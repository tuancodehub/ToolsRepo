# Stack profile: web app with backend

## What this covers
Products with a browser frontend AND your own server: an API, a database, accounts, background jobs. Any server language works. This is the highest-risk profile because the server holds other people's data and decides who may do what.

## Non-negotiable rules
1. **Production is off limits to sessions.** No production credentials, no production database, no deploy or migration commands. Previews and tests use a separate database with fake data and test keys (payment sandbox, email test mode).
2. **The server decides.** Every request is validated, authenticated and authorized (including per-object ownership) on the server.
3. **Migrations are reviewed files.** A migration is written by the builder, read by you and the security reviewer, and run against real data only by you or your deploy pipeline, never by a session. Destructive changes (dropping or rewriting data) are separate, planned features with a backup.
4. **Money and identity use hosted services.** Card data never touches your code (hosted checkout). Passwords use a vetted library; consider a managed sign-in provider.

## Before the first feature
- Decide the language and test tooling. The default `.claude/checks.json` assumes Node scripts (`lint`, `typecheck`, `test`, `test:api`, `build`, optional `db:check`). For other languages, `/init-project` rewrites the commands, for example:
  - Python: `ruff check .`, `mypy .`, `pytest -q` (set `requires_tool` accordingly)
  - Go: `go vet ./...`, `go test ./...`, `go build ./...`
  - Ruby, .NET, Java: the project's lint, test and build commands.
- A way to run API tests without real services: a local or containerized test database, or in-memory fakes. CI can start a service container (an example is commented in `.github/workflows/ci.yml`).
- A seed script that creates fake data.
- `.nvmrc` (Node projects) and `ignore-scripts=true` in `.npmrc` (owner edit).
- Preview environment with its own database and keys at your host.

## Checks
Required: `lint`, `typecheck`, `unit`, `api-tests`, `build`, `secrets`. Optional: `db-check` (migration lint or schema drift), `e2e`, `a11y`. CI runs them with `--strict` plus a dependency audit.

## Preview (gate 2)
A hosted preview of the frontend AND backend wired to the preview database (many hosts offer per-branch environments or branch databases). If you cannot get a full preview, ask for API tests plus screenshots, and treat the first release of any feature as higher risk. State your preview method in `PROJECT.md`.

## Risk guide
- **low:** copy and styling changes in the frontend.
- **medium:** new endpoints that touch no personal data, new UI with server calls.
- **high (always):** anything touching sign-in, sessions, roles or permissions; personal, health, child or financial data; payments; file uploads; email or SMS sending; migrations; background jobs with side effects; deployment, secrets or infrastructure files.

## Cost notes
- CI: 6 to 15 minutes per pull request, more with service containers and browser tests.
- Preview databases and environments can have their own free-tier limits.
- Features that call email, SMS, maps or AI services cost per use; test mode and low limits in previews.

## Browser support
Ask at `/init-project`; the answer lives in `.claude/browsers.txt` (one of `chromium`, `firefox`, `webkit` per line; Chrome and Edge are `chromium`, Safari is `webkit`) and in `docs/orchestration/PROJECT.md`.
- **Tests:** if you use Playwright, define one test project per listed browser (`projects: [{ name: 'chromium', ... }, { name: 'firefox', ... }, { name: 'webkit', ... }]`). CI installs exactly the browsers in `.claude/browsers.txt` and runs them all.
- **Cloud sessions may not be able to install every browser** (their network is limited). If one cannot be installed, the tests still run in GitHub's checks on the pull request; the agent must say so instead of skipping it silently.
- **Each extra browser adds a few CI minutes.** Public sites usually deserve all three; a private tool needs the browsers its users actually use, plus Chromium.
- **Features that only some browsers support** (for example choosing a folder to save into works in Chrome and Edge but not in Firefox or Safari; some payment, notification and file APIs differ too): the planner must list them as a decision. Build one storage or feature layer with a fallback for the other browsers, or show a clear, friendly "please use Chrome or Edge" page, and add a test for that message.
- **WebKit in tests is not real iPhone Safari.** Check the preview on a real device for anything that matters on phones.

## Limits and honesty
- Agents cannot prove an access-control design is safe; the security reviewer reads for it and tests should cover "wrong user" cases, but a human security review is wise before real users and real data.
- Compliance (privacy laws, payment standards, health or children's data) is the owner's responsibility; agents will mark such decisions OPEN.

## Local testing (local modes; see `LOCAL-MODE.md`)
- Run the frontend and API on **localhost only**, using this folder's port block (`worktree.py ports`: frontend, API, database get different numbers). Use a **local test database** (a throwaway container or file), never a shared or production one.
- Each worktree needs its own dependencies and its own test database name or file, so two sessions do not share data.
- Keep test data fake. Stop servers and remove the test database when done.

## Oneshot notes
See `docs/orchestration/ONESHOT.md`. Look at pages in each chosen browser and on a phone. Database changes (migrations) are never run against a real database: only a test one. Check with real test accounts; real data is a human check.
