# Stack profile: iOS app

## What this covers
Native iPhone and iPad apps in Swift (SwiftUI or UIKit). For cross-platform apps (React Native or Expo), use the *mobile (Expo)* kit.

## The honest limits (read first)
- **The cloud session runs Linux.** Apple's iOS build tools run only on macOS. So the session can write Swift and build and test a Swift Package, but it cannot build the app, run the simulator, or show you a screen.
- **No preview on your iPhone from the cloud.** Installing a build on an iPhone needs signing and, for easy sharing, TestFlight, which requires a paid Apple Developer Program membership. Even then, a build must come from a Mac (your own, or a CI macOS runner).
- **macOS CI minutes are about 10 times as expensive** as Linux minutes. This kit runs the macOS job only when you start it (manually, or by adding the label `run-ios-ci`).
- So expect: **more risk per feature, less automatic proof.** Agents help most with logic, data, networking and tests in a Swift Package, and least with visual polish.

## How to make this work well
1. **Put logic in a Swift Package** (`Package.swift`): models, networking, storage, view models. Linux can build and test it, for free, quickly.
2. **Keep the Xcode project thin** (app target, screens, assets). Prefer a generated project (XcodeGen `project.yml` or Tuist) so the project file is readable text, not a huge hand-edited blob that creates merge conflicts.
3. **Use SwiftUI previews and a few screenshot tests** where possible; you do the final visual check on your own Mac or a test phone via your usual route.
4. **Preview gate (gate 2) options:**
   - Pull the branch on your Mac, open in Xcode, run on the simulator or your own device (free signing works for your own devices).
   - Run the macOS CI job (label `run-ios-ci`); it proves the app builds and tests pass, but gives no picture.
   - TestFlight distribution: only if you have the paid Apple program and set up signing yourself outside the session.

## Before the first feature
- Decide the build route (A: Swift Package only, B: Xcode project) and enable the matching step in `.github/workflows/ci.yml` (`/init-project` helps). Until you do, the macOS job deliberately fails with a reminder.
- Optional: add a `.swiftlint.yml` and install SwiftLint in CI.
- Keep certificates (`.p12`), provisioning profiles, App Store Connect keys (`.p8`) and fastlane secrets out of the repository; they live in your Keychain or a secrets manager.

## Checks
Required: `secrets`. Optional until configured: `lint` (SwiftLint), `package-build`, `package-tests`. The macOS job is the full build. Because required checks are thin, treat the owner review as the main gate for risky changes.

## Risk guide
- **low:** strings, colors, assets, small view tweaks inside the Swift Package's tested logic.
- **medium:** new screens, storage, navigation, new library.
- **high:** entitlements, permission strings in Info.plist, App Transport Security exceptions, Keychain or encryption, sign-in, purchases (StoreKit), background modes, push notifications, URL schemes and universal links, WebViews, anything with personal data, project or signing configuration.

## Cost notes
- Linux checks: minutes. macOS build: 10 to 25 macOS minutes at about ten times the rate, so budget roughly 100 to 250 Linux-equivalent minutes per run. On the free plan's 2,000 included minutes, that is only a few runs a month. Trigger it sparingly.

## Limits and honesty
- App Store review rules, privacy nutrition labels, export compliance, and age ratings are yours to answer.
- Many Apple features (push, purchases, Sign in with Apple) need account setup in Apple's portals that no agent can do.

## Local testing (local modes; see `LOCAL-MODE.md`)
- iPhone apps build and run only on a **Mac with Xcode**. On Windows or Linux use cloud mode for planning, code and checks, and test on a Mac later.
- You install Xcode and the simulators. Agents may build for the **simulator** (`xcodebuild ... -destination 'platform=iOS Simulator,...'`) and control it with `xcrun simctl`. Real-phone testing and signing are yours.
- Build output goes to a folder inside this project or its worktree (use `-derivedDataPath`), not your home Library folder.
- Use a **test Apple account and fake data**; never commit certificates, provisioning files or keys.

## Oneshot notes
See `docs/orchestration/ONESHOT.md`. EXPERIMENTAL. Touch, device sizes, signing, store settings and real devices need a human. macOS CI minutes cost about 10 times Linux.
