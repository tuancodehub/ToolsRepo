## What changed and why

## How to check it
<!-- Preview link or steps. -->

## Checks
<!-- Result of: python3 -I scripts/orchestration/run_checks.py . List anything skipped locally that CI covers. -->

## Reviews
- Quality:
- UX / accessibility:
- Security:

## New dependencies
<!-- Name, version, why. Or "none". -->

## OPEN items / decisions needed
<!-- Or "none". -->

## Owner checklist before merging
- [ ] I looked at the preview and it does what I asked
- [ ] CI is green
- [ ] No safety files changed (.claude, .githooks, .github/workflows, CLAUDE.md, scripts/orchestration) unless I asked for it
- [ ] I am happy with the new dependencies (if any)
