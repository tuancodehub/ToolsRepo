#!/usr/bin/env python3
"""The parking lot: where questions, concerns and guesses go during a oneshot run. Standard library only.

One small file per item in docs/parking-lot/, so stacked branches never conflict. Commit them with the feature.

  park.py add --feature SLUG --type TYPE --title "..." --detail "..." [--default "what I did instead"]
              [--severity low|medium|high] [--options "A | B | C"] [--recommend "A"]
  park.py list [--open] [--feature SLUG]
  park.py show ID
  park.py resolve ID --decision "what the owner chose"

TYPE is one of: question, concern, assumption, open, risk, human-test.
  question    something only the owner can answer; say what you did instead (--default)
  concern     something that may be wrong or costly later
  assumption  a guess you made because a sensible default existed
  open        money, tax, legal wording, real names, links, credentials: never guessed, placeholder used
  risk        a security, privacy or data risk you noticed
  human-test  something only a person can check (looks, phone or device behavior, real accounts)
Money, legal and policy wording, real names, phone numbers, links, reviews and credentials are NEVER guessed:
park them as `open` and use a clearly marked placeholder.
"""
import datetime
import os
import re
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
DIR = os.path.join(ROOT, "docs", "parking-lot")
SLUG_RE = re.compile(r"^[a-z0-9][a-z0-9-]{0,40}$")
ID_RE = re.compile(r"^[a-z0-9][a-z0-9-]{0,40}-\d{2,3}$")
TYPES = ("question", "concern", "assumption", "open", "risk", "human-test")
SEVERITIES = ("low", "medium", "high")
KEYS = {"--feature": "feature", "--type": "type", "--title": "title", "--detail": "detail", "--default": "default",
        "--severity": "severity", "--options": "options", "--recommend": "recommend", "--decision": "decision"}


def clean(text, limit=1200, multiline=False):
    text = str(text or "")
    text = re.sub(r"[\x00-\x08\x0b-\x1f\x7f]+", " ", text) if multiline else re.sub(r"[\x00-\x1f\x7f]+", " ", text)
    return text.replace("---", "- - -").strip()[:limit]


def parse(args):
    out, flags, i = {}, set(), 0
    while i < len(args):
        a = args[i]
        if a in ("--open",):
            flags.add(a)
            i += 1
        elif a in KEYS and i + 1 < len(args):
            out[KEYS[a]] = args[i + 1]
            i += 2
        elif not a.startswith("--") and "id" not in out:
            out["id"] = a
            i += 1
        else:
            print("unknown or incomplete option: %s" % a)
            return None, None
    return out, flags


def front(path):
    try:
        text = open(path, "r", encoding="utf-8").read()
    except OSError:
        return None, ""
    m = re.match(r"^---\n(.*?)\n---\n?(.*)$", text, re.S)
    if not m:
        return None, text
    fm = {}
    for line in m.group(1).splitlines():
        if ":" in line:
            k, v = line.split(":", 1)
            fm[k.strip()] = v.strip()
    return fm, m.group(2)


def item_path(item_id):
    return os.path.join(DIR, item_id + ".md")


def all_items():
    items = []
    for name in sorted(os.listdir(DIR)) if os.path.isdir(DIR) else []:
        if name.endswith(".md"):
            fm, body = front(os.path.join(DIR, name))
            if fm:
                fm["_body"] = body
                items.append(fm)
    return items


def cmd_add(o):
    for need in ("feature", "type", "title", "detail"):
        if not o.get(need):
            print("REFUSED: missing --%s" % need)
            return 4
    if not SLUG_RE.match(o["feature"]) or o["type"] not in TYPES or o.get("severity", "medium") not in SEVERITIES:
        print("REFUSED: bad --feature, --type (%s) or --severity (%s)." % (", ".join(TYPES), ", ".join(SEVERITIES)))
        return 4
    os.makedirs(DIR, exist_ok=True)
    n = 1 + max([int(m.group(1)) for f in os.listdir(DIR) for m in [re.match(r"^%s-(\d+)\.md$" % re.escape(o["feature"]), f)] if m] or [0])
    item_id = "%s-%02d" % (o["feature"], n)
    body = ["---", "id: " + item_id, "feature: " + o["feature"], "type: " + o["type"],
            "severity: " + o.get("severity", "medium"), "status: open",
            "title: " + clean(o["title"], 140), "created: " + datetime.date.today().isoformat(), "---", "",
            "## What", clean(o["detail"], 1500, True), ""]
    if o.get("default"):
        body += ["## What was done instead (safe default)", clean(o["default"], 600, True), ""]
    if o.get("options"):
        body += ["## Options", clean(o["options"], 600), ""]
    if o.get("recommend"):
        body += ["## Recommended", clean(o["recommend"], 300), ""]
    body += ["## Decision", "(not decided yet)", ""]
    with open(item_path(item_id), "w", encoding="utf-8") as fh:
        fh.write("\n".join(body))
    print("PARKED %s (%s). Continue with the safe default; do not wait. Commit docs/parking-lot/%s.md with the feature." % (item_id, o["type"], item_id))
    return 0


def cmd_list(o, flags):
    items = all_items()
    if "--open" in flags:
        items = [i for i in items if i.get("status") == "open"]
    if o.get("feature"):
        items = [i for i in items if i.get("feature") == o["feature"]]
    if not items:
        print("Parking lot: nothing here.")
        return 0
    order = {"high": 0, "medium": 1, "low": 2}
    items.sort(key=lambda i: (order.get(i.get("severity"), 1), i.get("feature", ""), i.get("id", "")))
    for i in items:
        print("%-26s %-10s %-6s %-9s %s" % (i.get("id"), i.get("type"), i.get("severity"), i.get("status"), i.get("title")))
    counts = {}
    for i in items:
        counts[i.get("type")] = counts.get(i.get("type"), 0) + 1
    print("-- %d items: %s" % (len(items), ", ".join("%d %s" % (n, t) for t, n in sorted(counts.items()))))
    return 0


def cmd_show(o):
    if not ID_RE.match(o.get("id", "")) or not os.path.exists(item_path(o["id"])):
        print("No such item.")
        return 4
    print(open(item_path(o["id"]), "r", encoding="utf-8").read())
    return 0


def cmd_resolve(o):
    if not ID_RE.match(o.get("id", "")) or not os.path.exists(item_path(o["id"])) or not o.get("decision"):
        print("usage: resolve ID --decision \"...\" (the item must exist)")
        return 4
    text = open(item_path(o["id"]), "r", encoding="utf-8").read()
    text = re.sub(r"(?m)^status: .*$", "status: resolved", text, count=1)
    text = re.sub(r"(?s)## Decision\n.*$", lambda _m: "## Decision\n" + clean(o["decision"], 800, True) + "\n", text)
    with open(item_path(o["id"]), "w", encoding="utf-8") as fh:
        fh.write(text)
    print("RESOLVED %s" % o["id"])
    return 0


def main():
    if len(sys.argv) < 2 or sys.argv[1] not in ("add", "list", "show", "resolve"):
        print(__doc__)
        return 1
    o, flags = parse(sys.argv[2:])
    if o is None:
        return 1
    return {"add": lambda: cmd_add(o), "list": lambda: cmd_list(o, flags), "show": lambda: cmd_show(o),
            "resolve": lambda: cmd_resolve(o)}[sys.argv[1]]()


if __name__ == "__main__":
    sys.exit(main())
