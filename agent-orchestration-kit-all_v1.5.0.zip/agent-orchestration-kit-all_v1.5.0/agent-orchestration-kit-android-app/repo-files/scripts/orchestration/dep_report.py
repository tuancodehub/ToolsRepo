#!/usr/bin/env python3
"""List dependencies ADDED, REMOVED or CHANGED compared with the default branch, so the security reviewer
can check every new package (supply-chain safety: typo-squats, brand-new or unmaintained packages).

  dep_report.py [--base origin/main]
Understands: package.json, requirements*.txt, pyproject.toml, go.mod, Gemfile, Cargo.toml,
Gradle (build.gradle[.kts], libs.versions.toml), Swift (Package.swift, Package.resolved).
"""
import json
import os
import re
import subprocess
import sys

try:
    import tomllib
except ImportError:  # Python < 3.11
    tomllib = None

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


def sh(*args):
    p = subprocess.run(["git", "-C", ROOT] + list(args), capture_output=True, text=True)
    return p.stdout if p.returncode == 0 else None


def parse(name, text):
    base = os.path.basename(name)
    deps = {}
    if text is None:
        return deps
    try:
        if base == "package.json":
            j = json.loads(text)
            for sec in ("dependencies", "devDependencies", "optionalDependencies", "peerDependencies"):
                for k, v in (j.get(sec) or {}).items():
                    deps["%s (%s)" % (k, sec)] = v
        elif re.match(r"requirements.*\.txt$", base):
            for line in text.splitlines():
                line = line.split("#", 1)[0].strip()
                m = re.match(r"^([A-Za-z0-9_.\-\[\]]+)\s*(.*)$", line)
                if m and not line.startswith("-"):
                    deps[m.group(1)] = m.group(2) or "*"
        elif base == "pyproject.toml" and tomllib:
            t = tomllib.loads(text)
            for d in (t.get("project", {}).get("dependencies") or []):
                m = re.match(r"^([A-Za-z0-9_.\-]+)\s*(.*)$", d)
                if m:
                    deps[m.group(1)] = m.group(2) or "*"
            for k, v in (t.get("tool", {}).get("poetry", {}).get("dependencies") or {}).items():
                deps[k] = str(v)
        elif base == "Cargo.toml" and tomllib:
            t = tomllib.loads(text)
            for sec in ("dependencies", "dev-dependencies", "build-dependencies"):
                for k, v in (t.get(sec) or {}).items():
                    deps["%s (%s)" % (k, sec)] = str(v)
        elif base == "libs.versions.toml" and tomllib:
            t = tomllib.loads(text)
            for k, v in (t.get("libraries") or {}).items():
                deps[k] = str(v)
        elif base == "go.mod":
            for m in re.finditer(r"^\s*([\w.\-/]+)\s+(v[\w.\-+]+)", text, re.M):
                deps[m.group(1)] = m.group(2)
        elif base == "Gemfile":
            for m in re.finditer(r"^\s*gem\s+['\"]([^'\"]+)['\"](?:\s*,\s*['\"]([^'\"]+)['\"])?", text, re.M):
                deps[m.group(1)] = m.group(2) or "*"
        elif base.startswith("build.gradle"):
            for m in re.finditer(r"""(?:implementation|api|kapt|ksp|testImplementation|androidTestImplementation|debugImplementation|classpath)\s*\(?\s*["']([^"']+)["']""", text):
                deps[m.group(1)] = ""
        elif base == "Package.swift":
            for m in re.finditer(r"\.package\(\s*url:\s*\"([^\"]+)\"[^)]*\)", text):
                deps[m.group(1)] = m.group(0)[:100]
        elif base == "Package.resolved":
            j = json.loads(text)
            for pin in (j.get("pins") or j.get("object", {}).get("pins") or []):
                deps[pin.get("identity") or pin.get("package", "?")] = str((pin.get("state") or {}).get("version") or (pin.get("state") or {}).get("revision", ""))[:12]
    except (ValueError, KeyError, AttributeError):
        deps["(could not parse %s)" % base] = ""
    return deps


def main():
    base = "origin/main"
    if "--base" in sys.argv:
        base = sys.argv[sys.argv.index("--base") + 1]
    elif sh("rev-parse", "--verify", "--quiet", "origin/main") is None and sh("rev-parse", "--verify", "--quiet", "origin/master"):
        base = "origin/master"
    files = set((sh("diff", "--name-only", base + "...HEAD") or "").split()) | set((sh("diff", "--name-only", "HEAD") or "").split())
    manifests = sorted(f for f in files if re.search(
        r"(^|/)(package\.json|requirements[\w.\-]*\.txt|pyproject\.toml|go\.mod|Gemfile|Cargo\.toml|build\.gradle(\.kts)?|libs\.versions\.toml|Package\.swift|Package\.resolved)$", f))
    if not manifests:
        print("No dependency manifests changed.")
        return 0
    total = 0
    for f in manifests:
        old = parse(f, sh("show", "%s:%s" % (base, f)))
        try:
            new = parse(f, open(os.path.join(ROOT, f), "r", encoding="utf-8").read())
        except OSError:
            new = {}
        added = sorted(set(new) - set(old))
        removed = sorted(set(old) - set(new))
        changed = sorted(k for k in set(old) & set(new) if old[k] != new[k])
        if not (added or removed or changed):
            continue
        print("== %s" % f)
        for k in added:
            print("  ADDED    %s %s" % (k, new[k]))
        for k in changed:
            print("  CHANGED  %s: %s -> %s" % (k, old[k], new[k]))
        for k in removed:
            print("  REMOVED  %s" % k)
        total += len(added) + len(changed) + len(removed)
    print("%d dependency change(s). For each ADDED package: confirm the exact name is the well-known one "
          "(no typo-squats), it is maintained, and it is really needed." % total)
    return 0


if __name__ == "__main__":
    sys.exit(main())
