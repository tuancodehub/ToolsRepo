#!/usr/bin/env python3
"""Show what the safety hooks decided: blocked, asked, or (in oneshot) allowed without asking.

  python3 -I scripts/orchestration/hook_log.py summary        # counts and the most common items
  python3 -I scripts/orchestration/hook_log.py recent [N]     # the last N decisions (default 20)

The log is .claude/.check-logs/hook-log.jsonl: local to this computer or session, never committed.
Token-like strings are cut out of it. Read-only: this script never changes anything.
"""
import collections
import json
import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
LOG = os.path.join(ROOT, ".claude", ".check-logs", "hook-log.jsonl")


def load():
    rows = []
    for p in (LOG + ".1", LOG):
        try:
            with open(p, "r", encoding="utf-8") as fh:
                for line in fh:
                    try:
                        rows.append(json.loads(line))
                    except ValueError:
                        pass
        except OSError:
            pass
    return rows


def head(what):
    parts = what.split()
    return " ".join(parts[:2]) if parts else "(empty)"


def main():
    rows = load()
    cmd = sys.argv[1] if len(sys.argv) > 1 else "summary"
    if not rows:
        print("No hook decisions logged yet.")
        return 0
    if cmd == "recent":
        n = int(sys.argv[2]) if len(sys.argv) > 2 and sys.argv[2].isdigit() else 20
        for r in rows[-n:]:
            print("%s  %-18s %-8s %s  [%s]" % (r.get("mode"), r.get("decision"), r.get("tool"), r.get("what"), r.get("reason")))
        return 0
    counts = collections.Counter(r.get("decision") for r in rows)
    print("Decisions: " + ", ".join("%s %d" % (k, v) for k, v in counts.most_common()))
    for kind, title in (("deny", "Blocked for good (hard blocks)"), ("blocked-in-oneshot", "Would have asked you, blocked in oneshot"),
                        ("ask", "Asked you"), ("auto-allowed", "Allowed without asking in oneshot (command starts with)")):
        sel = [r for r in rows if r.get("decision") == kind]
        if not sel:
            continue
        print("\n%s: %d" % (title, len(sel)))
        if kind == "auto-allowed":
            c = collections.Counter(head(r.get("what", "")) for r in sel if r.get("tool") == "Bash")
        else:
            c = collections.Counter((r.get("reason") or "")[:110] + "  <- " + head(r.get("what", "")) for r in sel)
        for item, n in c.most_common(8):
            print("  %3dx  %s" % (n, item))
    return 0


if __name__ == "__main__":
    sys.exit(main())
