#!/usr/bin/env python3
"""Show the feature queue. There is no hand-edited table to conflict on: every feature's status lives in
the front matter of its own brief (docs/briefs/<slug>.md), and this script builds the table.

  queue_status.py           numbered build order, one-line goals, warnings
  queue_status.py --short   2-3 lines (used at session start)
  queue_status.py --next    the slug of the next feature that is ready to build (nothing else on stdout)

Order: set `order: N` (1 = first) in a brief's front matter. Features without an order come after the ordered
ones, alphabetically. A feature is READY when it is queued and every feature in `depends_on` is merged.
"""
import glob
import os
import re
import subprocess
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
ACTIVE = {"claimed", "planning", "building", "reviewing", "preview", "pr-open"}


def front_matter(path):
    try:
        text = open(path, "r", encoding="utf-8").read()
    except OSError:
        return {}
    m = re.match(r"^---\n(.*?)\n---", text, re.S)
    data = {}
    if not m:
        return data
    for line in m.group(1).splitlines():
        if ":" in line and not line.startswith(" "):
            k, v = line.split(":", 1)
            v = v.split("#", 1)[0].strip()
            if v.startswith("[") and v.endswith("]"):
                data[k.strip()] = [x.strip().strip("'\"") for x in v[1:-1].split(",") if x.strip()]
            else:
                data[k.strip()] = v.strip("'\"")
    return data


def static_prefix(pattern):
    m = re.search(r"[*?\[]", pattern)
    return pattern[:m.start()] if m else pattern


def overlaps(a, b):
    pa, pb = static_prefix(a), static_prefix(b)
    return pa.startswith(pb) or pb.startswith(pa)


def goal_text(path):
    """First sentence under '## Goal' (placeholder text and comments are ignored)."""
    try:
        text = open(path, "r", encoding="utf-8").read()
    except OSError:
        return ""
    m = re.search(r"(?ms)^## Goal\s*\n(.*?)(?=^## |\Z)", text)
    if not m:
        return ""
    body = re.sub(r"(?s)<!--.*?-->", "", m.group(1)).strip()
    body = " ".join(body.split())
    if not body or body.startswith("One or two sentences"):
        return ""
    cut = re.search(r"[.!?](\s|$)", body)
    first = body[:cut.end()].strip() if cut else body
    return first if len(first) <= 150 else first[:147].rstrip() + "..."


def order_of(b):
    try:
        n = int(str(b.get("order", "0")).strip() or 0)
    except ValueError:
        n = 0
    return n if n > 0 else 10 ** 6


def is_ready(b, status_by_slug, claims):
    if b.get("status") != "queued":
        return False
    if claims and b["slug"] in claims:
        return False
    return all(status_by_slug.get(d) == "merged" for d in b.get("depends_on", []))


def remote_claims():
    try:
        p = subprocess.run(["git", "-C", ROOT, "ls-remote", "--heads", "origin", "refs/heads/feature/*"],
                           capture_output=True, text=True, timeout=10)
        if p.returncode != 0:
            return None
        return {l.split("refs/heads/feature/", 1)[1] for l in p.stdout.splitlines() if "refs/heads/feature/" in l}
    except (OSError, subprocess.SubprocessError):
        return None


def other_session_briefs(known):
    """Local modes: briefs that live only in another running session's worktree."""
    out = []
    try:
        sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
        import orch_common as oc
        ws = oc.load_ws(ROOT)
        if not oc.is_local(ws):
            return out
        for s in oc.active_sessions(oc.state_dir(ROOT), ws["stale_hours"]):
            if s["slug"] in known or os.path.realpath(s["path"]) == os.path.realpath(ROOT):
                continue
            fm = front_matter(os.path.join(s["path"], "docs", "briefs", s["slug"] + ".md"))
            if fm:
                fm.setdefault("slug", s["slug"])
                out.append(fm)
    except Exception:
        pass
    return out


def main():
    short = "--short" in sys.argv
    want_next = "--next" in sys.argv
    briefs = []
    for path in sorted(glob.glob(os.path.join(ROOT, "docs", "briefs", "*.md"))):
        name = os.path.basename(path)
        if name.startswith("_"):
            continue
        fm = front_matter(path)
        fm.setdefault("slug", name[:-3])
        fm["_goal"] = goal_text(path)
        briefs.append(fm)

    briefs += other_session_briefs({b["slug"] for b in briefs})
    claims = remote_claims()
    counts = {}
    for b in briefs:
        counts[b.get("status", "?")] = counts.get(b.get("status", "?"), 0) + 1
    active = [b for b in briefs if b.get("status") in ACTIVE]

    if want_next:
        by = {b["slug"]: b.get("status") for b in briefs}
        ready = sorted([b for b in briefs if is_ready(b, by, claims)], key=lambda b: (order_of(b), b["slug"]))
        if ready:
            print(ready[0]["slug"])
            return 0
        sys.stderr.write("No queued feature is ready (everything is merged, claimed, or waiting on a dependency).\n")
        return 1

    if short:
        if not briefs:
            print("Queue: empty (add one with /add-feature).")
        else:
            print("Queue: " + ", ".join("%d %s" % (n, s) for s, n in sorted(counts.items())) +
                  ("; active: " + ", ".join(b["slug"] for b in active) if active else ""))
        return 0

    if not briefs:
        print("Queue is empty. Add a feature with /add-feature <slug>.")
        return 0
    by_status = {b["slug"]: b.get("status") for b in briefs}
    upcoming = sorted([b for b in briefs if b.get("status") not in ("merged", "cancelled")], key=lambda b: (order_of(b), b["slug"]))
    done = sorted([b for b in briefs if b.get("status") in ("merged", "cancelled")], key=lambda b: b["slug"])
    nxt = next((b for b in upcoming if is_ready(b, by_status, claims)), None)
    print("BUILD ORDER (1 = first). READY means queued and every dependency is merged.")
    for n, b in enumerate(upcoming, 1):
        tags = []
        if b is nxt:
            tags.append("<-- NEXT")
        elif b.get("status") == "queued" and is_ready(b, by_status, claims):
            tags.append("ready")
        elif b.get("status") == "queued":
            waiting = [d for d in b.get("depends_on", []) if by_status.get(d) != "merged"]
            if waiting:
                tags.append("waits for " + ", ".join(waiting))
        if claims and b["slug"] in claims:
            tags.append("remote branch")
        print("%3d. %s  [%s, risk %s]%s" % (n, b["slug"], b.get("status", "?"), b.get("risk", "?"), ("  " + "; ".join(tags)) if tags else ""))
        print("     " + (b.get("_goal") or "(no goal written yet)"))
    if done:
        print("DONE: " + ", ".join(b["slug"] for b in done))
    warned = False
    for i, a in enumerate(active):
        for b in active[i + 1:]:
            for pa in a.get("touches", []):
                for pb in b.get("touches", []):
                    if overlaps(pa, pb):
                        print("WARNING: '%s' and '%s' are both active and both touch %s / %s. "
                              "Expect a merge conflict; merge one before the other." % (a["slug"], b["slug"], pa, pb))
                        warned = True
    if claims:
        known = {b["slug"] for b in briefs}
        for s in sorted(claims - known):
            print("NOTE: remote branch feature/%s has no brief on this branch yet." % s)
    if not warned:
        print("No overlapping 'touches' among active features.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
