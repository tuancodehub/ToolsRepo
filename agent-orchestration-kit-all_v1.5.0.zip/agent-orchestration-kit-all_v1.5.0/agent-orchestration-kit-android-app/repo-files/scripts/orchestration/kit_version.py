#!/usr/bin/env python3
"""Show which orchestration kit version is installed and check the kit's files match it.

  python3 -I scripts/orchestration/kit_version.py          # print the installed version
  python3 -I scripts/orchestration/kit_version.py check    # also compare every kit file with the install record

The install record is docs/orchestration/KIT-VERSION.txt: line 1 is "agent-orchestration-kit <type> <version>", then one
"<sha256>  <path>" line per kit file as shipped. Files you are meant to edit (CLAUDE.md, PROJECT.md, checks.json,
browsers.txt, ci.yml, areas.json) are not listed. Missing file = FAIL. Changed safety file = WARN (check it is yours).
Exit 0 = OK or only warnings, 1 = FAIL. Read-only: nothing is changed.
"""
import hashlib
import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
RECORD = os.path.join(ROOT, "docs", "orchestration", "KIT-VERSION.txt")
SAFETY = (".claude/hooks/", ".githooks/", "scripts/orchestration/", ".claude/settings.json", ".claude/agents/", ".claude/commands/")


def digest(path):
    with open(path, "rb") as fh:
        return hashlib.sha256(fh.read().replace(b"\r\n", b"\n")).hexdigest()


def read_record():
    try:
        with open(RECORD, "r", encoding="utf-8") as fh:
            lines = [l.rstrip("\n") for l in fh if l.strip()]
    except OSError:
        return None, {}
    files = {}
    for l in lines[1:]:
        h, _, p = l.partition("  ")
        if h and p:
            files[p] = h
    return lines[0], files


def main():
    head, files = read_record()
    if not head:
        print("Kit version: UNKNOWN (docs/orchestration/KIT-VERSION.txt is missing: the kit was not installed completely, or is very old).")
        return 1
    print("Kit version: " + head.replace("agent-orchestration-kit ", "", 1))
    if len(sys.argv) < 2 or sys.argv[1] != "check":
        return 0
    missing, changed = [], []
    for rel, want in sorted(files.items()):
        p = os.path.join(ROOT, rel)
        if not os.path.isfile(p):
            missing.append(rel)
        elif digest(p) != want:
            changed.append(rel)
    ok = len(files) - len(missing) - len(changed)
    print("Kit files: %d listed, %d match, %d changed, %d missing." % (len(files), ok, len(changed), len(missing)))
    for m in missing:
        print("FAIL missing: " + m)
    for c in changed:
        print(("WARN changed (safety file; make sure the change is yours): " if c.startswith(SAFETY) else "note changed: ") + c)
    if missing:
        print("RESULT: FAIL (some kit files are missing; re-run the kit install)")
        return 1
    print("RESULT: OK" + (" with warnings" if any(c.startswith(SAFETY) for c in changed) else ""))
    return 0


if __name__ == "__main__":
    sys.exit(main())
