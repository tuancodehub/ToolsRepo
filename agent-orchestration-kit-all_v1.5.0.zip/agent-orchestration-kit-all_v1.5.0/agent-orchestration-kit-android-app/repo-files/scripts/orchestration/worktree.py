#!/usr/bin/env python3
"""Worktrees for running several sessions on YOUR computer at once. Standard library only.

A worktree is an extra folder holding another checked-out copy of the same project, on its own branch, so a second
Claude session can work without touching the first. They live NEXT TO the project:

    <workspace>/MyProject/                 the main folder
    <workspace>/MyProject-worktrees/<slug> one folder per running feature
    <workspace>/tools/                     tools shared by every project and worktree

  worktree.py add <slug>       make the folder (detached at the default branch; nothing pushed), give it a port block.
                               Then open a terminal in it, start Claude there and run /build-feature <slug>.
  worktree.py list             worktrees, their branches, sessions and ports
  worktree.py remove <slug>    remove the folder (only if it has no uncommitted changes). The branch is kept.
  worktree.py ports [<slug>]   the port numbers this worktree should use for dev servers
  worktree.py tools            where shared tools and Python virtual environments go, and how

Only works in the local modes. Limit: max_sessions (default 2) worktrees at once.
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import orch_common as oc  # noqa: E402

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
WS = oc.load_ws(ROOT)
MAIN = WS["_main"]


def git(*args):
    return oc.git(MAIN, *args)


def listing():
    out, cur = git("worktree", "list", "--porcelain").stdout, {}
    rows = []
    for line in out.splitlines() + [""]:
        if not line.strip():
            if cur:
                rows.append(cur)
            cur = {}
        elif " " in line:
            k, v = line.split(" ", 1)
            cur[k] = v
        else:
            cur[line] = True
    return rows


def default_branch():
    p = git("symbolic-ref", "--short", "refs/remotes/origin/HEAD")
    if p.returncode == 0 and p.stdout.strip():
        return p.stdout.strip().split("/", 1)[1]
    for cand in ("main", "master"):
        if git("rev-parse", "--verify", "--quiet", "refs/heads/" + cand).returncode == 0:
            return cand
    return "main"


def need_local():
    if oc.is_local(WS):
        return True
    print("This computer is not set up for local mode, so worktrees are not used. In cloud mode every feature already "
          "gets its own clean cloud session. To use worktrees on your computer, the owner runs set_workspace.py "
          "(see docs/orchestration/LOCAL-MODE.md).")
    return False


def cmd_add(slug):
    if not oc.SLUG_RE.match(slug):
        print("REFUSED: give a slug (lowercase letters, numbers, dashes).")
        return 4
    base = oc.worktrees_base(WS)
    path = os.path.join(base, slug)
    ws_root = WS["workspace_root"]
    if not (os.path.realpath(path) + os.sep).startswith(os.path.realpath(ws_root) + os.sep):
        print("REFUSED: %s is outside the workspace folder %s. Put the project inside the workspace folder." % (path, ws_root))
        return 4
    extra = [r for r in listing() if os.path.realpath(r.get("worktree", "")) != os.path.realpath(MAIN)]
    if len(extra) >= int(WS.get("max_sessions", 2)):
        print("REFUSED: %d worktrees already exist (limit %d). Finish and remove one first (worktree.py remove <slug>)." %
              (len(extra), WS["max_sessions"]))
        return 5
    if os.path.exists(path):
        print("REFUSED: %s already exists." % path)
        return 4
    branch = "feature/" + slug
    if git("rev-parse", "--verify", "--quiet", "refs/heads/" + branch).returncode == 0:
        print("ALREADY CLAIMED: branch %s already exists on this computer." % branch)
        return 3
    b = default_branch()
    if WS["mode"] == "local-github":
        if git("ls-remote", "--exit-code", "--heads", "origin", "refs/heads/" + branch).returncode == 0:
            print("ALREADY CLAIMED: %s exists on GitHub. Another session or computer is working on it." % branch)
            return 3
        f = git("fetch", "origin", b)
        if f.returncode != 0:
            print("fetch failed:", f.stderr.strip())
            return 1
        start = "origin/" + b
    else:
        start = b
    os.makedirs(base, exist_ok=True)
    p = git("worktree", "add", "--detach", path, start)
    if p.returncode != 0:
        print("worktree add failed:", p.stderr.strip())
        return 1
    st = oc.state_dir(MAIN)
    slot = oc.assign_slot(st, slug)
    print("WORKTREE READY: %s" % path)
    print_ports(slot)
    print("Next steps (do these yourself, in a NEW terminal window):")
    print("  1. cd into that folder:   cd \"%s\"" % path)
    print("  2. install what the project needs there (each worktree has its own copy of dependencies)")
    print("  3. start Claude in that folder, then run:   /build-feature %s" % slug)
    return 0


def print_ports(slot):
    print("Ports for this worktree (use these so it never collides with other sessions):")
    for k, v in oc.ports_for(slot).items():
        print("  %-24s %d" % (k, v))


def cmd_list():
    st = oc.state_dir(MAIN)
    slots = oc.read_slots(st)
    sess = {s["path"]: s for s in oc.active_sessions(st, WS["stale_hours"])}
    for r in listing():
        path = r.get("worktree", "")
        name = os.path.basename(path)
        s = sess.get(path)
        print("%-40s %-28s slot=%-3s %s" % (path, r.get("branch", "(detached)").replace("refs/heads/", ""), slots.get(name, "-" if path != MAIN else 0),
                                             ("session: %s, active %s" % (s["slug"], oc.age_text(s["heartbeat"]))) if s else ""))
    return 0


def cmd_remove(slug):
    path = os.path.join(oc.worktrees_base(WS), slug)
    if not os.path.isdir(path):
        print("No worktree at %s." % path)
        return 1
    dirty = oc.git(path, "status", "--porcelain", "--untracked-files=no").stdout.strip()
    if dirty:
        print("REFUSED: %s has uncommitted changes. Commit or discard them first." % path)
        return 4
    p = git("worktree", "remove", path)
    if p.returncode != 0:
        print("could not remove:", (p.stderr or p.stdout).strip())
        return 1
    st = oc.state_dir(MAIN)
    oc.release_slot(st, slug)
    oc.release_session(st, slug)
    print("REMOVED: %s. The branch feature/%s is kept (delete it yourself once merged)." % (path, slug))
    return 0


def cmd_ports(slug):
    st = oc.state_dir(MAIN)
    if not slug:
        here = os.path.basename(ROOT)
        slug = here if here in oc.read_slots(st) else None
    slot = oc.read_slots(st).get(slug, 0) if slug else 0
    print_ports(slot)
    return 0


def cmd_tools():
    t = oc.tools_path(WS)
    os.makedirs(os.path.join(t, "venvs"), exist_ok=True)
    os.makedirs(os.path.join(t, "bin"), exist_ok=True)
    print("Shared tools folder: %s" % t)
    print("  Python tools:   python3 -m venv \"%s/venvs/<name>\"   then   \"%s/venvs/<name>/bin/pip\" install <package>" % (t, t))
    print("                  (on Windows the program is <name>\\Scripts\\pip.exe)")
    print("  Downloaded programs: save them in \"%s/bin\" and run them from there." % t)
    print("  Every project and worktree uses this same folder. Agents may not install anything outside the work folders.")
    return 0


def main():
    if len(sys.argv) < 2 or sys.argv[1] not in ("add", "list", "remove", "ports", "tools"):
        print(__doc__)
        return 1
    if not need_local():
        return 4
    c = sys.argv[1]
    arg = sys.argv[2] if len(sys.argv) > 2 else None
    if c == "list":
        return cmd_list()
    if c == "tools":
        return cmd_tools()
    if c == "ports":
        return cmd_ports(arg)
    if not arg:
        print("usage: worktree.py %s <slug>" % c)
        return 1
    return cmd_add(arg) if c == "add" else cmd_remove(arg)


if __name__ == "__main__":
    sys.exit(main())
