#!/usr/bin/env python3
"""OWNER-ONLY: merge a finished feature into the main branch on YOUR computer (local mode, no pull request).

Run it yourself in a terminal, from the main project folder, after you approved the preview:

    python3 scripts/orchestration/local_merge.py <slug>

It will not run unless a person is typing at a terminal: agents cannot use it, by design.
It checks the folder is clean, merges feature/<slug> into the default branch with a merge commit, and runs the
project checks on the result. If the checks fail it tells you how to undo the merge (it never undoes anything itself).
In local-github mode, merge pull requests on GitHub instead.
"""
import os
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(os.path.dirname(HERE))
sys.path.insert(0, HERE)
import orch_common as oc  # noqa: E402


def git(*args):
    return oc.git(ROOT, *args)


def main():
    if not (sys.stdin.isatty() and sys.stdout.isatty()):
        print("REFUSED: this must be run by a person at a terminal, not by an agent.")
        return 4
    arg = sys.argv[1] if len(sys.argv) == 2 else ""
    prefix, _, rest = arg.partition("/") if "/" in arg else ("feature", "", arg)
    if prefix not in ("feature", "chore", "fix", "docs") or not oc.SLUG_RE.match(rest):
        print(__doc__)
        return 1
    slug = rest
    branch = prefix + "/" + rest
    ws = oc.load_ws(ROOT)
    if ws["mode"] != "local":
        print("This is for local-only projects. In cloud or local-github mode, merge the pull request on GitHub.")
        return 4
    if oc.main_root(ROOT) != os.path.realpath(ROOT):
        print("Run this from the main project folder, not from a worktree.")
        return 4
    cur = git("rev-parse", "--abbrev-ref", "HEAD").stdout.strip()
    base = next((c for c in ("main", "master") if git("rev-parse", "--verify", "--quiet", "refs/heads/" + c).returncode == 0), None)
    if cur != base:
        print("Switch to the %s branch first:  git switch %s" % (base, base))
        return 4
    if git("status", "--porcelain", "--untracked-files=no").stdout.strip():
        print("The folder has uncommitted changes. Commit or set them aside first.")
        return 4
    if git("rev-parse", "--verify", "--quiet", "refs/heads/" + branch).returncode != 0:
        print("No branch called %s on this computer." % branch)
        return 4
    log = git("log", "--oneline", "%s..%s" % (base, branch)).stdout.strip()
    print("About to merge %s into %s. Commits:\n%s\n" % (branch, base, log or "(none)"))
    if input("Type the feature name (%s) to confirm, anything else cancels: " % slug).strip() != slug:
        print("Cancelled. Nothing changed.")
        return 0
    p = git("merge", "--no-ff", branch, "-m", "Merge %s" % branch)
    print((p.stdout or p.stderr).strip())
    if p.returncode != 0:
        print("The merge stopped (probably a conflict). Fix it, or undo with:  git merge --abort")
        return 1
    print("\nRunning the project checks on the merged result...")
    rc = subprocess.run([sys.executable, "-I", os.path.join(HERE, "run_checks.py")], cwd=ROOT).returncode
    if rc != 0:
        print("\nChecks FAILED after the merge. To undo the merge:  git reset --hard HEAD~1")
        return 1
    print("\nMERGED and checks pass. When you are done with the feature's folder: python3 scripts/orchestration/worktree.py remove %s" % slug)
    return 0


if __name__ == "__main__":
    sys.exit(main())
