#!/usr/bin/env python3
"""Oneshot mode and run state. Standard library only.

A "oneshot" run builds a whole queue of features without stopping to ask. Questions, concerns and guesses are
parked (see park.py) and handled at the end. This script holds two things:

  MODE   (.claude/run-mode.json, git-ignored, expires on its own) tells the safety hooks to turn "ask the owner"
         into "blocked: park it and continue". The hooks never relax a hard block.
  STATE  (docs/oneshot/RUN.json, committed with every feature) lets a run be resumed from any session.

  oneshot.py mode show
  oneshot.py mode set oneshot --cap N --owner-answer "<the owner's answer, in their words>"
  oneshot.py mode end

  oneshot.py state init --features a,b,c --cap N [--run-id ID]
  oneshot.py state update <slug> <building|built|failed|skipped> [--branch B] [--pr URL] [--note TEXT]
  oneshot.py state next        prints "NEXT <slug> BASE <branch>" or "STOP: <reason>" or "DONE"
  oneshot.py state show [--find]   --find looks across all feature branches for the newest run state
  oneshot.py state finish --reason TEXT
  oneshot.py pause [SECONDS]   wait (at most 60 s) so pull requests are not opened in a burst

Agents may run `mode set` only AFTER the owner has said yes (AskUserQuestion); the owner's words are recorded.
This is a record, not a lock: see docs/orchestration/ONESHOT.md for what that means.
"""
import json
import os
import re
import subprocess
import sys
import time

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
MODE_FILE = os.path.join(ROOT, ".claude", "run-mode.json")
STATE_REL = os.path.join("docs", "oneshot", "RUN.json")
STATE_FILE = os.path.join(ROOT, STATE_REL)
SLUG_RE = re.compile(r"^[a-z0-9][a-z0-9-]{0,40}$")
MODE_HOURS = 12            # a oneshot mode left behind expires by itself
MAX_CAP = 40
STATUSES = ("pending", "building", "built", "failed", "skipped")


def now():
    return int(time.time())


def read_json(path):
    try:
        with open(path, "r", encoding="utf-8") as fh:
            return json.load(fh)
    except (OSError, ValueError):
        return None


def write_json(path, data):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as fh:
        json.dump(data, fh, indent=2)
        fh.write("\n")
    os.replace(tmp, path)


def git(*args):
    return subprocess.run(["git", "-C", ROOT] + list(args), capture_output=True, text=True, timeout=60)


def clean(text, limit=300):
    return re.sub(r"[\x00-\x1f\x7f]+", " ", str(text or "")).strip()[:limit]


# ---------------------------------------------------------------- mode
def active_mode():
    data = read_json(MODE_FILE) or {}
    if data.get("mode") == "oneshot" and now() < int(data.get("expires_at", 0)):
        return data
    return None


def refresh_mode():
    data = active_mode()
    if data:
        data["expires_at"] = now() + MODE_HOURS * 3600
        write_json(MODE_FILE, data)


def cmd_mode(args):
    if not args or args[0] not in ("show", "set", "end"):
        print(__doc__)
        return 1
    if args[0] == "show":
        data = active_mode()
        if data:
            left = (int(data["expires_at"]) - now()) // 60
            print("mode: ONESHOT (cap %s features; expires in %d min unless the run keeps going)" % (data.get("cap"), left))
            print("owner's answer on record: %s" % data.get("owner_answer", ""))
        else:
            print("mode: step-by-step (normal: the safety hooks ask the owner when a rule says so)")
        return 0
    if args[0] == "end":
        try:
            os.remove(MODE_FILE)
        except OSError:
            pass
        print("mode: step-by-step")
        return 0
    # set
    if len(args) < 2 or args[1] != "oneshot":
        print("usage: mode set oneshot --cap N --owner-answer \"...\"")
        return 1
    opts = parse_opts(args[2:], {"--cap": "cap", "--owner-answer": "owner_answer"})
    if opts is None:
        return 1
    answer = clean(opts.get("owner_answer"))
    if len(answer) < 3:
        print("REFUSED: oneshot needs the owner's explicit yes. Ask them (AskUserQuestion), then pass their answer "
              "with --owner-answer.")
        return 4
    try:
        cap = int(opts.get("cap", "12"))
    except ValueError:
        cap = 0
    if not 1 <= cap <= MAX_CAP:
        print("REFUSED: --cap must be between 1 and %d." % MAX_CAP)
        return 4
    write_json(MODE_FILE, {"mode": "oneshot", "cap": cap, "owner_answer": answer, "set_at": now(),
                           "expires_at": now() + MODE_HOURS * 3600})
    print("mode: ONESHOT, cap %d features. Hooks now block (instead of asking) and expect you to park questions. "
          "Hard blocks are unchanged." % cap)
    return 0


def parse_opts(args, allowed):
    out, i = {}, 0
    while i < len(args):
        key = args[i]
        if key not in allowed or i + 1 >= len(args):
            print("unknown or incomplete option: %s" % key)
            return None
        out[allowed[key]] = args[i + 1]
        i += 2
    return out


# ---------------------------------------------------------------- state
def load_state():
    return read_json(STATE_FILE)


def save_state(st):
    st["seq"] = int(st.get("seq", 0)) + 1
    st["updated"] = now()
    write_json(STATE_FILE, st)
    refresh_mode()


def cmd_state(args):
    if not args:
        print(__doc__)
        return 1
    sub, rest = args[0], args[1:]
    if sub == "init":
        opts = parse_opts(rest, {"--features": "features", "--cap": "cap", "--run-id": "run_id"})
        if opts is None:
            return 1
        slugs = [s.strip() for s in opts.get("features", "").split(",") if s.strip()]
        if not slugs or any(not SLUG_RE.match(s) for s in slugs) or len(set(slugs)) != len(slugs):
            print("REFUSED: --features must be unique slugs (lowercase letters, numbers, dashes), comma separated.")
            return 4
        try:
            cap = int(opts.get("cap", "12"))
        except ValueError:
            cap = 0
        if not 1 <= cap <= MAX_CAP:
            print("REFUSED: --cap must be between 1 and %d." % MAX_CAP)
            return 4
        if load_state() and not load_state().get("finished"):
            print("REFUSED: a run is already in progress here (docs/oneshot/RUN.json). Resume it, or finish it first.")
            return 4
        run_id = clean(opts.get("run_id")) or time.strftime("run-%Y%m%d-%H%M")
        st = {"run_id": run_id, "seq": 0, "cap": cap, "started": now(), "finished": None, "stop_reason": None,
              "order": slugs, "features": {s: {"status": "pending", "branch": None, "pr": None, "note": ""} for s in slugs}}
        save_state(st)
        print("RUN STARTED: %s, %d features, cap %d. State: docs/oneshot/RUN.json (commit it with each feature)." % (run_id, len(slugs), cap))
        return 0
    if sub == "update":
        if len(rest) < 2:
            print("usage: state update <slug> <status> [--branch B] [--pr URL] [--note TEXT]")
            return 1
        slug, status = rest[0], rest[1]
        opts = parse_opts(rest[2:], {"--branch": "branch", "--pr": "pr", "--note": "note"})
        st = load_state()
        if opts is None or not st or slug not in st["features"] or status not in STATUSES:
            print("REFUSED: unknown run, feature or status (%s)." % ", ".join(STATUSES))
            return 4
        f = st["features"][slug]
        f["status"] = status
        for k in ("branch", "pr", "note"):
            if k in opts:
                f[k] = clean(opts[k], 400)
        if status == "failed":
            f["failures"] = int(f.get("failures", 0)) + 1
        save_state(st)
        print("%s: %s" % (slug, status))
        return 0
    if sub == "finish":
        opts = parse_opts(rest, {"--reason": "reason"})
        st = load_state()
        if opts is None or not st:
            print("REFUSED: no run state here.")
            return 4
        st["finished"] = now()
        st["stop_reason"] = clean(opts.get("reason"), 400) or "finished"
        save_state(st)
        print("RUN FINISHED: %s" % st["stop_reason"])
        return 0
    if sub == "next":
        st = load_state()
        if not st:
            print("STOP: no run state here. Start with /oneshot, or resume with /oneshot-resume.")
            return 1
        feats = st["features"]
        built = [s for s in st["order"] if feats[s]["status"] == "built"]
        tip = feats[built[-1]]["branch"] if built else None
        resumable = [s for s in st["order"] if feats[s]["status"] == "building"]
        if resumable:
            print("NEXT %s BASE %s RESUME" % (resumable[0], (feats[resumable[0]].get("base") or tip or "default")))
            return 0
        streak = 0
        for f in reversed([feats[s] for s in st["order"] if feats[s]["status"] in ("built", "failed")]):
            if f["status"] == "failed":
                streak += 1
            else:
                break
        broken = [s for s in st["order"] if feats[s]["status"] == "failed" and int(feats[s].get("failures", 0)) >= 2]
        if broken:
            print("STOP: %s failed twice. Later features are stacked on it, so stop here and tell the owner; do not keep spending." % broken[0])
            return 1
        if streak >= 2:
            print("STOP: two features in a row failed. Stop here and tell the owner; do not keep spending.")
            return 1
        if len([s for s in built if s != "oneshot-plan"]) >= int(st["cap"]):
            print("STOP: the cap of %d features is reached." % st["cap"])
            return 1
        for s in st["order"]:
            if feats[s]["status"] in ("pending", "failed"):
                print("NEXT %s BASE %s" % (s, tip or "default"))
                return 0
        print("DONE")
        return 0
    if sub == "show":
        return show_state("--find" in rest)
    print(__doc__)
    return 1


def show_state(find):
    st, where = load_state(), "this branch"
    if find:
        best = (-1, None, None)
        refs = git("for-each-ref", "--format=%(refname:short)", "refs/heads/feature", "refs/remotes/origin/feature").stdout.split()
        for ref in refs:
            p = git("show", "%s:%s" % (ref, STATE_REL.replace(os.sep, "/")))
            if p.returncode != 0:
                continue
            try:
                data = json.loads(p.stdout)
            except ValueError:
                continue
            if int(data.get("seq", 0)) > best[0]:
                best = (int(data.get("seq", 0)), ref, data)
        if best[2] is not None and (st is None or best[0] > int(st.get("seq", 0))):
            st, where = best[2], best[1]
    if not st:
        print("No oneshot run found.")
        return 1
    print("run %s (state from %s): %s" % (st["run_id"], where, "FINISHED: " + str(st.get("stop_reason")) if st.get("finished") else "in progress"))
    built = [s for s in st["order"] if st["features"][s]["status"] == "built"]
    for i, s in enumerate(st["order"], 1):
        f = st["features"][s]
        print("%3d. %-28s %-9s %s %s" % (i, s, f["status"], f.get("branch") or "", f.get("pr") or ""))
    if built:
        print("TIP %s" % st["features"][built[-1]]["branch"])
    return 0


def cmd_pause(args):
    try:
        secs = int(args[0]) if args else 20
    except ValueError:
        secs = 20
    secs = max(1, min(secs, 60))
    time.sleep(secs)
    refresh_mode()
    print("waited %d s" % secs)
    return 0


def main():
    if len(sys.argv) < 2 or sys.argv[1] not in ("mode", "state", "pause"):
        print(__doc__)
        return 1
    return {"mode": cmd_mode, "state": cmd_state, "pause": cmd_pause}[sys.argv[1]](sys.argv[2:])


if __name__ == "__main__":
    sys.exit(main())
