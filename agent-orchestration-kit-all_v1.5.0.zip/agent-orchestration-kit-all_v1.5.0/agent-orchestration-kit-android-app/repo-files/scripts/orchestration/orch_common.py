#!/usr/bin/env python3
"""Shared helpers for the orchestration scripts (modes, session list, push lock). Standard library only.

Modes (set once per computer by the owner with set_workspace.py, stored in .claude/workspace.local.json):
  cloud         no file: every feature runs in its own cloud session; nothing here changes.
  local         work on your own computer, no GitHub: branches and worktrees stay on this computer.
  local-github  work on your own computer and push/pull the latest changes to GitHub.

Shared state for all sessions on this computer lives in <git common dir>/orchestration/ (git never commits it):
  sessions/<slug>.json  who is working on what (and where), with a heartbeat
  slots.json            which port block each worktree uses
  push.lock/            a lock so only one session pushes at a time
  last_push             when the last push finished (so pushes are spaced out)
"""
import json
import os
import re
import subprocess
import sys
import time

SLUG_RE = re.compile(r"^[a-z0-9][a-z0-9-]{1,40}$")
WORKSPACE_FILE = "workspace.local.json"
DEFAULTS = {"mode": "cloud", "max_sessions": 2, "push_gap_seconds": 15, "stale_hours": 12, "scope": "workspace",
            "tools_dir": "tools", "extra_allowed_write": []}


def git(cwd, *args, timeout=180):
    return subprocess.run(["git", "-C", cwd] + list(args), capture_output=True, text=True, timeout=timeout)


def common_dir(cwd):
    p = git(cwd, "rev-parse", "--git-common-dir")
    out = p.stdout.strip() if p.returncode == 0 else ""
    if not out:
        return ""
    return os.path.realpath(out if os.path.isabs(out) else os.path.join(cwd, out))


def main_root(cwd):
    c = common_dir(cwd)
    if c and os.path.basename(c) == ".git":
        return os.path.dirname(c)
    return os.path.realpath(cwd)


def load_ws(cwd):
    """Settings for this computer. mode is 'cloud' when no workspace file exists."""
    ws = dict(DEFAULTS)
    main = main_root(cwd)
    ws["_main"] = main
    path = os.path.join(main, ".claude", WORKSPACE_FILE)
    try:
        with open(path, "r", encoding="utf-8") as fh:
            ws.update(json.load(fh))
    except (OSError, ValueError):
        ws["mode"] = "cloud"
        return ws
    if ws.get("mode") not in ("local", "local-github"):
        ws["mode"] = "cloud"
        return ws
    ws["workspace_root"] = os.path.realpath(os.path.expanduser(ws.get("workspace_root", "")))
    return ws


def is_local(ws):
    return ws.get("mode") in ("local", "local-github")


def tools_path(ws):
    return os.path.realpath(os.path.join(ws["workspace_root"], ws.get("tools_dir") or "tools"))


def worktrees_base(ws):
    main = ws["_main"]
    return os.path.realpath(os.path.join(os.path.dirname(main), os.path.basename(main) + "-worktrees"))


def state_dir(cwd):
    d = os.path.join(common_dir(cwd) or os.path.join(cwd, ".git"), "orchestration")
    os.makedirs(os.path.join(d, "sessions"), exist_ok=True)
    return d


class DirLock:
    """A lock that works on Windows, macOS and Linux: creating a folder succeeds for only one process."""

    def __init__(self, path, timeout=900, stale=300):
        self.path, self.timeout, self.stale = path, timeout, stale

    def __enter__(self):
        start = time.time()
        announced = False
        while True:
            try:
                os.mkdir(self.path)
                with open(os.path.join(self.path, "owner"), "w") as fh:
                    fh.write(str(os.getpid()))
                return self
            except FileExistsError:
                try:
                    age = time.time() - os.path.getmtime(self.path)
                except OSError:
                    continue
                if age > self.stale:
                    self._break()
                    continue
                if time.time() - start > self.timeout:
                    raise TimeoutError("another session has held the lock %s for over %d seconds" % (self.path, self.timeout))
                if not announced:
                    print("Another session is pushing right now. Waiting for its turn...")
                    announced = True
                time.sleep(2)

    def _break(self):
        try:
            for f in os.listdir(self.path):
                os.remove(os.path.join(self.path, f))
            os.rmdir(self.path)
        except OSError:
            pass

    def __exit__(self, *exc):
        self._break()


def wait_for_gap(state, gap):
    """Space out pushes: wait until `gap` seconds have passed since the last push finished."""
    f = os.path.join(state, "last_push")
    try:
        last = float(open(f).read().strip())
    except (OSError, ValueError):
        return
    wait = last + gap - time.time()
    if wait > 0:
        print("Pausing %d seconds so pushes to GitHub are spaced out." % int(wait + 0.5))
        time.sleep(wait)


def mark_push(state):
    try:
        with open(os.path.join(state, "last_push"), "w") as fh:
            fh.write(str(time.time()))
    except OSError:
        pass


# ----- sessions registry ---------------------------------------------------------------------------------
def _sess_path(state, slug):
    return os.path.join(state, "sessions", slug + ".json")


def register_session(state, slug, branch, path, mode):
    now = time.time()
    data = {"slug": slug, "branch": branch, "path": path, "mode": mode, "started": now, "heartbeat": now}
    old = read_session(state, slug)
    if old:
        data["started"] = old.get("started", now)
    with open(_sess_path(state, slug), "w", encoding="utf-8") as fh:
        json.dump(data, fh)


def read_session(state, slug):
    try:
        with open(_sess_path(state, slug), "r", encoding="utf-8") as fh:
            return json.load(fh)
    except (OSError, ValueError):
        return None


def touch_session(state, slug):
    data = read_session(state, slug)
    if data:
        data["heartbeat"] = time.time()
        with open(_sess_path(state, slug), "w", encoding="utf-8") as fh:
            json.dump(data, fh)


def release_session(state, slug):
    try:
        os.remove(_sess_path(state, slug))
        return True
    except OSError:
        return False


def active_sessions(state, stale_hours):
    out = []
    d = os.path.join(state, "sessions")
    for name in sorted(os.listdir(d)) if os.path.isdir(d) else []:
        if not name.endswith(".json"):
            continue
        data = read_session(state, name[:-5])
        if data and time.time() - data.get("heartbeat", 0) < stale_hours * 3600:
            out.append(data)
    return out


def age_text(ts):
    mins = int((time.time() - ts) / 60)
    return "%d min ago" % mins if mins < 120 else "%d hours ago" % (mins // 60)


# ----- port slots ----------------------------------------------------------------------------------------
def _slots_path(state):
    return os.path.join(state, "slots.json")


def read_slots(state):
    try:
        with open(_slots_path(state), "r", encoding="utf-8") as fh:
            return json.load(fh)
    except (OSError, ValueError):
        return {}


def assign_slot(state, slug):
    slots = read_slots(state)
    if slug in slots:
        return slots[slug]
    used = set(slots.values())
    n = next(i for i in range(1, 60) if i not in used)
    slots[slug] = n
    with open(_slots_path(state), "w", encoding="utf-8") as fh:
        json.dump(slots, fh)
    return n


def release_slot(state, slug):
    slots = read_slots(state)
    if slug in slots:
        del slots[slug]
        with open(_slots_path(state), "w", encoding="utf-8") as fh:
            json.dump(slots, fh)


def ports_for(slot):
    """Each worktree gets its own block of 10 ports so dev servers never collide. Slot 0 = the main folder."""
    if slot == 0:
        return {"web dev server": 3000, "vite": 5173, "expo / metro": 8081, "api / backend": 3001, "second server": 3002}
    base = 4000 + slot * 10
    return {"web dev server": base, "second server / preview": base + 1, "expo / metro": base + 2, "api / backend": base + 3,
            "debugger": base + 4}
