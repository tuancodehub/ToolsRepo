#!/usr/bin/env python3
"""OWNER-ONLY: tell the kit how and where you work on this computer. Standard library only.

You run this yourself, in your own terminal (or with the ! prefix inside Claude). Agents are blocked from running it,
because it decides which folders they may change.

  set_workspace.py --mode local-github --root ~/Workspace          local files + GitHub push/pull
  set_workspace.py --mode local        --root ~/Workspace          local files only, no GitHub
  set_workspace.py --mode cloud                                    back to cloud-only (removes the local file)
  set_workspace.py --show | --check                                look at the current settings (safe for anyone)

Options: --os auto|windows|macos|linux   --scope workspace|project   --max-sessions N   --push-gap SECONDS
         --extra-write FOLDER (repeatable)   --create (make the workspace folder if missing)

The settings are saved in <project>/.claude/workspace.local.json, which is git-ignored: every computer has its own.
Layout it expects (your project must be inside the workspace folder):
    ~/Workspace/               <- --root: the only place agents may change files (plus the temp folder)
        tools/                 <- shared tools and Python virtual environments for all projects
        MyProject/             <- this project
        MyProject-worktrees/   <- extra folders for parallel sessions (made by worktree.py)
"""
import argparse
import datetime
import json
import os
import platform
import shutil
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(os.path.dirname(HERE))
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(ROOT, ".claude", "hooks"))
import orch_common as oc  # noqa: E402
from _common import critical_kind, pkey, within  # noqa: E402


def detect_os():
    s = sys.platform
    if s.startswith("win"):
        return "windows"
    if s == "darwin":
        return "macos"
    return "linux"


def problems_for_root(root, main):
    out = []
    ck = critical_kind(root)
    if ck:
        out.append("%s is %s. Choose a normal work folder such as ~/Workspace." % (root, ck[1]))
    home = os.path.realpath(os.path.expanduser("~"))
    if pkey(root) == pkey(home):
        out.append("Your whole home folder is too wide. Make a folder such as ~/Workspace and use that.")
    if os.path.dirname(root) == root:
        out.append("The top of a drive is too wide.")
    if not within(main, root):
        out.append("This project (%s) is not inside %s. Move the project into the workspace folder, or choose the folder that contains it." % (main, root))
    return out


def cmd_show():
    ws = oc.load_ws(ROOT)
    print("mode: %s" % ws["mode"])
    if oc.is_local(ws):
        print("computer type: %s" % ws.get("os", "?"))
        print("workspace folder (agents may change files only here, plus temp): %s" % ws["workspace_root"])
        print("scope: %s" % ws.get("scope", "workspace"))
        print("tools folder: %s" % oc.tools_path(ws))
        print("worktrees folder: %s" % oc.worktrees_base(ws))
        print("limits: %s sessions at once, %s s between pushes" % (ws.get("max_sessions"), ws.get("push_gap_seconds")))
        for x in ws.get("extra_allowed_write", []):
            print("extra allowed folder: %s" % x)
    return ws


def cmd_check():
    ws = cmd_show()
    bad = 0
    if oc.is_local(ws):
        root = ws["workspace_root"]
        for label, path in (("workspace folder", root), ("tools folder", oc.tools_path(ws)), ("worktrees folder", oc.worktrees_base(ws))):
            ok = os.path.isdir(path)
            print("%-17s %s %s" % (label, "ok" if ok else "MISSING", path))
            bad += 0 if ok else 1
        for p in problems_for_root(root, ws["_main"]):
            print("PROBLEM:", p)
            bad += 1
        if ws["mode"] == "local-github":
            has_remote = oc.git(ROOT, "remote").stdout.strip()
            print("git remote: %s" % (has_remote or "NONE (add one: git remote add origin <url>)"))
            bad += 0 if has_remote else 1
            print("gh (GitHub command line): %s" % ("found" if shutil.which("gh") else "not found (needed only to open pull requests from here)"))
    for tool in ("git", "python3" if detect_os() != "windows" else "python"):
        print("%-17s %s" % (tool, "found" if shutil.which(tool) else "NOT FOUND"))
        bad += 0 if shutil.which(tool) else 1
    if detect_os() == "windows":
        print("note: on Windows, run Claude Code from Git Bash or WSL so the safety hooks can start (see docs/orchestration/LOCAL-MODE.md).")
    print("RESULT: %s" % ("OK" if not bad else "%d thing(s) need attention" % bad))
    return 0 if not bad else 1


def main():
    ap = argparse.ArgumentParser(add_help=True)
    ap.add_argument("--mode", choices=["cloud", "local", "local-github"])
    ap.add_argument("--root")
    ap.add_argument("--os", dest="os_name", default="auto", choices=["auto", "windows", "macos", "linux"])
    ap.add_argument("--scope", default="workspace", choices=["workspace", "project"])
    ap.add_argument("--max-sessions", type=int, default=2)
    ap.add_argument("--push-gap", type=int, default=15)
    ap.add_argument("--extra-write", action="append", default=[])
    ap.add_argument("--create", action="store_true")
    ap.add_argument("--show", action="store_true")
    ap.add_argument("--check", action="store_true")
    a = ap.parse_args()
    if a.show:
        cmd_show()
        return 0
    if a.check:
        return cmd_check()
    if not a.mode:
        print(__doc__)
        return 1
    main_dir = oc.main_root(ROOT)
    target = os.path.join(main_dir, ".claude", oc.WORKSPACE_FILE)
    if a.mode == "cloud":
        if os.path.exists(target):
            os.remove(target)
        print("Cloud mode: the local settings file was removed. Nothing else changed.")
        return 0
    if not a.root:
        print("--root is required: the folder that holds your projects, for example ~/Workspace")
        return 2
    root = os.path.realpath(os.path.expanduser(a.root))
    if not os.path.isdir(root):
        if a.create:
            os.makedirs(root)
        else:
            print("The workspace folder %s does not exist. Create it first, or add --create." % root)
            return 2
    probs = problems_for_root(root, main_dir)
    if probs:
        for p in probs:
            print("REFUSED:", p)
        return 2
    extra = []
    for x in a.extra_write:
        xr = os.path.realpath(os.path.expanduser(x))
        if critical_kind(xr):
            print("REFUSED: extra folder %s is a system or home folder." % xr)
            return 2
        extra.append(xr)
    data = {"mode": a.mode, "os": detect_os() if a.os_name == "auto" else a.os_name, "workspace_root": root,
            "tools_dir": "tools", "scope": a.scope, "max_sessions": max(1, min(a.max_sessions, 4)),
            "push_gap_seconds": max(5, a.push_gap), "stale_hours": 12, "extra_allowed_write": extra,
            "saved": datetime.date.today().isoformat(), "machine": platform.node() and "this computer"}
    os.makedirs(os.path.dirname(target), exist_ok=True)
    with open(target, "w", encoding="utf-8") as fh:
        json.dump(data, fh, indent=2)
        fh.write("\n")
    os.makedirs(os.path.join(root, "tools", "venvs"), exist_ok=True)
    os.makedirs(os.path.join(root, "tools", "bin"), exist_ok=True)
    wt = oc.worktrees_base(oc.load_ws(ROOT))
    os.makedirs(wt, exist_ok=True)
    gi = os.path.join(main_dir, ".gitignore")
    try:
        text = open(gi, "r", encoding="utf-8").read() if os.path.exists(gi) else ""
        if oc.WORKSPACE_FILE not in text:
            with open(gi, "a", encoding="utf-8") as fh:
                fh.write(("\n" if text and not text.endswith("\n") else "") + ".claude/" + oc.WORKSPACE_FILE + "\n")
    except OSError:
        pass
    print("SAVED (%s). Agents may now change files only inside: %s (and the temp folder)." % (a.mode, root))
    print("Tools folder: %s   Worktrees folder: %s" % (os.path.join(root, "tools"), wt))
    print("Start a NEW Claude session so the new rules apply, then run /smoke-test.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
