#!/usr/bin/env python3
"""Decide which reviewers a change needs, from the files it touches (saves tokens on small changes).

Reads .claude/areas.json (globs for: docs_only, ui, copy, security_sensitive, deps).
Prints, for example:
  changed_files: 7
  areas: ui, security_sensitive
  reviewers: quality, ux, security
Rules: docs-only -> no reviewers. Otherwise quality always; ux if ui or copy changed;
security if anything non-docs changed (always for security_sensitive or deps).
"""
import json
import os
import re
import subprocess
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


def glob_to_regex(pat):
    i, out = 0, []
    while i < len(pat):
        c = pat[i]
        if c == "*":
            if pat[i:i + 3] == "**/":
                out.append("(?:.*/)?")
                i += 3
                continue
            if pat[i:i + 2] == "**":
                out.append(".*")
                i += 2
                continue
            out.append("[^/]*")
        elif c == "?":
            out.append("[^/]")
        else:
            out.append(re.escape(c))
        i += 1
    return re.compile("^" + "".join(out) + "$")


def sh(*args):
    p = subprocess.run(["git", "-C", ROOT] + list(args), capture_output=True, text=True)
    return p.stdout if p.returncode == 0 else ""


def changed_files():
    base = None
    for cand in ("origin/main", "origin/master"):
        if sh("rev-parse", "--verify", "--quiet", cand).strip():
            base = cand
            break
    files = set()
    if base:
        files |= set(sh("diff", "--name-only", base + "...HEAD").split())
    files |= set(sh("diff", "--name-only", "HEAD").split())
    files |= {l[3:].strip() for l in sh("status", "--porcelain").splitlines() if l[3:].strip()}
    return sorted(f for f in files if f)


def main():
    try:
        with open(os.path.join(ROOT, ".claude", "areas.json"), "r", encoding="utf-8") as fh:
            areas = json.load(fh)
    except (OSError, ValueError) as exc:
        print("areas.json unreadable (%s). Run all reviewers." % exc)
        print("reviewers: quality, ux, security")
        return 0
    files = changed_files()
    compiled = {k: [glob_to_regex(p) for p in v] for k, v in areas.items() if isinstance(v, list)}

    def hit(area, f):
        return any(r.match(f) for r in compiled.get(area, []))

    found = {a for a in compiled for f in files if hit(a, f)}
    non_docs = [f for f in files if not hit("docs_only", f)]
    print("changed_files: %d" % len(files))
    print("areas: %s" % (", ".join(sorted(found - {"docs_only"})) or "none"))
    if not files or not non_docs:
        print("reviewers: none (nothing but docs/content changed)")
        return 0
    reviewers = ["quality"]
    if "ui" in found or "copy" in found:
        reviewers.append("ux")
    reviewers.append("security")
    print("reviewers: " + ", ".join(reviewers))
    return 0


if __name__ == "__main__":
    sys.exit(main())
