#!/usr/bin/env python3
"""Show or change the model of each agent and command.

  set_models.py --show
  set_models.py --set builder=sonnet planner=opus
Allowed values: opus, sonnet, haiku, inherit, or a full model ID such as claude-opus-5-5.
These files are protected: Claude will ask the owner to approve the edit.
"""
import os
import re
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
DIRS = [os.path.join(ROOT, ".claude", "agents"), os.path.join(ROOT, ".claude", "commands")]
VALUE_RE = re.compile(r"^(opus|sonnet|haiku|inherit|claude-[a-z0-9.\-]+)$")


def files():
    out = {}
    for d in DIRS:
        for name in sorted(os.listdir(d)) if os.path.isdir(d) else []:
            if name.endswith(".md"):
                out[name[:-3]] = os.path.join(d, name)
    return out


def current(path):
    m = re.search(r"(?m)^model:\s*(\S+)", open(path, "r", encoding="utf-8").read().split("\n---", 2)[0])
    return m.group(1) if m else "(none)"


def main():
    fs = files()
    if "--show" in sys.argv or len(sys.argv) == 1:
        for name, path in fs.items():
            kind = "agent  " if "/agents/" in path else "command"
            print("%s %-18s %s" % (kind, name, current(path)))
        return 0
    if "--set" in sys.argv:
        pairs = sys.argv[sys.argv.index("--set") + 1:]
        for pair in pairs:
            if "=" not in pair:
                print("bad pair:", pair)
                return 1
            name, value = pair.split("=", 1)
            if name not in fs or not VALUE_RE.match(value):
                print("unknown name or value:", pair)
                return 1
            text = open(fs[name], "r", encoding="utf-8").read()
            head, sep, body = text.partition("\n---\n")
            new_head, n = re.subn(r"(?m)^model:.*$", "model: " + value, head, count=1)
            if n == 0:
                print("no model line in", name)
                return 1
            open(fs[name], "w", encoding="utf-8").write(new_head + sep + body)
            print("%s -> %s" % (name, value))
        return 0
    print(__doc__)
    return 1


if __name__ == "__main__":
    sys.exit(main())
