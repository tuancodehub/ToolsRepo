#!/usr/bin/env python3
"""The ONLY approved way for agents to claim a feature and push. Standard library only.

  feature_git.py claim <slug>    claim a feature: refuse if someone else already has it, create feature/<slug>
                                 from the default branch, add the brief (and push, unless local-only).
  feature_git.py claim <slug> --base feature/<other>
                                 (oneshot) start from another feature's branch instead of the default branch, so
                                 features are stacked: each pull request then shows only its own changes.
  feature_git.py pr-base         print the branch the current feature's pull request should target.
  feature_git.py resume <slug>   continue a feature whose earlier session died (owner confirms it is dead).
  feature_git.py push            push the current feature branch (never a protected branch).
  feature_git.py status          branch, remote state, sessions on this computer.
  feature_git.py sessions        list the sessions working on this computer.
  feature_git.py release <slug>  free a session slot (owner: use when a session was closed without finishing).
  feature_git.py overlap         local modes: do my files overlap with another running session's?

Three modes (see orch_common.py): cloud, local, local-github.
- cloud:         the claim is visible to every other session the moment it is pushed.
- local:         no GitHub. Branches and sessions are tracked on this computer only; push does nothing.
- local-github:  as cloud, plus: only `max_sessions` sessions at once; pushes take turns through a lock and are
                 spaced `push_gap_seconds` apart, so several sessions never hit GitHub's limits.

Exit codes: 0 ok, 3 already claimed, 4 refused (unsafe branch, bad slug, dirty folder), 5 session limit,
6 overlapping files, 1 other failure.
"""
import datetime
import fnmatch
import json
import os
import re
import subprocess
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import orch_common as oc  # noqa: E402

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
SLUG_RE = oc.SLUG_RE
ALLOWED_PREFIXES = ("feature/", "fix/", "chore/", "docs/")
DEFAULT_PROTECTED = ["main", "master", "production", "prod", "develop", "release", "release/*"]
RATE_LIMIT_HINTS = ("429", "too many", "concurrent", "rate limit", "secondary rate", "abuse")
WS = oc.load_ws(ROOT)
MODE = WS["mode"]


def git(*args, check=False, timeout=180):
    p = subprocess.run(["git", "-C", ROOT] + list(args), capture_output=True, text=True, timeout=timeout)
    if check and p.returncode != 0:
        raise RuntimeError("git %s failed: %s" % (" ".join(args), (p.stderr or p.stdout).strip()))
    return p


def protected_branches():
    try:
        with open(os.path.join(ROOT, ".claude", "guard-config.json"), "r", encoding="utf-8") as fh:
            return json.load(fh).get("protected_branches", DEFAULT_PROTECTED)
    except (OSError, ValueError):
        return DEFAULT_PROTECTED


def is_protected(name):
    return any(fnmatch.fnmatchcase(name, p) for p in protected_branches())


def default_branch():
    p = git("symbolic-ref", "--short", "refs/remotes/origin/HEAD")
    if p.returncode == 0 and p.stdout.strip():
        return p.stdout.strip().split("/", 1)[1]
    if MODE == "local":
        for cand in ("main", "master"):
            if git("rev-parse", "--verify", "--quiet", "refs/heads/" + cand).returncode == 0:
                return cand
        return "main"
    for cand in ("main", "master"):
        if git("ls-remote", "--exit-code", "--heads", "origin", cand).returncode == 0:
            return cand
    return "main"


def state():
    return oc.state_dir(ROOT)


def push_with_retry(branch):
    """cloud: retry once after 6 s. local-github: take the lock, space pushes out, retry once after 30 s."""
    if MODE == "local-github":
        st = state()
        try:
            with oc.DirLock(os.path.join(st, "push.lock")):
                oc.wait_for_gap(st, int(WS.get("push_gap_seconds", 15)))
                ok = _push_once(branch, wait=30)
                oc.mark_push(st)
                return ok
        except TimeoutError as exc:
            print("PUSH FAILED:", exc, "Run 'feature_git.py sessions' and ask the owner if another session is stuck.")
            return False
    return _push_once(branch, wait=6)


def _push_once(branch, wait):
    for attempt in (1, 2):
        p = git("-c", "push.negotiate=true", "push", "-u", "origin", branch)
        text = (p.stderr + p.stdout).lower()
        if p.returncode == 0:   # "push negotiation failed" is only a warning from git, not a failed push
            return True
        if attempt == 1 and any(h in text for h in RATE_LIMIT_HINTS):
            print("Push was rate-limited. Waiting %d seconds and trying exactly once more." % wait)
            time.sleep(wait)
            continue
        print("PUSH FAILED:\n" + (p.stderr or p.stdout).strip())
        return False
    return False


def ensure_identity():
    if not git("config", "user.email").stdout.strip():
        git("config", "user.email", "agent@users.noreply.invalid")
    if not git("config", "user.name").stdout.strip():
        git("config", "user.name", "Claude agent")


def session_cap_problem(slug):
    """Local modes: at most max_sessions sessions at once on this computer."""
    # One folder runs one feature at a time: a session moving on to its next feature in this same folder (after
    # /clear) is finished with the previous one, so that one does not count against the limit.
    others = [s for s in oc.active_sessions(state(), WS["stale_hours"]) if s["slug"] != slug
              and os.path.realpath(s.get("path", "")) != os.path.realpath(ROOT)]
    if len(others) >= int(WS.get("max_sessions", 2)):
        print("SESSION LIMIT: %d sessions are already running on this computer (limit %d):" % (len(others), WS["max_sessions"]))
        for s in others:
            print("  - %s in %s (last activity %s)" % (s["slug"], s["path"], oc.age_text(s["heartbeat"])))
        print("Finish one first. If one of them is really finished or was closed, the owner can free its slot with: "
              "python3 -I scripts/orchestration/feature_git.py release <slug>")
        return True
    return False


def set_front_field(text, key, value):
    """Set (or add) one `key: value` line in the front matter of a brief."""
    m = re.match(r"^---\n(.*?)\n---", text, re.S)
    if not m:
        return text
    head = m.group(1)
    line = "%s: %s" % (key, value) if value else "%s:" % key
    if re.search(r"(?m)^%s:" % re.escape(key), head):
        head = re.sub(r"(?m)^%s:.*$" % re.escape(key), lambda _m: line, head, count=1)
    else:
        head += "\n" + line
    return "---\n" + head + "\n---" + text[m.end():]


BASE_RE = re.compile(r"^feature/[a-z0-9][a-z0-9-]{0,40}$")


def write_brief(slug, base=None):
    brief = os.path.join(ROOT, "docs", "briefs", slug + ".md")
    today = datetime.date.today().isoformat()
    if os.path.exists(brief):
        with open(brief, "r", encoding="utf-8") as fh:
            text = fh.read()
        text = re.sub(r"(?m)^status:.*$", "status: claimed", text, count=1)
        text = re.sub(r"(?m)^updated:.*$", "updated: " + today, text, count=1)
        text = set_front_field(text, "base", base or "")
    else:
        with open(os.path.join(ROOT, "docs", "briefs", "_TEMPLATE.md"), "r", encoding="utf-8") as fh:
            text = fh.read().replace("{{SLUG}}", slug).replace("{{DATE}}", today)
        text = set_front_field(text, "base", base or "")
        os.makedirs(os.path.dirname(brief), exist_ok=True)
    with open(brief, "w", encoding="utf-8") as fh:
        fh.write(text)
    return brief


def cmd_claim(slug, base_branch=None):
    if not SLUG_RE.match(slug):
        print("REFUSED: slug must be lowercase letters, numbers and dashes (2-41 characters).")
        return 4
    if base_branch is not None and not BASE_RE.match(base_branch):
        print("REFUSED: --base must be another feature branch such as feature/<slug>.")
        return 4
    branch = "feature/" + slug
    local = MODE in ("local", "local-github")
    lock = oc.DirLock(os.path.join(state(), "claim.lock"), timeout=60, stale=120) if local else None
    if lock:
        lock.__enter__()
    try:
        if local:
            if session_cap_problem(slug):
                return 5
            if oc.read_session(state(), slug) and git("rev-parse", "--verify", "--quiet", "refs/heads/" + branch).returncode == 0 \
                    and (oc.read_session(state(), slug) or {}).get("path") != ROOT:
                print("ALREADY CLAIMED: another session on this computer is working on %s." % branch)
                return 3
            if git("status", "--porcelain", "--untracked-files=no").stdout.strip():
                print("REFUSED: this folder has uncommitted changes. Commit or set them aside first, then claim again.")
                return 4
        if MODE in ("cloud", "local-github"):
            if git("ls-remote", "--exit-code", "--heads", "origin", "refs/heads/" + branch).returncode == 0:
                print("ALREADY CLAIMED: branch %s exists on the remote. Another session or device is working on it. "
                      "Pick another feature, or ask the owner." % branch)
                return 3
        base = base_branch or default_branch()
        if base_branch and MODE == "local" and git("rev-parse", "--verify", "--quiet", "refs/heads/" + base).returncode != 0:
            print("REFUSED: the base branch %s does not exist on this computer." % base)
            return 4
        if MODE == "cloud":
            if git("fetch", "--depth=1", "origin", base).returncode != 0:
                print("REFUSED: could not fetch %s from GitHub. Has the earlier feature been pushed?" % base)
                return 4
            start = "origin/" + base
        elif MODE == "local-github":
            if git("fetch", "origin", base).returncode != 0:     # a normal fetch: never turns a full clone into a shallow one
                print("REFUSED: could not fetch %s from GitHub. Has the earlier feature been pushed?" % base)
                return 4
            start = "origin/" + base
        else:
            start = base
        if git("rev-parse", "--verify", "--quiet", "refs/heads/" + branch).returncode == 0:
            print("ALREADY CLAIMED: a local branch %s already exists on this computer. Use 'resume %s' if it is yours, "
                  "or ask the owner." % (branch, slug))
            return 3 if local else 4
        git("checkout", "-b", branch, start, check=True)
        brief = write_brief(slug, base_branch)
        ensure_identity()
        git("add", "--", os.path.relpath(brief, ROOT), check=True)
        git("commit", "-m", "chore(%s): claim feature" % slug, check=True)
        if MODE != "local":
            if not push_with_retry(branch):
                return 1
        if local:
            for prev in oc.active_sessions(state(), WS["stale_hours"]):      # only now that the claim succeeded
                if prev["slug"] != slug and os.path.realpath(prev.get("path", "")) == os.path.realpath(ROOT):
                    oc.release_session(state(), prev["slug"])
            oc.register_session(state(), slug, branch, ROOT, MODE)
        print("CLAIMED: %s is yours%s. Brief: docs/briefs/%s.md" % (branch, " (local only, not pushed)" if MODE == "local" else "", slug))
        return 0
    finally:
        if lock:
            lock.__exit__()


def cmd_resume(slug):
    if not SLUG_RE.match(slug):
        print("REFUSED: bad slug.")
        return 4
    branch = "feature/" + slug
    local = MODE in ("local", "local-github")
    if local and session_cap_problem(slug):
        return 5
    if MODE in ("cloud", "local-github"):
        if git("ls-remote", "--exit-code", "--heads", "origin", "refs/heads/" + branch).returncode != 0 and \
                git("rev-parse", "--verify", "--quiet", "refs/heads/" + branch).returncode != 0:
            print("NOTHING TO RESUME: %s is not on the remote or this computer. Use claim instead." % branch)
            return 1
        depth = ["--depth=50"] if MODE == "cloud" else []
        git("fetch", *depth, "origin", "%s:refs/remotes/origin/%s" % (branch, branch))
    elif git("rev-parse", "--verify", "--quiet", "refs/heads/" + branch).returncode != 0:
        print("NOTHING TO RESUME: %s does not exist on this computer. Use claim instead." % branch)
        return 1
    if git("rev-parse", "--verify", "--quiet", "refs/heads/" + branch).returncode == 0:
        p = git("checkout", branch)
        if p.returncode != 0:
            print("REFUSED:", (p.stderr or p.stdout).strip(), "(a branch can be checked out in only one folder at a time)")
            return 4
        if MODE != "local":
            git("merge", "--ff-only", "origin/" + branch)
    else:
        git("checkout", "-b", branch, "--track", "origin/" + branch, check=True)
    if local:
        oc.register_session(state(), slug, branch, ROOT, MODE)
    print("RESUMED: %s at %s. Only resume if you are sure no other session is still working on it." %
          (branch, git("rev-parse", "--short", "HEAD").stdout.strip()))
    return 0


def current_slug():
    b = git("rev-parse", "--abbrev-ref", "HEAD").stdout.strip()
    return b.split("/", 1)[1] if "/" in b else b


def cmd_push():
    branch = git("rev-parse", "--abbrev-ref", "HEAD").stdout.strip()
    if not branch or branch == "HEAD" or is_protected(branch) or not branch.startswith(ALLOWED_PREFIXES):
        print("REFUSED: '%s' is not a work branch (allowed prefixes: %s)." % (branch, ", ".join(ALLOWED_PREFIXES)))
        return 4
    if MODE in ("local", "local-github"):
        oc.touch_session(state(), current_slug())
    if MODE == "local":
        print("LOCAL MODE: nothing to push. Your commits are saved on this computer. "
              "When you approve the feature, you merge it with local_merge.py.")
        return 0
    if not push_with_retry(branch):
        return 1
    print("PUSHED: %s at %s" % (branch, git("rev-parse", "--short", "HEAD").stdout.strip()))
    return 0


def cmd_pr_base():
    """The branch this feature's pull request should target: its `base:` field, else the default branch."""
    slug = current_slug()
    path = os.path.join(ROOT, "docs", "briefs", slug + ".md")
    try:
        text = open(path, "r", encoding="utf-8").read()
    except OSError:
        text = ""
    m = re.search(r"(?m)^base:[ \t]*(\S+)", text)
    print(m.group(1) if m and BASE_RE.match(m.group(1)) else default_branch())
    return 0


def cmd_status():
    branch = git("rev-parse", "--abbrev-ref", "HEAD").stdout.strip()
    print("mode:", MODE)
    print("branch:", branch, "(protected)" if is_protected(branch) else "")
    if MODE != "local":
        remote = git("ls-remote", "--heads", "origin", "refs/heads/" + branch).stdout.strip()
        print("on remote:", "yes" if remote else "no")
    print(git("status", "--short", "--branch").stdout.strip())
    if MODE != "cloud":
        cmd_sessions()
    return 0


def cmd_sessions():
    if MODE == "cloud":
        print("Cloud mode: each feature runs in its own cloud session; there is no list on this computer.")
        return 0
    act = oc.active_sessions(state(), WS["stale_hours"])
    print("sessions on this computer: %d of %d allowed" % (len(act), WS["max_sessions"]))
    for s in act:
        print("  - %-24s %s (last activity %s)" % (s["slug"], s["path"], oc.age_text(s["heartbeat"])))
    return 0


def cmd_release(slug):
    if MODE == "cloud":
        print("Cloud mode: nothing to release.")
        return 0
    if oc.release_session(state(), slug):
        print("RELEASED: %s no longer counts toward the session limit. The branch and its files are untouched." % slug)
    else:
        print("No active session called %s." % slug)
    return 0


def cmd_overlap():
    if MODE == "cloud":
        print("Cloud mode: overlap between features is shown by queue_status.py.")
        return 0
    from queue_status import front_matter, overlaps
    slug = current_slug()
    mine = front_matter(os.path.join(ROOT, "docs", "briefs", slug + ".md")).get("touches", [])
    if not mine:
        print("No 'touches' list in docs/briefs/%s.md yet. Fill it in first." % slug)
        return 1
    found = False
    for s in oc.active_sessions(state(), WS["stale_hours"]):
        if s["slug"] == slug:
            continue
        theirs = front_matter(os.path.join(s["path"], "docs", "briefs", s["slug"] + ".md")).get("touches", [])
        for a in mine:
            for b in theirs:
                if overlaps(a, b):
                    print("OVERLAP with '%s': my %s / their %s" % (s["slug"], a, b))
                    found = True
    if found:
        print("Two sessions are planning to change the same files. Finish and merge one first, or split the work.")
        return 6
    print("No overlap with the other running sessions.")
    return 0


def main():
    cmds = ("claim", "resume", "push", "status", "sessions", "release", "overlap", "pr-base")
    if len(sys.argv) < 2 or sys.argv[1] not in cmds:
        print(__doc__)
        return 1
    c = sys.argv[1]
    try:
        if c in ("claim", "resume", "release"):
            if len(sys.argv) < 3:
                print("usage: %s <slug>" % c)
                return 1
            if c == "claim":
                rest = sys.argv[3:]
                if rest and (rest[0] != "--base" or len(rest) != 2):
                    print("usage: claim <slug> [--base feature/<other-slug>]")
                    return 1
                return cmd_claim(sys.argv[2], rest[1] if rest else None)
            return {"resume": cmd_resume, "release": cmd_release}[c](sys.argv[2])
        return {"push": cmd_push, "status": cmd_status, "sessions": cmd_sessions, "overlap": cmd_overlap,
                "pr-base": cmd_pr_base}[c]()
    except (RuntimeError, subprocess.SubprocessError) as exc:
        print("ERROR:", exc)
        return 1


if __name__ == "__main__":
    sys.exit(main())
