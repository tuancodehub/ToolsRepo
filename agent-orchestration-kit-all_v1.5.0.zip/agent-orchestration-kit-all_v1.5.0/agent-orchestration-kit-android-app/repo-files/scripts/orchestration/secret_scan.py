#!/usr/bin/env python3
"""Fallback secret scanner (used when gitleaks is not installed, and always run in the pre-commit hook).

  secret_scan.py --staged     scan what is about to be committed
  secret_scan.py --all        scan all tracked and untracked (not ignored) files

Prints file:line and the rule name. It NEVER prints the matched value.
Allow a known-safe file by adding a glob to .secret-scan-allow (one per line; owner edits only).
Exit code 1 if anything is found.
"""
import math
import os
import re
import subprocess
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
MAX_BYTES = 1_000_000

RULES = [
    ("aws-access-key", re.compile(r"\b(?:AKIA|ASIA)[0-9A-Z]{16}\b")),
    ("private-key", re.compile(r"-----BEGIN (?:RSA |EC |DSA |OPENSSH |PGP |ENCRYPTED )?PRIVATE KEY")),
    ("github-token", re.compile(r"\bgh[pousr]_[A-Za-z0-9]{36,}\b|\bgithub_pat_[A-Za-z0-9_]{22,}\b")),
    ("slack-token", re.compile(r"\bxox[abprs]-[A-Za-z0-9-]{10,}")),
    ("stripe-key", re.compile(r"\b[sr]k_(?:live|test)_[A-Za-z0-9]{16,}")),
    ("google-api-key", re.compile(r"\bAIza[0-9A-Za-z_\-]{35}\b")),
    ("jwt", re.compile(r"\beyJ[A-Za-z0-9_-]{10,}\.eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}")),
    ("anthropic-key", re.compile(r"\bsk-ant-[A-Za-z0-9_-]{20,}")),
    ("openai-key", re.compile(r"\bsk-(?:proj-)?[A-Za-z0-9_-]{32,}")),
    ("sendgrid-key", re.compile(r"\bSG\.[A-Za-z0-9_-]{22}\.[A-Za-z0-9_-]{43}\b")),
    ("resend-key", re.compile(r"\bre_[A-Za-z0-9_]{24,}\b")),
    ("url-with-password", re.compile(r"\b[a-z][a-z0-9+.-]*://[^/\s:@'\"]+:[^/\s:@'\"]{4,}@(?!localhost|127\.0\.0\.1)")),
]
GENERIC = re.compile(r"""(?i)(api[_-]?key|secret|token|passwd|password|pwd|private[_-]?key)\s*[:=]\s*['"]([^'"\s]{12,})['"]""")
PLACEHOLDER = re.compile(r"(?i)example|changeme|change-me|your[_-]|xxx|placeholder|<|\{\{|\$\{|todo|dummy|sample|redacted|\*\*\*")
URL_PLACEHOLDER = re.compile(r"(?i)(user(name)?:pass(word)?|user:password|root:root|admin:admin)@")


def entropy(s):
    if not s:
        return 0.0
    counts = {c: s.count(c) for c in set(s)}
    return -sum(n / len(s) * math.log2(n / len(s)) for n in counts.values())


def sh(*args, text=True):
    return subprocess.run(["git", "-C", ROOT] + list(args), capture_output=True, text=text)


def allow_patterns():
    try:
        with open(os.path.join(ROOT, ".secret-scan-allow"), "r", encoding="utf-8") as fh:
            return [l.strip() for l in fh if l.strip() and not l.startswith("#")]
    except OSError:
        return []


def allowed(path, pats):
    import fnmatch
    return any(fnmatch.fnmatch(path, p) for p in pats)


def scan_text(path, text, findings):
    for n, line in enumerate(text.splitlines(), 1):
        if "kit:allow-secret" in line:
            continue
        for name, rx in RULES:
            if rx.search(line):
                if name == "url-with-password" and URL_PLACEHOLDER.search(line):
                    continue
                findings.append((path, n, name))
        m = GENERIC.search(line)
        if m and not PLACEHOLDER.search(m.group(2)) and entropy(m.group(2)) >= 3.0:
            findings.append((path, n, "generic-secret-assignment"))


def main():
    mode = "--staged" if "--staged" in sys.argv else "--all"
    pats = allow_patterns()
    findings = []
    if mode == "--staged":
        names = sh("diff", "--cached", "--name-only", "--diff-filter=ACM").stdout.split("\n")
        for name in filter(None, names):
            if allowed(name, pats):
                continue
            blob = sh("show", ":" + name, text=False).stdout
            if len(blob) > MAX_BYTES or b"\x00" in blob[:4096]:
                continue
            scan_text(name, blob.decode("utf-8", "replace"), findings)
    else:
        names = sh("ls-files", "-co", "--exclude-standard").stdout.split("\n")
        for name in filter(None, names):
            if allowed(name, pats):
                continue
            full = os.path.join(ROOT, name)
            try:
                if not os.path.isfile(full) or os.path.getsize(full) > MAX_BYTES:
                    continue
                data = open(full, "rb").read()
            except OSError:
                continue
            if b"\x00" in data[:4096]:
                continue
            scan_text(name, data.decode("utf-8", "replace"), findings)
    for path, n, rule in findings:
        print("SECRET? %s:%d  rule=%s  (value hidden)" % (path, n, rule))
    if findings:
        print("Found %d possible secret(s). Remove them, rotate any real key, and put the value in the host's secret store. "
              "False alarm in a test file? Ask the owner to add the path to .secret-scan-allow." % len(findings))
        return 1
    print("secret scan: clean (%s)" % mode)
    return 0


if __name__ == "__main__":
    sys.exit(main())
