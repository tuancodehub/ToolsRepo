#!/usr/bin/env python3
"""PreToolUse hook for Read, Edit, Write, MultiEdit, NotebookEdit, Grep and Glob.

- Secret files (.env, keys, keystores, cloud credentials): BLOCKED for every file tool.
- Safety rails (.claude, .githooks, CI workflows, CLAUDE.md, ...): the owner must approve each edit.
- Writes outside the repository: the owner must approve.
"""
import os
import re
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _common import (set_log_context, RUN_MODE_FILE, WORKSPACE_FILE, allowed_list_text, ask, canon, critical_kind, deny, finish,  # noqa: E402
                     folder_sets, is_secret_path, load_config, load_workspace, match_any,
                     project_dir, protected_edit_patterns, read_event, rel_to_root,
                     repo_root, where_allowed)

WRITE_TOOLS = {"Edit", "Write", "MultiEdit", "NotebookEdit"}
SECRETISH_GLOB = re.compile(
    r"(?i)\.env\b|\.pem\b|id_rsa|id_ed25519|\.p12\b|\.jks\b|\.keystore\b|credentials|\.ssh\b|\.aws\b|\.netrc|\.tfstate"
)
TMP_OK = ("/tmp/", "/var/tmp/")


def main():
    ev = read_event()
    tool = ev.get("tool_name", "")
    ti = ev.get("tool_input") or {}
    cwd = ev.get("cwd") or os.getcwd()
    proj = project_dir(cwd)
    cfg = load_config(proj)

    set_log_context(tool, " ".join(str(ti.get(k, "")) for k in ("file_path", "notebook_path", "path", "pattern", "glob")), cwd)
    paths = [ti[k] for k in ("file_path", "notebook_path", "path") if isinstance(ti.get(k), str) and ti.get(k)]

    # Grep / Glob can reveal secret contents or names through their patterns.
    if tool in ("Grep", "Glob"):
        for k in ("glob", "pattern") if tool == "Glob" else ("glob",):
            val = ti.get(k)
            if isinstance(val, str) and SECRETISH_GLOB.search(val) and not re.search(r"\.env\.(example|sample|template)", val):
                deny("searching for secret files is not allowed (%s)." % val)

    resolved = [canon(p, cwd) for p in paths]
    for ap in resolved:
        if is_secret_path(ap):
            deny("'%s' looks like a secret file. Agents never read or write secrets. "
                 "Use the placeholder file (for example .env.example) and tell the owner what value is needed." % os.path.basename(ap))

    if tool in WRITE_TOOLS:
        ws = load_workspace(proj)
        free, project_areas, wide, _ = folder_sets(ws, proj)
        for ap in resolved:
            if os.path.basename(ap) == RUN_MODE_FILE:
                deny("run-mode.json switches oneshot mode on. Only oneshot.py writes it, after the owner has said yes.")
            if os.path.basename(ap) == WORKSPACE_FILE:
                deny("workspace.local.json lists the folders agents may change. Only the owner edits it (set_workspace.py).")
            zone = where_allowed(ap, free, project_areas, wide)
            if ws and not zone:
                crit = critical_kind(ap)
                deny("'%s' is %soutside your allowed work folders (%s). Agents change files only inside them. "
                     "If the owner wants another folder allowed, they run set_workspace.py." % (
                         ap, ("in %s, " % crit[1]) if crit else "", allowed_list_text(free, project_areas, wide)))
            root = repo_root(ap) or proj
            rel = rel_to_root(ap, root)
            inside = not rel.startswith("..")
            if inside and match_any(rel, protected_edit_patterns(cfg)):
                ask("'%s' is a safety rail or CI file. Approve only if you asked for this change. "
                    "If you are an unattended agent: STOP and report BLOCKED instead of finding a workaround." % rel)
            if not ws and not inside and not zone:
                crit = critical_kind(ap)
                if crit:
                    ask("'%s' is in %s." % (ap, crit[1]))
                else:
                    ask("'%s' is outside the repository." % ap)
    finish()


if __name__ == "__main__":
    try:
        main()
    except SystemExit:
        raise
    except Exception as exc:  # fail closed: a broken guard must not silently allow
        sys.stderr.write("BLOCKED by the safety kit: guard_files.py failed (%s). Ask the owner to run the self-test.\n" % exc)
        sys.exit(2)
