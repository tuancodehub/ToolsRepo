#!/usr/bin/env python3
"""Shared helpers for the kit's safety hooks. Standard library only.

Hook contract (Claude Code): the event arrives as JSON on stdin.
  exit 2 + message on stderr  -> the tool call is BLOCKED and Claude sees the message
  exit 0 + JSON on stdout     -> {"hookSpecificOutput": {"permissionDecision": "ask"}} asks the owner
  any other exit code         -> NOT blocking (so a crash must be turned into exit 2 on purpose)
"""
import fnmatch
import json
import os
import re
import subprocess
import sys
import time

DEFAULT_CONFIG = {
    # Branches nobody may commit to, merge into, or push to from an agent session.
    "protected_branches": ["main", "master", "production", "prod", "develop", "release", "release/*"],
    # Extra repo-relative globs that need the owner's approval to edit (added by the stack profile).
    "extra_protected_edit": [],
}

# Repo-relative paths an agent may not change without the owner approving the prompt.
# These are the safety rails themselves, so a builder cannot weaken its own fence.
PROTECTED_EDIT = [
    ".claude/**",
    ".githooks/**",
    ".github/workflows/**",
    ".github/CODEOWNERS",
    ".github/dependabot.yml",
    "CLAUDE.md",
    "AGENTS.md",
    ".mcp.json",
    ".secret-scan-allow",
    "scripts/orchestration/**",
    ".git/**",
    "**/.npmrc",
]

# Anything matching this is treated as a secret: never read, never written by an agent.
SECRET_RE = re.compile(
    r"""(?ix)
    (?:^|[/\s'"=@:])\.env(?!\.(?:example|sample|template|dist)\b)(?:\.[\w.-]+)?(?=$|[\s'"/;|&)])
  | \.dev\.vars(?!\.example)
  | \.pem\b | \.p12\b | \.pfx\b | \.p8\b | \.jks\b | \.keystore\b | \.mobileprovision\b
  | \bid_(?:rsa|ed25519|ecdsa|dsa)\b(?!\.pub)
  | keystore\.properties | \.netrc\b | \.git-credentials | \.pypirc | \.tfstate\b
  | (?:^|/)\.ssh(?:/|$) | (?:^|/)\.aws(?:/|$) | \.config/gh\b | \.gnupg\b
  | \.kube/config | \.docker/config\.json | /proc/[^\s/]+/environ | \.git/config
  | service[-_]?account[\w.-]*\.json | \bcredentials\.json\b
    """
)


def read_event():
    raw = sys.stdin.read()
    if not raw.strip():
        return {}
    return json.loads(raw)


_LOGCTX = {}
_SECRETISH = re.compile(r"[A-Za-z0-9_\-]{24,}")


def set_log_context(tool, text, cwd):
    """Remember what this hook call is about, for the decision log."""
    _LOGCTX.update({"tool": str(tool or ""), "text": str(text or ""), "cwd": cwd or os.getcwd()})


def log_decision(decision, reason=""):
    """Append one line to .claude/.check-logs/hook-log.jsonl (git-ignored, kept small, never breaks a hook).
    Long token-like strings are cut out so a secret that slipped into a command is not copied into the log."""
    try:
        if not _LOGCTX:
            return
        base = os.path.join(project_dir(_LOGCTX["cwd"]), ".claude", ".check-logs")
        os.makedirs(base, exist_ok=True)
        path = os.path.join(base, "hook-log.jsonl")
        try:
            if os.path.getsize(path) > 1_000_000:
                os.replace(path, path + ".1")
        except OSError:
            pass
        line = {"t": int(time.time()), "mode": "oneshot" if oneshot_active(_LOGCTX["cwd"]) else "step",
                "tool": _LOGCTX["tool"], "decision": decision,
                "reason": _SECRETISH.sub("<cut>", str(reason))[:200],
                "what": _SECRETISH.sub("<cut>", " ".join(_LOGCTX["text"].split()))[:160]}
        with open(path, "a", encoding="utf-8") as fh:
            fh.write(json.dumps(line) + "\n")
    except Exception:
        pass


def deny(message):
    """Block the tool call. Claude sees the message."""
    log_decision("deny", message)
    sys.stderr.write("BLOCKED by the safety kit: " + message + "\n")
    sys.exit(2)


RUN_MODE_FILE = "run-mode.json"      # <project>/.claude/run-mode.json, git-ignored; written only by oneshot.py
_ASKS = []


def oneshot_active(cwd=None):
    """True while an owner-approved oneshot run is active (the file expires by itself)."""
    try:
        path = os.path.join(project_dir(cwd or os.getcwd()), ".claude", RUN_MODE_FILE)
        with open(path, "r", encoding="utf-8") as fh:
            data = json.load(fh)
        return data.get("mode") == "oneshot" and time.time() < float(data.get("expires_at", 0))
    except (OSError, ValueError, TypeError):
        return False


def ask(reason):
    """Remember that the owner must approve this call. Any later deny still wins; finish() sends the question."""
    _ASKS.append("Safety kit: " + reason)


def finish():
    """End the hook: ask the owner if any rule asked, otherwise allow.
    In an approved oneshot run nobody is there to answer, so an ask becomes a block that tells the agent to park the
    question and carry on with the safe alternative. Hard blocks (deny) are never relaxed."""
    if _ASKS and oneshot_active():
        log_decision("blocked-in-oneshot", "; ".join(dict.fromkeys(_ASKS)))
        sys.stderr.write("BLOCKED in oneshot mode (the owner is not here to approve): " + "; ".join(dict.fromkeys(_ASKS))[:700] +
                         "\nDo not wait and do not look for a workaround. Park it: python3 -I scripts/orchestration/park.py add "
                         "--feature <slug> --type question --title \"...\" --detail \"...\" --default \"what you did instead\", "
                         "then continue with a safe alternative that needs no approval.\n")
        sys.exit(2)
    if _ASKS:
        log_decision("ask", "; ".join(dict.fromkeys(_ASKS)))
        print(json.dumps({
            "hookSpecificOutput": {
                "hookEventName": "PreToolUse",
                "permissionDecision": "ask",
                "permissionDecisionReason": "; ".join(dict.fromkeys(_ASKS))[:900],
            }
        }))
        sys.exit(0)
    if oneshot_active():
        log_decision("auto-allowed", "oneshot")
        # Nothing asked and nothing denied: say "allow" out loud so the permission list does not stop an unattended run.
        # Deny rules in settings.json and every hook deny above still win; this only skips the "may I?" prompt.
        print(json.dumps({"hookSpecificOutput": {"hookEventName": "PreToolUse", "permissionDecision": "allow",
                                                 "permissionDecisionReason": "oneshot run: passed the safety kit's checks"}}))
    sys.exit(0)


def glob_to_regex(pat):
    i, out = 0, []
    while i < len(pat):
        c = pat[i]
        if c == "*":
            if pat[i:i + 3] == "**/":
                out.append("(?:.*/)?")
                i += 3
                continue
            if pat[i:i + 2] == "**":
                out.append(".*")
                i += 2
                continue
            out.append("[^/]*")
        elif c == "?":
            out.append("[^/]")
        else:
            out.append(re.escape(c))
        i += 1
    return re.compile("^" + "".join(out) + "$")


def match_any(rel_path, patterns):
    return any(glob_to_regex(p).match(rel_path) for p in patterns)


def resolve(path, cwd):
    p = os.path.expandvars(os.path.expanduser(path))
    if not os.path.isabs(p):
        p = os.path.join(cwd, p)
    return os.path.realpath(p)


def repo_root(path):
    d = path if os.path.isdir(path) else os.path.dirname(path)
    while d and d != os.path.dirname(d):
        if os.path.exists(os.path.join(d, ".git")):
            return d
        d = os.path.dirname(d)
    return None


def project_dir(cwd):
    env = os.environ.get("CLAUDE_PROJECT_DIR")
    if env:
        return os.path.realpath(env)
    return repo_root(cwd) or os.path.realpath(cwd)


def load_config(root):
    cfg = dict(DEFAULT_CONFIG)
    path = os.path.join(root, ".claude", "guard-config.json")
    try:
        with open(path, "r", encoding="utf-8") as fh:
            user = json.load(fh)
        for key in cfg:
            if key in user and isinstance(user[key], list):
                cfg[key] = user[key]
    except (OSError, ValueError):
        pass
    return cfg


def current_branch(cwd):
    try:
        out = subprocess.run(
            ["git", "-C", cwd, "rev-parse", "--abbrev-ref", "HEAD"],
            capture_output=True, text=True, timeout=5,
        )
        return out.stdout.strip() if out.returncode == 0 else ""
    except (OSError, subprocess.SubprocessError):
        return ""


def branch_protected(name, cfg):
    name = re.sub(r"^refs/heads/", "", name or "")
    return any(fnmatch.fnmatchcase(name, pat) for pat in cfg["protected_branches"])


def is_secret_path(path):
    return bool(SECRET_RE.search(path.replace("\\", "/")))


def protected_edit_patterns(cfg):
    return PROTECTED_EDIT + list(cfg.get("extra_protected_edit", []))


def rel_to_root(abs_path, root):
    try:
        rel = os.path.relpath(abs_path, root)
    except ValueError:
        return abs_path
    return rel.replace(os.sep, "/")


# ---------------------------------------------------------------------------
# Local-computer support: workspace settings, allowed folders, system-folder protection.
# ---------------------------------------------------------------------------
import ntpath  # noqa: E402
import tempfile  # noqa: E402

WORKSPACE_FILE = "workspace.local.json"   # lives in <main repo>/.claude/, git-ignored, one per computer
MODES = ("cloud", "local", "local-github")
CASE_INSENSITIVE = os.name == "nt" or sys.platform == "darwin"

POSIX_SYSTEM = {
    "bin", "boot", "dev", "etc", "lib", "lib32", "lib64", "libx32", "opt", "proc", "root", "run", "sbin", "srv", "sys",
    "usr", "var", "snap", "system", "library", "applications", "private", "cores", "lost+found", "nix", "usr",
}
POSIX_NOT_SYSTEM = ("/var/tmp", "/var/folders", "/private/tmp", "/private/var/folders", "/dev/null", "/dev/stdout",
                    "/dev/stderr", "/dev/stdin", "/dev/tty", "/dev/fd")
WIN_SYSTEM = {
    "windows", "program files", "program files (x86)", "programdata", "$recycle.bin", "system volume information",
    "recovery", "boot", "perflogs", "msocache", "documents and settings", "efi", "winnt",
}


def git_out(cwd, *args):
    try:
        p = subprocess.run(["git", "-C", cwd] + list(args), capture_output=True, text=True, timeout=8)
        return p.stdout.strip() if p.returncode == 0 else ""
    except (OSError, subprocess.SubprocessError):
        return ""


def git_common_dir(cwd):
    out = git_out(cwd, "rev-parse", "--git-common-dir")
    if not out:
        return ""
    return os.path.realpath(out if os.path.isabs(out) else os.path.join(cwd, out))


def main_repo_root(cwd):
    """The main checkout folder, even when cwd is inside a worktree."""
    common = git_common_dir(cwd)
    if common and os.path.basename(common) == ".git":
        return os.path.dirname(common)
    return repo_root(cwd) or os.path.realpath(cwd)


def load_workspace(cwd):
    """Return the local-computer settings dict, or None when running in cloud mode (no file)."""
    main = main_repo_root(cwd)
    path = os.path.join(main, ".claude", WORKSPACE_FILE)
    try:
        with open(path, "r", encoding="utf-8") as fh:
            ws = json.load(fh)
    except (OSError, ValueError):
        return None
    if ws.get("mode") not in ("local", "local-github"):
        return None
    root = ws.get("workspace_root")
    if not isinstance(root, str) or not root.strip():
        return None
    ws["workspace_root"] = os.path.realpath(os.path.expanduser(root))
    ws["_main"] = main
    return ws


def tools_dir(ws):
    return os.path.realpath(os.path.join(ws["workspace_root"], ws.get("tools_dir") or "tools"))


def worktrees_base(ws):
    main = ws["_main"]
    return os.path.realpath(os.path.join(os.path.dirname(main), os.path.basename(main) + "-worktrees"))


def temp_roots():
    out = []
    for d in (tempfile.gettempdir(), os.environ.get("TMPDIR"), os.environ.get("TEMP"), os.environ.get("TMP")):
        if d:
            out.append(os.path.realpath(d))
    if os.name != "nt":
        for d in ("/tmp", "/var/tmp"):
            if os.path.isdir(d):
                out.append(os.path.realpath(d))
    plans = os.path.realpath(os.path.join(os.path.expanduser("~"), ".claude", "plans"))
    out.append(plans)
    return list(dict.fromkeys(out))


def slashes(p):
    p = p.replace("\\", "/")
    while "//" in p[1:]:
        p = p[:1] + p[1:].replace("//", "/")
    if len(p) > 1 and p.endswith("/") and not re.match(r"^[A-Za-z]:/$", p):
        p = p.rstrip("/")
    return p


def pkey(p):
    p = slashes(p)
    return p.lower() if CASE_INSENSITIVE or re.match(r"^[A-Za-z]:", p) else p


def within(path, root):
    a, b = pkey(path), pkey(root)
    return a == b or a.startswith(b.rstrip("/") + "/")


_MSYS = re.compile(r"^/([A-Za-z])(?:/|$)")
_DRIVE = re.compile(r"^[A-Za-z]:[\\/]?")


def expand(path):
    return os.path.expandvars(os.path.expanduser(path))


def unresolved(path):
    """True when the text still contains variables or command substitution we cannot evaluate."""
    return bool(re.search(r"\$|`|%[A-Za-z_][A-Za-z0-9_]*%", path))


def canon(path, cwd):
    p = expand(path)
    if os.name == "nt" and _MSYS.match(p):
        p = p[1].upper() + ":" + p[2:]
    if _DRIVE.match(p) and os.name != "nt":
        return ntpath.normpath(p).replace("\\", "/")      # a Windows path seen from a Unix shell
    if not os.path.isabs(p):
        p = os.path.join(cwd, p)
    return os.path.realpath(p)


def glob_base(token):
    m = re.search(r"[*?\[]", token)
    if not m:
        return token
    base = token[:m.start()]
    if not base.endswith(("/", "\\")):
        base = base[:max(base.rfind("/"), base.rfind("\\")) + 1]
    return base or "."


def _win_rest(rest):
    segs = [x for x in rest.split("/") if x]
    if not segs:
        return "root", "the top of a drive"
    if segs[0] in WIN_SYSTEM:
        return ("root" if len(segs) == 1 else "system"), "a Windows system folder"
    if segs[0] == "users" and len(segs) <= 2:
        return "root", "a Windows user profile folder"
    return None


def critical_kind(path):
    """Return ("root"|"system", label) when path is a drive top, home folder or system folder, else None."""
    s = pkey(path)
    m = re.match(r"^([a-z]):(/.*)?$", s)
    if m:
        return _win_rest(m.group(2) or "")
    m = re.match(r"^/mnt/([a-z])(/.*)?$", s)
    if m:
        return _win_rest(m.group(2) or "")
    segs = [x for x in s.split("/") if x]
    if not segs:
        return "root", "the top of the disk"
    top = segs[0]
    if top in ("home", "users"):
        if len(segs) == 1:
            return "root", "the folder holding every home folder"
        if len(segs) == 2:
            return "root", "a whole home folder"
        return None
    if top in ("mnt", "media", "volumes"):
        return ("root", "a drive or mounted disk") if len(segs) <= 2 else None
    s2 = "/" + "/".join(segs)
    if any(s2 == e or s2.startswith(e + "/") for e in POSIX_NOT_SYSTEM):
        return None
    if top in POSIX_SYSTEM:
        return ("root" if len(segs) == 1 else "system"), "a system folder"
    return None


def folder_sets(ws, proj):
    """Returns (free, project_areas, wide, protected_roots) lists of real paths for this computer."""
    free = temp_roots()
    main = ws["_main"] if ws else main_repo_root(proj)
    project_areas = [proj, main]
    wide = []
    if ws:
        project_areas += [worktrees_base(ws), tools_dir(ws)]
        if ws.get("scope", "workspace") == "workspace":
            wide.append(ws["workspace_root"])
        wide += [os.path.realpath(os.path.expanduser(x)) for x in ws.get("extra_allowed_write", []) if isinstance(x, str)]
    protected_roots = list(dict.fromkeys(free[:-1] + project_areas + wide))   # not ~/.claude/plans
    return free, project_areas, wide, protected_roots


def where_allowed(path, free, project_areas, wide):
    if any(within(path, r) for r in free):
        return "free"
    if any(within(path, r) for r in project_areas):
        return "project"
    if any(within(path, r) for r in wide):
        return "wide"
    return None


def allowed_list_text(free, project_areas, wide):
    names = list(dict.fromkeys(project_areas + wide))
    return ", ".join(names) + " and the temp folder"
