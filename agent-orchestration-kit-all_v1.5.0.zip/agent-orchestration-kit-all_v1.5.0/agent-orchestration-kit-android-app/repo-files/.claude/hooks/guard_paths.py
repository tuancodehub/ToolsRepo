#!/usr/bin/env python3
"""Folder-boundary and destructive-action rules, used by guard_bash.py. Standard library only.

What it enforces
- ALWAYS (every mode): nothing may delete, move over, reformat or wipe a drive top, a home folder, a system folder,
  a disk or a partition. Commands that do that are blocked outright, whatever the stated reason.
- LOCAL modes (workspace.local.json exists): an agent may only CHANGE files inside the work folders the owner chose
  (the workspace folder, this project, its worktrees folder, the shared tools folder) and the temp folder.
  Reading and running programs from system folders is allowed. Installing into the system is not.
- Cloud mode: deleting or moving things outside the project asks the owner first.

This is accident prevention for an agent that makes mistakes, not a sandbox against a hostile program: a script run
with python -c or node -e can still do things. See docs/orchestration/SAFETY.md for the stronger options.
"""
import os
import re
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _common import (ask, canon, critical_kind, deny, expand, folder_sets, glob_base, is_secret_path, pkey,  # noqa: E402
                     unresolved, where_allowed, within, allowed_list_text)

# Matched against the WHOLE command text, in every mode.
HARD_DENY = [
    (r"--no-preserve-root", "'--no-preserve-root' exists only to delete the whole disk."),
    (r"(?i)\bformat(\.com)?\s+[a-z]:", "formatting a drive is not allowed."),
    (r"(?i)\b(diskpart|bcdedit|Format-Volume|Clear-Disk|Remove-Partition|Initialize-Disk|New-Partition|Resize-Partition|Set-Disk)\b",
     "disk and partition tools are not allowed."),
    (r"\b(mkfs(\.\w+)?|wipefs|blkdiscard|cryptsetup|lvremove|vgremove|pvremove|sgdisk|sfdisk|gdisk|cfdisk)\b",
     "disk and partition tools are not allowed."),
    (r"\bzpool\s+destroy|\bzfs\s+destroy", "destroying storage pools is not allowed."),
    (r"\bdiskutil\s+(erase\w*|partition\w*|zero\w*|secure\w*|apfs\s+delete\w*)", "erasing disks is not allowed."),
    (r"\bhdiutil\s+(erase|eject\s+-force)", "erasing disk images is not allowed."),
    (r"\b(csrutil|nvram)\b", "system protection settings are off limits."),
    (r"\bdd\b[^|;&\n]*\bof=/dev/", "writing straight to a disk device is not allowed."),
    (r"(?:^|[\s;|&])>>?\s*/dev/(sd|nvme|hd|vd|xvd|disk|rdisk|mmcblk)", "writing straight to a disk device is not allowed."),
    (r"\bshred\b[^|;&\n]*\s/dev/", "wiping a disk device is not allowed."),
    (r"(?i)\bvssadmin\b[^|;&\n]*\bdelete\b", "deleting backups and shadow copies is not allowed."),
    (r"(?i)\bwmic\b[^|;&\n]*\b(delete|call\s+terminate|logicaldisk|diskdrive)", "that wmic action is not allowed."),
    (r"(?i)\bcipher(\.exe)?\b[^|;&\n]*\s/w\b", "wiping free disk space is not allowed."),
    (r"(?i)\breg(\.exe)?\s+(delete|load|unload|restore)\b", "registry deletes are not allowed."),
    (r"(?i)\bwevtutil\b[^|;&\n]*\bcl\b", "clearing system logs is not allowed."),
    (r"(?i)\b(takeown|icacls)\b[^|;&\n]*(/grant|/setowner|/reset|/inheritance)", "changing ownership or permissions of system files is not allowed."),
    (r"(?i)\bnet(\.exe)?\s+(user|localgroup)\b", "changing user accounts is not allowed."),
    (r"(?i)\bschtasks(\.exe)?\s+/create", "creating scheduled tasks is not allowed."),
    (r"(?i)\bsc(\.exe)?\s+(create|delete|config)\b", "changing system services is not allowed."),
    (r"(?i)(-EncodedCommand|\s-enc\s|\s-ec\s)", "encoded PowerShell commands cannot be inspected, so they are not allowed."),
    (r"(?i)(Invoke-Expression|(?:^|[\s;|(])iex\s)", "Invoke-Expression runs text as code and cannot be inspected."),
    (r"(?i)Start-Process[^|;&\n]*-Verb\s+RunAs", "running as administrator is not allowed."),
    (r"(?i)Set-ItemProperty[^|;&\n]*\bHK(LM|CU)\b|New-ItemProperty[^|;&\n]*\bHK(LM|CU)\b", "registry changes are not allowed."),
    (r"(?i)\bRemove-Item\b[^|;&\n]*\bHK(LM|CU|CR|U):", "registry deletes are not allowed."),
    (r"(?i)\bsystemctl\s+(poweroff|halt|reboot|kexec)\b|\binit\s+[06]\b|\bStop-Computer\b|\bRestart-Computer\b",
     "shutting down or restarting the computer is not allowed."),
]
HARD_DENY = [(re.compile(p), m) for p, m in HARD_DENY]

READ_SAFE = {"ls", "dir", "cat", "head", "tail", "grep", "egrep", "fgrep", "rg", "stat", "file", "wc", "which", "where",
             "type", "echo", "printf", "pwd", "cd", "test", "[", "diff", "cmp", "sort", "uniq", "du", "df", "tree",
             "realpath", "readlink", "basename", "dirname", "uname", "id", "date", "true", "false", "get-content",
             "get-childitem", "gci", "select-string", "sls", "get-location", "set-location", "sl", "gc", "less", "more",
             "find", "locate", "nproc", "hostname", "ver", "pushd", "popd", "export", "unset", "set", "sleep", "clear"}
READ_GIT = {"status", "log", "diff", "show", "ls-files", "rev-parse", "ls-remote", "remote", "branch", "describe", "blame",
            "shortlog", "cat-file", "grep", "fetch", "config", "worktree", "rev-list", "for-each-ref", "show-ref",
            "merge-base", "name-rev", "diff-tree", "stash", "version", "help", "reflog", "check-ignore", "var"}
SYSTEM_PM = {"apt", "apt-get", "aptitude", "dpkg", "dnf", "yum", "microdnf", "rpm", "zypper", "pacman", "apk", "brew",
             "port", "snap", "flatpak", "choco", "winget", "scoop", "msiexec", "pkg", "nix-env", "pkgin"}
PM_READONLY = {"list", "info", "search", "show", "--version", "-v", "version", "query", "-q", "-qa", "policy", "depends",
               "which", "--help", "help", "-h", "outdated", "deps", "uses", "--prefix", "--cellar", "config", "-l", "-s", "-si"}

DELETE = {"rm", "rmdir", "unlink", "shred", "del", "erase", "rd", "remove-item", "ri"}
MOVE = {"mv", "move", "move-item", "mi", "rename", "ren", "rename-item", "rni"}
COPY = {"cp", "copy", "copy-item", "cpi", "install", "rsync", "xcopy", "robocopy"}
WRITE_ALL = {"touch", "mkdir", "md", "mkfifo", "tee", "new-item", "ni", "set-content", "sc", "add-content", "ac",
             "out-file", "clear-content", "truncate"}
CMD_STYLE = {"del", "erase", "rd", "rmdir"}
PS_PATH_PARAMS = {"-path", "-literalpath", "-destination", "-filepath", "-name"}
PS_SWITCHES = {"-recurse", "-force", "-confirm", "-whatif", "-verbose", "-passthru", "-noclobber", "-append",
               "-nonewline", "-forcenew", "-debug", "-erroraction", "-includehidden"}
INLINE_DESTRUCTIVE = re.compile(
    r"(?i)(shutil\.rmtree|\brmtree\b|os\.(remove|rmdir|unlink|removedirs)|\bunlink\s*\(|fs\.(rm|rmSync|rmdir|rmdirSync|unlink|unlinkSync)\b|"
    r"FileUtils\.(rm|remove)|Remove-Item|\brm\s+-[a-z]*r|\bdel\s+/|\brd\s+/)")


def positional(args, value_flags=()):
    out, skip, dd = [], False, False
    for a in args:
        if skip:
            skip = False
            continue
        if dd:
            out.append(a)
            continue
        if a == "--":
            dd = True
            continue
        if a in value_flags:
            skip = True
            continue
        if a.startswith("-") and len(a) > 1:
            continue
        if a == "-":
            continue
        out.append(a)
    return out


def _ps_switch(low):
    return len(low) >= 2 and any(sw.startswith(low) for sw in PS_SWITCHES)


def ps_split(args):
    """Return (paths, recursive) for a PowerShell-style argument list."""
    paths, rec, i = [], False, 0
    while i < len(args):
        a = args[i]
        low = a.lower()
        if a.startswith("-") and len(a) > 1 and not re.fullmatch(r"-\d+", a):
            name = low.split(":", 1)[0]
            if len(name) >= 2 and "-recurse".startswith(name):
                rec = True
            if ":" in low and name in PS_PATH_PARAMS:
                paths.append(a.split(":", 1)[1])
            elif name in PS_PATH_PARAMS and i + 1 < len(args):
                paths.append(args[i + 1])
                i += 1
            elif _ps_switch(name) or ":" in low:
                pass
            elif i + 1 < len(args) and not args[i + 1].startswith("-"):
                i += 1
        else:
            paths.append(a)
        i += 1
    return paths, rec


def flag_values(args, short, long_=()):
    out = []
    for i, a in enumerate(args):
        if a in short and i + 1 < len(args):
            out.append(args[i + 1])
        for lf in long_:
            if a.startswith(lf + "="):
                out.append(a.split("=", 1)[1])
            elif a == lf and i + 1 < len(args):
                out.append(args[i + 1])
    return out


def ops_for(cmd0, args, ps):
    """Describe what a command changes: a list of (kind, targets, recursive). kind: delete | move | write | cwd."""
    c = cmd0.lower()
    if c.endswith(".exe"):
        c = c[:-4]
    ops = []
    if c in DELETE or c in MOVE or c in COPY or c in WRITE_ALL:
        if ps or c in ("remove-item", "ri", "move-item", "mi", "copy-item", "cpi", "new-item", "ni", "set-content", "sc",
                       "add-content", "ac", "out-file", "clear-content", "rename-item", "rni"):
            pos, rec = ps_split(args)
        else:
            if c in CMD_STYLE:
                rec = any(re.fullmatch(r"/[sS]", a) for a in args)
                args = [a for a in args if not re.fullmatch(r"/[A-Za-z?]", a)]
            else:
                rec = any(a == "--recursive" or (a.startswith("-") and not a.startswith("--") and ("r" in a or "R" in a)) for a in args)
            pos = positional(args, ("-s", "--size", "-r", "--reference", "-m", "--mode", "-t", "--target-directory") if c in ("truncate", "mkdir", "install") else ())
        if c in DELETE:
            ops.append(("delete", pos, rec))
        elif c in MOVE:
            ops.append(("move", pos, False))
        elif c in COPY:
            tv = flag_values(args, ("-t",), ("--target-directory",))
            if tv:
                ops.append(("write", tv, False))
            elif c in ("robocopy", "xcopy"):
                ops.append(("write", pos[1:2], False))
            elif c == "install" and any(a in ("-d", "--directory") for a in args):
                ops.append(("write", pos, False))
            elif len(pos) >= 2:
                ops.append(("write", pos[-1:], False))
            if c == "rsync" and any(a.startswith("--delete") for a in args) and len(pos) >= 2:
                ops.append(("delete", pos[-1:], True))
        else:
            ops.append(("write", pos, False))
    elif c == "ln":
        pos = positional(args)
        if len(pos) >= 2:
            ops.append(("write", pos[-1:], False))
    elif c in ("chmod", "chown", "chgrp"):
        pos = positional(args)
        rec = any(a == "--recursive" or (a.startswith("-") and not a.startswith("--") and "R" in a) for a in args)
        if "--reference" not in " ".join(args):
            pos = pos[1:]
        ops.append(("write", pos, rec))
    elif c == "dd":
        ops.append(("write", [a[3:] for a in args if a.startswith("of=")], False))
    elif c == "sed" and any(a.startswith("-i") or a == "--in-place" for a in args):
        has_script = any(a in ("-e", "-f", "--expression", "--file") for a in args)
        pos = positional(args, ("-e", "-f", "--expression", "--file"))
        ops.append(("write", pos if has_script else pos[1:], False))
    elif c == "perl" and any(re.fullmatch(r"-[a-zA-Z]*i[a-zA-Z.]*", a) for a in args):
        ops.append(("write", positional(args, ("-e", "-E"))[(0 if any(a in ("-e", "-E") for a in args) else 1):], False))
    elif c == "curl":
        outs = flag_values(args, ("-o",), ("--output",))
        outs += flag_values(args, (), ("--output-dir",))
        if any(a == "-O" or a == "--remote-name" or (a.startswith("-") and not a.startswith("--") and "O" in a) for a in args) or any(a == "--remote-name-all" for a in args):
            outs.append(".")
        ops.append(("write", outs, False))
    elif c == "wget":
        outs = flag_values(args, ("-O", "-P"), ("--output-document", "--directory-prefix"))
        if not outs and not any(a in ("-q", "--spider") for a in args):
            outs = ["."]
        ops.append(("write", outs, False))
    elif c == "tar":
        letters = args[0] if args and not args[0].startswith("-") else ""
        shorts = letters + "".join(a[1:] for a in args if a.startswith("-") and not a.startswith("--"))
        extract = "x" in shorts or "--extract" in args or "--get" in args
        create = "c" in shorts or "--create" in args
        dirs = flag_values(args, ("-C",), ("--directory",))
        files = flag_values(args, ("-f",), ("--file",))
        if "f" in letters and not files:
            idx = args.index(letters)
            if idx + 1 < len(args):
                files = [args[idx + 1]]
        if extract:
            ops.append(("write", dirs or ["."], False))
        if create and files:
            ops.append(("write", files[:1], False))
    elif c == "unzip" and not any(a in ("-l", "-Z", "-t", "-v") for a in args):
        ops.append(("write", flag_values(args, ("-d",)) or ["."], False))
    elif c == "zip":
        pos = positional(args, ("-x", "-i", "-b", "-n", "-t", "-tt"))
        if pos:
            ops.append(("write", pos[:1], False))
    elif c in ("gzip", "gunzip", "bzip2", "bunzip2", "xz", "unxz") and not any(a in ("-c", "--stdout", "-l", "-t") for a in args):
        ops.append(("write", positional(args), False))
    elif c in ("virtualenv",):
        ops.append(("write", positional(args), False))
    elif c in ("python", "python3", "py") and "-m" in args:
        i = args.index("-m")
        if i + 1 < len(args) and args[i + 1] == "venv":
            ops.append(("write", positional(args[i + 2:]), False))
    elif c in ("npm", "pnpm", "yarn", "bun"):
        pre = flag_values(args, ("--prefix", "-C"), ("--prefix", "--dir", "--cwd"))
        if pre:
            ops.append(("write", pre, False))
    return ops


def git_ops(sub, rest):
    ops = []
    if sub == "clone":
        pos = positional(rest, ("-b", "--branch", "--depth", "-o", "--origin", "--reference", "--template", "-c", "--config", "--separate-git-dir"))
        ops.append(("write", pos[1:2] if len(pos) > 1 else ["."], False))
    elif sub == "init":
        pos = positional(rest, ("--template", "-b", "--initial-branch", "--separate-git-dir"))
        ops.append(("write", pos[:1] or ["."], False))
    return ops


def check_targets(kind, targets, ctx, recursive, name):
    """Apply the folder rules to the paths a command is about to change."""
    ws = ctx.ws
    free, project_areas, wide, protected = ctx.sets
    for t in targets:
        if not t:
            continue
        t = t.strip("'\"")
        exp = expand(t)
        if unresolved(exp):
            deny("'%s %s': cannot tell where this points because it uses a variable or command. Write the real path." % (name, t))
        is_glob = bool(re.search(r"[*?\[]", t))
        base = glob_base(exp) if is_glob else exp
        ap = canon(base or ".", ctx.cwd)
        if t in ("*", "./*", "../*", ".", "..", "/", "/*", "~", "~/*", "\\", "C:\\", "C:/") and kind in ("delete", "move") and name != "find":
            deny("refusing '%s %s'. Name the exact file or folder." % (name, t))
        if kind in ("write", "move") and is_secret_path(ap):
            deny("never write secret files.")
        is_root = any(pkey(ap) == pkey(r) for r in protected)
        if is_root and name == "find" and kind == "delete":
            ask("find with -delete or -exec rm will run across the whole of %s." % ap)
            continue
        if is_root and (kind in ("delete", "move") or is_glob):
            deny("'%s %s' would remove or empty a main work folder (%s). Use worktree.py remove, or delete specific items inside it." % (name, t, ap))
        if kind in ("delete", "move") and os.path.basename(ap.rstrip("/\\")) == ".git":
            deny("refusing to delete or move a .git folder.")
        zone = where_allowed(ap, free, project_areas, wide)
        if zone:
            if kind == "delete" and recursive and zone == "wide":
                ask("recursive delete outside this project but inside the workspace folder: %s" % t)
            continue
        crit = critical_kind(ap)
        if crit:
            deny("'%s %s' reaches %s (%s). Agents may never change system or home folders." % (name, t, crit[1], ap))
        if ws:
            deny("'%s %s' would change %s, which is outside your allowed work folders (%s). "
                 "Work inside them, or ask the owner to add the folder with set_workspace.py." % (name, t, ap, allowed_list_text(free, project_areas, wide)))
        if kind in ("delete", "move"):
            ask("%s outside the project: %s" % (name, t))


def hard_deny_text(text):
    for rx, msg in HARD_DENY:
        if rx.search(text):
            deny(msg)


def rule_folder_ops(cmd0, args, seg, ctx, ps=False, git_sub=None, git_rest=None, git_dir=None):
    ops = ops_for(cmd0, args, ps)
    if cmd0 == "git" and git_sub:
        ops += git_ops(git_sub, git_rest or [])
        if ctx.ws and git_sub not in READ_GIT and git_dir:
            ops.append(("write", [git_dir], False))
    name = os.path.basename(cmd0)
    for kind, targets, rec in ops:
        check_targets(kind, targets, ctx, rec, name)
    # Redirections: echo x > path, >> path
    unquoted = re.sub(r"\"[^\"]*\"|'[^']*'", '""', seg)
    for m in re.finditer(r"(?<![<>&\w-])(?:\d?)>>?\s*(?!&)([^\s;|&<>]+)", unquoted):
        tgt = m.group(1).strip("'\"")
        if tgt.lower() in ("/dev/null", "nul", "$null", "/dev/stderr", "/dev/stdout", "/dev/tty") or tgt.startswith("&"):
            continue
        check_targets("write", [tgt], ctx, False, "redirect >")
    # find ... -delete / -exec rm
    if cmd0 == "find" and ("-delete" in args or (("-exec" in args or "-execdir" in args) and re.search(r"\b(rm|rmdir|mv|shred)\b", seg))):
        starts = []
        for a in args:
            if a.startswith("-") or a in ("(", "!", ")"):
                break
            starts.append(a)
        check_targets("delete", starts or ["."], ctx, True, "find")


def rule_cwd(cmd0, args, ctx, git_sub=None):
    """In local modes, nothing except plain reading may run from a folder outside the work folders."""
    if not ctx.ws:
        return
    free, project_areas, wide, _ = ctx.sets
    here = canon(".", ctx.cwd)
    if where_allowed(here, free, project_areas, wide):
        return
    c = os.path.basename(cmd0).lower()
    if c.endswith(".exe"):
        c = c[:-4]
    if c in READ_SAFE:
        return
    if c == "git" and git_sub in READ_GIT:
        return
    deny("your shell is in %s, outside the allowed work folders (%s). Change back into the project before running '%s'." % (
        here, allowed_list_text(free, project_areas, wide), c))


def rule_system_installs(cmd0, args, ctx, exe=None):
    """Local modes: no installs into the computer itself. Tools go into the shared tools folder."""
    if not ctx.ws:
        return
    c = os.path.basename(cmd0).lower()
    if c.endswith(".exe"):
        c = c[:-4]
    tools = ctx.tools_hint()
    if c in SYSTEM_PM:
        if args and args[0] not in PM_READONLY and not args[0].startswith("--version"):
            deny("'%s %s' changes your computer outside the work folders. Ask the owner to install it, or put the tool in %s "
                 "(for Python: python3 -m venv %s/venvs/<name>)." % (c, args[0], tools, tools))
        return
    if c in ("npm", "pnpm", "yarn", "bun") and args:
        glob = any(a in ("-g", "--global", "--location=global", "--location", "global") for a in args) or args[0] == "global"
        if glob and any(a in ("install", "i", "add", "remove", "uninstall", "rm", "update", "up", "upgrade", "link") for a in args):
            deny("global installs change your computer. Install into the project instead, or into %s with --prefix %s." % (tools, tools))
    if c in ("pip", "pip3", "pipx") or (c in ("python", "python3", "py") and args[:2] == ["-m", "pip"]) or (c == "uv" and args[:1] == ["pip"]):
        rest = args[2:] if c in ("python", "python3", "py") else args[1:] if c == "uv" else args
        if any(a in ("install", "uninstall") for a in rest[:3]) and "--dry-run" not in rest:
            free, project_areas, wide, _ = ctx.sets
            venv_env = os.environ.get("VIRTUAL_ENV", "")
            exe = exe or cmd0
            exe_ok = "/" in exe or "\\" in exe
            exe_inside = exe_ok and where_allowed(canon(exe, ctx.cwd), free, project_areas, wide)
            env_inside = bool(venv_env) and where_allowed(os.path.realpath(venv_env), free, project_areas, wide)
            target_inside = any(where_allowed(canon(t, ctx.cwd), free, project_areas, wide) for t in flag_values(rest, ("-t",), ("--target", "--prefix")))
            if c == "pipx" or not (exe_inside or env_inside or target_inside):
                deny("pip would install into your computer's own Python. Create a virtual environment inside the tools folder "
                     "(python3 -m venv %s/venvs/<name>), then run its pip, for example %s/venvs/<name>/bin/pip install <package>." % (tools, tools))
    if c in ("cargo", "go", "gem") and args[:1] == ["install"]:
        ask("'%s install' puts a program outside your work folders unless its home setting points inside them." % c)
    if c in ("python", "python3", "node", "ruby", "perl", "py", "pwsh", "powershell") and any(a in ("-c", "-e", "-Command") for a in args) \
            and INLINE_DESTRUCTIVE.search(" ".join(args)):
        ask("inline code that deletes files cannot be checked against the folder rules. Prefer a normal command.")
