#!/usr/bin/env python3
"""PreToolUse hook for the Bash tool.

BLOCK  (exit 2): pushing to protected branches, force pushes, merging PRs, skipping hooks, publishing,
                 reading or sending secrets, sudo, pipe-to-shell, destructive deletes.
ASK    (owner approves): real-infrastructure CLIs (cloud, deploy), destructive database commands,
                 remote code runners (npx and friends), edits to safety rails through the shell.

This is accident prevention, not a sandbox: a determined script (python -c, node -e) can still do things.
Keep secrets out of the working folder, and use the other layers (permissions, git hook, CI, GitHub rules).
"""
import os
import re
import shlex
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _common import (set_log_context, SECRET_RE, ask, branch_protected, finish, canon, current_branch, deny,  # noqa: E402
                     folder_sets, is_secret_path, load_config, load_workspace, match_any,
                     project_dir, protected_edit_patterns, read_event, rel_to_root, repo_root,
                     resolve, tools_dir)
from guard_paths import (hard_deny_text, rule_cwd, rule_folder_ops, rule_system_installs)  # noqa: E402

WRAPPERS = {"command", "builtin", "time", "nohup", "nice", "exec", "then", "do", "else", "!", "{", "(", "env"}
READERS = {"cat", "less", "more", "head", "tail", "grep", "egrep", "fgrep", "rg", "awk", "sed", "cp", "mv", "base64",
           "xxd", "od", "strings", "source", ".", "hexdump", "tac", "nl", "cut", "sort", "uniq", "diff", "cmp", "wc",
           "jq", "yq", "python", "python3", "node", "ruby", "perl", "php", "bash", "sh", "zsh", "xargs", "tee", "zip",
           "tar", "gzip", "openssl", "gpg", "get-content", "gc", "type", "select-string", "sls", "copy-item", "cpi"}
EXFIL = {"curl", "wget", "nc", "ncat", "socat", "telnet", "scp", "sftp", "ssh", "ftp", "rsync", "http", "https"}
WRITERS = {"rm", "mv", "cp", "tee", "chmod", "chown", "ln", "install", "truncate", "touch", "dd", "patch", "unlink", "shred"}
READONLY = {"cat", "ls", "head", "tail", "grep", "rg", "diff", "wc", "file", "stat", "less", "more", "find"}
SAFE_HOSTS = ()


def split_segments(cmd):
    segs, buf, q, i = [], [], None, 0
    while i < len(cmd):
        c = cmd[i]
        if q:
            buf.append(c)
            if c == q and (q == "'" or cmd[i - 1] != "\\"):
                q = None
        elif c in "'\"":
            q = c
            buf.append(c)
        elif c == "\\" and i + 1 < len(cmd):
            buf.append(c)
            buf.append(cmd[i + 1])
            i += 1
        elif c in ";\n|&":
            nxt = cmd[i + 1] if i + 1 < len(cmd) else ""
            prev = cmd[i - 1] if i > 0 else ""
            if c == "&" and (prev == ">" or nxt == ">"):
                buf.append(c)  # 2>&1 or &>
            else:
                segs.append("".join(buf))
                buf = []
                if nxt == c and c in "|&":
                    i += 1
        else:
            buf.append(c)
        i += 1
    segs.append("".join(buf))
    return [s.strip() for s in segs if s.strip()]


def strip_heredocs(cmd):
    out, skip = [], None
    for line in cmd.split("\n"):
        if skip is not None:
            if line.strip() == skip:
                skip = None
            continue
        out.append(line)
        m = re.search(r"<<-?\s*['\"]?(\w+)['\"]?", line)
        if m:
            skip = m.group(1)
    return "\n".join(out)


def tokenize(seg):
    try:
        return shlex.split(seg, posix=True)
    except ValueError:
        return seg.split()


class Ctx:
    def __init__(self, cwd):
        self.cwd = cwd
        self.proj = project_dir(cwd)
        self.cfg = load_config(self.proj)
        self.ws = load_workspace(self.proj)          # None in cloud mode
        self.sets = folder_sets(self.ws, self.proj)  # (free, project areas, wide, protected roots)

    def tools_hint(self):
        return tools_dir(self.ws) if self.ws else "<tools folder>"

    def branch(self, d=None):
        return current_branch(d or self.cwd)


def mentions_secret(tokens):
    return any(SECRET_RE.search(t) for t in tokens)


def tokenize_ps(seg):
    toks = re.findall(r"\"[^\"]*\"|'[^']*'|\S+", seg)
    return [t[1:-1] if len(t) >= 2 and t[0] == t[-1] and t[0] in "'\"" else t for t in toks]


READ_ONLY_CMDS = {"cat", "ls", "head", "tail", "type", "dir", "grep", "stat", "wc", "get-content"}


def owner_only_rules(text):
    """Scripts and files that decide what an agent may touch are changed by the owner, never by the agent."""
    if re.search(r"set_workspace\.py", text) and not re.search(r"--(check|show)\b", text):
        deny("set_workspace.py decides which folders agents may change. Only the owner runs it, in their own terminal "
             "(or with the ! prefix). Tell the owner the exact command instead.")
    if re.search(r"local_merge\.py", text):
        deny("local_merge.py merges finished work into the main branch. Only the owner runs it, in their own terminal.")


def check_command(cmd, ctx, depth=0, ps=False):
    if depth > 4:
        return
    if not ps:
        cmd = strip_heredocs(cmd)
    full = cmd
    hard_deny_text(full)
    owner_only_rules(full)

    # Whole-command rules (pipes are split later, so look at the raw text first).
    if re.search(r"(?i)\b(curl|wget)\b[^|;&]*\|\s*(sudo\s+)?(ba|z|da|k)?sh\b", full) or \
       re.search(r"(?i)\b(curl|wget)\b[^|;&]*\|\s*(sudo\s+)?(python3?|node|perl|ruby)\b", full):
        deny("downloading and piping straight into a shell or interpreter is not allowed. Download, read, then run.")
    if re.search(r":\(\)\s*\{\s*:\|:&\s*\};:", full):
        deny("fork bomb pattern.")

    if not ps:
        for inner in re.findall(r"\$\(([^()]*)\)", full) + re.findall(r"`([^`]*)`", full):
            check_command(inner, ctx, depth + 1)

    saved_cwd = ctx.cwd
    for seg in split_segments(full):
        tokens = tokenize_ps(seg) if ps else tokenize(seg)
        while tokens and (re.match(r"^[A-Za-z_][A-Za-z0-9_]*=", tokens[0]) or tokens[0] in WRAPPERS or (ps and tokens[0] in ("&", "."))):
            tokens = tokens[1:]
        if not tokens:
            continue
        cmd0 = os.path.basename(tokens[0].replace("\\", "/"))
        args = tokens[1:]

        if cmd0.lower() in ("cd", "chdir", "pushd", "set-location", "sl") and args:
            ctx.cwd = canon(args[-1] if not args[-1].startswith("-") else ".", ctx.cwd)
            continue
        if "run-mode.json" in seg and cmd0.lower() not in READ_ONLY_CMDS:
            deny("run-mode.json switches oneshot mode on. Only oneshot.py writes it, after the owner has said yes.")
        if "workspace.local.json" in seg and cmd0.lower() not in READ_ONLY_CMDS:
            deny("workspace.local.json lists the folders agents may change. Only the owner edits it (set_workspace.py).")
        if cmd0.lower() in ("powershell", "pwsh", "powershell.exe", "pwsh.exe", "cmd", "cmd.exe"):
            for i, a in enumerate(args):
                if a.lower() in ("-command", "-c", "/c", "/k") and i + 1 < len(args):
                    check_command(" ".join(args[i + 1:]), ctx, depth + 1, ps=True)
        if cmd0 in ("bash", "sh", "zsh", "dash", "ksh") and "-c" in args:
            idx = args.index("-c")
            if idx + 1 < len(args):
                check_command(args[idx + 1], ctx, depth + 1)
        if cmd0 == "eval" and args:
            check_command(" ".join(args), ctx, depth + 1)
        if cmd0 == "xargs":
            rest = [a for a in args if not a.startswith("-")]
            if rest:
                check_command(" ".join(rest), ctx, depth + 1)

        rule_basic(cmd0, args, seg, ctx)
        git_sub, git_rest, git_dir = (None, [], None)
        if cmd0 == "git":
            git_sub, git_rest, gd = git_parse(args)
            git_dir = resolve(gd, ctx.cwd) if gd else None
        rule_cwd(cmd0, args, ctx, git_sub)
        rule_folder_ops(cmd0, args, seg if not ps else seg, ctx, ps=ps, git_sub=git_sub, git_rest=git_rest, git_dir=git_dir)
        rule_system_installs(cmd0, args, ctx, exe=tokens[0])
        rule_git(cmd0, args, ctx)
        rule_gh(cmd0, args, ctx)
        rule_publish_deploy(cmd0, args, seg)
        rule_node_tools(cmd0, args, ctx)
        rule_secrets(cmd0, tokens, args)
        rule_shell_writes(cmd0, args, seg, ctx)
    ctx.cwd = saved_cwd


def rule_basic(cmd0, args, seg, ctx):
    if cmd0 == "sudo" or cmd0 == "su" or cmd0 == "doas":
        deny("no sudo/su. Agents run without admin rights.")
    if cmd0 in ("ssh", "scp", "sftp", "nc", "ncat", "socat", "telnet"):
        deny("%s opens connections to other machines. Not needed for building features." % cmd0)
    if cmd0 in ("shutdown", "reboot", "halt", "poweroff", "mkfs", "fdisk", "parted") or cmd0.startswith("mkfs."):
        deny("system-level command.")
    if cmd0 == "dd" and any(a.startswith("of=/dev/") for a in args):
        deny("writing to a device.")
    if cmd0 == "chmod" and any(a in ("777", "-R777") or a == "a+rwx" for a in args):
        deny("world-writable permissions are not allowed.")
    if cmd0 in ("chown", "crontab", "at", "systemctl", "launchctl", "rsync"):
        ask("%s changes the system or syncs files elsewhere." % cmd0)
    if cmd0 == "printenv" or (cmd0 == "env" and not args) or (cmd0 == "export" and "-p" in args):
        deny("printing environment variables can leak secrets.")
    if cmd0 == "docker" and any(a in ("--privileged", "--pid=host", "--net=host") for a in args):
        deny("privileged containers are not allowed.")
    if cmd0 == "find" and ("-delete" in args or "-exec" in args or "-execdir" in args):
        ask("find with -delete/-exec can change many files.")


def git_parse(args):
    i, gdir = 0, None
    while i < len(args):
        a = args[i]
        if a == "-C" and i + 1 < len(args):
            gdir = args[i + 1]
            i += 2
        elif a == "-c" and i + 1 < len(args):
            i += 2
        elif a in ("--git-dir", "--work-tree", "--namespace") and i + 1 < len(args):
            i += 2
        elif a.startswith("-"):
            i += 1
        else:
            break
    if i >= len(args):
        return None, [], gdir
    return args[i], args[i + 1:], gdir


def rule_git(cmd0, args, ctx):
    if cmd0 != "git":
        return
    if any("hookspath" in a.lower() for a in args):
        deny("changing git hooks settings is not allowed.")
    sub, rest, gdir = git_parse(args)
    if sub is None:
        return
    cwd = resolve(gdir, ctx.cwd) if gdir else ctx.cwd
    cfg = ctx.cfg
    if ctx.ws:
        if sub == "push":
            if ctx.ws.get("mode") == "local":
                deny("this project is local-only: nothing is pushed to GitHub. Commit locally; the owner merges with local_merge.py.")
            deny("push with: python3 -I scripts/orchestration/feature_git.py push. It takes turns with your other sessions "
                 "so GitHub's rate limits are never hit.")
        if sub == "worktree" and rest and rest[0] in ("add", "move", "prune", "repair", "lock"):
            deny("create worktrees with: python3 -I scripts/orchestration/worktree.py add <slug>. It keeps them in the approved "
                 "folder and enforces the session limit.")
    if "--no-verify" in rest or (sub == "commit" and any(re.fullmatch(r"-[a-z]*n[a-z]*", a) for a in rest if not a.startswith("--"))):
        deny("skipping git hooks (--no-verify / -n) is not allowed. Fix what the hook reported.")
    br = None

    def branch():
        nonlocal br
        if br is None:
            br = current_branch(cwd)
        return br

    if sub == "push":
        flags = [a for a in rest if a.startswith("-")]
        pos = [a for a in rest if not a.startswith("-")]
        for f in flags:
            short_force = (not f.startswith("--")) and "f" in f
            if short_force or f.startswith("--force") or f in ("--mirror", "--all", "--delete", "--prune", "-d") or f.startswith("--receive-pack") or f.startswith("--exec"):
                deny("force pushes, deleting remote branches and mirror/all pushes are not allowed.")
        refspecs = pos[1:]
        if not refspecs:
            if branch_protected(branch(), cfg) or branch() in ("HEAD", ""):
                deny("you are on '%s'. Never push a protected branch. Work on feature/<slug>." % (branch() or "an unknown branch"))
        for r in refspecs:
            if r.startswith("+") or r.startswith(":"):
                deny("force or delete refspecs are not allowed.")
            dst = r.split(":", 1)[1] if ":" in r else r
            if dst == "HEAD":
                dst = branch()
            if branch_protected(dst, cfg):
                deny("pushing to '%s' is not allowed. Only the owner merges pull requests." % dst)
    elif sub == "commit":
        if branch_protected(branch(), cfg):
            deny("you are on protected branch '%s'. Create feature/<slug> first (feature_git.py claim <slug>)." % branch())
    elif sub in ("merge", "rebase", "cherry-pick", "am", "revert"):
        if branch_protected(branch(), cfg):
            deny("'git %s' on protected branch '%s' is not allowed." % (sub, branch()))
    elif sub == "add":
        if any(a in ("-A", "--all", ".", ":/", "*", "./", ":") for a in rest):
            deny("add files by explicit path (git add path/one path/two). 'add all' can commit secrets or junk.")
    elif sub == "config":
        if any(a in ("--global", "--system") for a in rest) and not any(a in ("--get", "--list", "-l", "--get-all") for a in rest):
            ask("changing global git settings.")
    elif sub == "credential":
        deny("git credential helpers can print tokens.")
    elif sub == "reset" and "--hard" in rest:
        ask("git reset --hard throws away uncommitted work.")
    elif sub == "clean" and any(a.startswith("-") and "f" in a for a in rest):
        ask("git clean deletes untracked files.")
    elif sub == "branch" and any(a in ("-D", "--delete", "-M", "-m") for a in rest):
        ask("deleting or renaming a branch.")
    elif sub == "remote" and rest and rest[0] in ("add", "set-url", "remove", "rm", "rename"):
        ask("changing git remotes.")
    elif sub in ("filter-branch", "filter-repo", "update-ref", "replace", "reflog") or (sub == "gc" and any("prune" in a for a in rest)):
        ask("rewriting git history or internals.")
    elif sub == "worktree" and rest and rest[0] == "remove" and any(a in ("-f", "--force") for a in rest):
        ask("force-removing a worktree.")

    if sub in ("rm", "mv", "restore", "checkout", "apply", "clean", "checkout-index"):
        root = repo_root(cwd) or ctx.proj
        for a in rest:
            if a.startswith("-"):
                continue
            ap = resolve(a, cwd)
            if is_secret_path(ap):
                deny("secret files are off limits.")
            if match_any(rel_to_root(ap, root), protected_edit_patterns(cfg)):
                ask("'%s' is a safety rail or CI file." % a)


def rule_gh(cmd0, args, ctx=None):
    if cmd0 != "gh":
        return
    if ctx is not None and ctx.ws and ctx.ws.get("mode") == "local" and args[:1] != ["--version"]:
        deny("this project is local-only (no GitHub). The gh command is not used here.")
    s = " ".join(args)
    if re.match(r"^auth\s+(token|login|refresh|setup-git|logout|switch)", s) or re.search(r"\bauth\s+status\b.*(-t|--show-token)", s):
        deny("gh auth commands can print or change tokens.")
    if re.match(r"^pr\s+merge", s) or re.search(r"--auto\b", s) and s.startswith("pr"):
        deny("agents never merge pull requests. The owner merges.")
    if re.match(r"^pr\s+review", s):
        deny("agents do not approve pull requests. Humans review and approve.")
    if re.match(r"^repo\s+(delete|archive|rename|edit|transfer|unarchive)", s):
        deny("changing or deleting the repository is not allowed.")
    if re.match(r"^extension\s+install", s):
        deny("installing gh extensions runs unknown code.")
    if re.match(r"^api\b", s):
        method = "GET"
        for i, a in enumerate(args):
            if a in ("-X", "--method") and i + 1 < len(args):
                method = args[i + 1].upper()
            if a in ("-f", "-F", "--field", "--raw-field", "--input") and method == "GET":
                method = "POST"
        if method != "GET":
            if re.search(r"(branches/.+/protection|rulesets|/merges|/git/refs|collaborators|/hooks|/keys|actions/secrets|dependabot/secrets|/environments|visibility|/transfer|/pulls/\d+/merge|/releases|/deployments)", s):
                deny("this GitHub API call changes protections, secrets, releases or access. Owner only.")
            ask("gh api with %s changes something on GitHub." % method)
    if re.match(r"^(secret|variable|release|workflow|run|cache|ruleset|label|issue|gist|codespace)\s+(set|delete|remove|create|edit|run|enable|disable|rerun|cancel)", s):
        ask("this gh command changes GitHub settings or spends CI minutes.")
    if re.match(r"^alias\s+set", s):
        ask("gh alias can hide commands.")


DENY_PUBLISH = [
    r"^(npm|yarn|pnpm|bun)\s+(publish|unpublish|deprecate|dist-tag|owner|access|token|adduser|login|logout)\b",
    r"^twine\s+upload", r"^cargo\s+(publish|yank|login|owner)", r"^gem\s+(push|yank|signin)",
    r"^docker\s+(push|login)", r"^(poetry|flit|uv|hatch)\s+publish",
    r"^fastlane\s+(deliver|pilot|supply|release|upload_to_\w+|match\s+nuke)",
    r"^eas\s+(submit|credentials)", r"^(\./)?gradlew?\s+.*\bpublish\w*",
    r"^xcrun\s+(altool|notarytool)", r"^pod\s+trunk\s+push",
]
ASK_INFRA = {"aws", "gcloud", "gsutil", "az", "doctl", "heroku", "flyctl", "fly", "railway", "render", "supabase", "pscale",
             "planetscale", "terraform", "tofu", "pulumi", "kubectl", "helm", "ansible", "cdk", "sam", "serverless", "sls",
             "vercel", "netlify", "firebase", "wrangler", "surge", "eas", "appcenter", "bq"}
SAFE_INFRA_SUBS = {"wrangler": {"dev", "--version", "-v", "types", "check"}}
DANGEROUS_DB = re.compile(
    r"(?i)(migrate\s+(deploy|reset)|db\s+push|db:(drop|reset|migrate:reset|schema:load)|drop\s+(database|table|schema)|"
    r"truncate\s+table|flush(db|all)|\bdropdb\b|alembic\s+downgrade|sequelize\s+db:migrate:undo:all)"
)


def rule_publish_deploy(cmd0, args, seg):
    s = " ".join([cmd0] + args)
    for pat in DENY_PUBLISH:
        if re.search(pat, s):
            deny("publishing or releasing packages and apps is the owner's job, never an agent's.")
    if cmd0 in ASK_INFRA:
        if args and args[0] in SAFE_INFRA_SUBS.get(cmd0, set()):
            pass
        elif cmd0 in ("vercel", "netlify", "firebase", "eas") and args and args[0] in ("--version", "-v", "--help", "-h"):
            pass
        else:
            ask("'%s' talks to real infrastructure or accounts." % cmd0)
    if DANGEROUS_DB.search(seg):
        ask("destructive database command. Never run against real data.")


def rule_node_tools(cmd0, args, ctx):
    pm = {"npm", "pnpm", "yarn", "bun"}
    if cmd0 in pm and args:
        sub = args[0]
        if sub in ("install", "i", "add", "ci", "update", "up", "upgrade", "install-test"):
            if "--ignore-scripts" not in args and not repo_has_ignore_scripts(ctx):
                deny("run installs with --ignore-scripts (for example 'npm ci --ignore-scripts'), then 'npm rebuild <package>' "
                     "only for a package that truly needs its install script. Install scripts run code from the internet.")
        if sub == "audit" and "fix" in args and "--force" in args:
            ask("npm audit fix --force can make breaking upgrades.")
        if sub in ("dlx", "exec", "x"):
            if "--no-install" not in args and "--no" not in args:
                ask("%s %s downloads and runs a package. Prefer a package.json script." % (cmd0, sub))
    if cmd0 in ("npx", "bunx", "pnpx", "uvx", "pipx"):
        first = next((a for a in args if not a.startswith("-")), "")
        local_bin = bool(first) and re.fullmatch(r"[A-Za-z0-9_.-]+", first) is not None and \
            os.path.isfile(os.path.join(ctx.proj, "node_modules", ".bin", first)) and cmd0 == "npx"
        if "--no-install" not in args and "--no" not in args and not local_bin:
            ask("%s downloads and runs a package. Prefer a package.json script, or use --no-install." % cmd0)


def repo_has_ignore_scripts(ctx):
    try:
        with open(os.path.join(ctx.proj, ".npmrc"), "r", encoding="utf-8") as fh:
            return bool(re.search(r"(?m)^\s*ignore-scripts\s*=\s*true\s*$", fh.read()))
    except OSError:
        return False


def rule_secrets(cmd0, tokens, args):
    if cmd0.lower() in READERS and mentions_secret(args):
        deny("that command would read a secret file. Never read .env, keys or credentials. Ask the owner for what you need.")
    if cmd0 in EXFIL and mentions_secret(args):
        deny("never send secret files anywhere.")
    if cmd0 in ("echo", "printf") and any(re.search(r"\$\{?[A-Z0-9_]*(SECRET|TOKEN|PASSWORD|PASSWD|API_?KEY|PRIVATE)[A-Z0-9_]*", a) for a in args):
        deny("do not print secret-looking environment variables.")


def rule_shell_writes(cmd0, args, seg, ctx):
    root = repo_root(ctx.cwd) or ctx.proj
    targets = []
    for m in re.finditer(r"(?:>>?|\btee\b(?:\s+-a)?)\s*([^\s;|&<>]+)", seg):
        targets.append(m.group(1).strip("'\""))
    if cmd0 in WRITERS or (cmd0 == "sed" and any(a.startswith("-i") for a in args)) or \
       (cmd0 == "perl" and any(a.startswith("-pi") or a == "-i" for a in args)):
        targets += [a for a in args if not a.startswith("-")]
    if cmd0 in READONLY and not targets:
        return
    for t in targets:
        if not t or t.startswith("&"):
            continue
        ap = resolve(t, ctx.cwd)
        if ap.startswith("/dev/"):
            continue
        if is_secret_path(ap):
            deny("never write secret files from the shell.")
        rel = rel_to_root(ap, root)
        if not rel.startswith("..") and match_any(rel, protected_edit_patterns(ctx.cfg)):
            ask("'%s' is a safety rail or CI file." % rel)


def main():
    ev = read_event()
    cmd = (ev.get("tool_input") or {}).get("command", "")
    if not isinstance(cmd, str) or not cmd.strip():
        sys.exit(0)
    ctx = Ctx(ev.get("cwd") or os.getcwd())
    set_log_context(ev.get("tool_name"), cmd, ctx.cwd)
    check_command(cmd, ctx, ps=(ev.get("tool_name") == "PowerShell"))
    finish()


if __name__ == "__main__":
    try:
        main()
    except SystemExit:
        raise
    except Exception as exc:  # fail closed
        sys.stderr.write("BLOCKED by the safety kit: guard_bash.py failed (%s). Ask the owner to run the self-test.\n" % exc)
        sys.exit(2)
