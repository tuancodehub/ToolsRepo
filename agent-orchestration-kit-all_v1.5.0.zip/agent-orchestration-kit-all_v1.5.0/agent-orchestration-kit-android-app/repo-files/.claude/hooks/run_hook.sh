#!/bin/sh
# Starts one safety hook with whichever Python 3 is installed (python3, python or py).
# Fails CLOSED: if no Python 3 works, the tool call is blocked (exit 2) instead of running unguarded.
script="$1"
shift
dir=$(dirname "$0")
for py in python3 python py; do
  if command -v "$py" >/dev/null 2>&1 && "$py" -c "import sys; sys.exit(0 if sys.version_info[0] == 3 else 1)" >/dev/null 2>&1; then
    exec "$py" -I "$dir/$script" "$@"
  fi
done
echo "BLOCKED by the safety kit: Python 3 was not found, so the safety hooks cannot run. Install Python 3 (see docs/orchestration/LOCAL-MODE.md), then try again." >&2
exit 2
