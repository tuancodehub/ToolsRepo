---
description: Show the feature queue, who has claimed what, and any overlap warnings. Costs almost nothing.
argument-hint: (no arguments)
model: haiku
---

Run `python3 -I scripts/orchestration/queue_status.py`. Then paste the ENTIRE output in your reply as plain text inside a code block: every numbered feature with its goal line, the DONE line and any warnings. Do not shorten it, summarize it or replace it with a count: the owner reads it on a phone and the tool output is folded away there. Then add at most two lines: which feature is NEXT (it is marked `<-- NEXT`), and any warning that needs the owner's attention. Do not run anything else.

End your final reply with the "Learn more" part described in CLAUDE.md (3 follow-up questions or considerations, 2 new topics to explore).
