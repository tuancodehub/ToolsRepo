---
description: Add a feature to the queue (a brief with status "queued") through a small pull request, so you can line up work from any device.
argument-hint: <feature-slug> <one paragraph describing what you want>
model: sonnet
---

Add one feature to the queue. Arguments: $ARGUMENTS (first word = slug; the rest = the owner's description).

1. Validate the slug: lowercase letters, numbers and dashes, 2 to 41 characters. Check that `docs/briefs/<slug>.md` and the remote branch `feature/<slug>` do not already exist (`git ls-remote --heads origin feature/<slug>`). If they do, say so and stop.
2. Start from the default branch on a new branch `chore/queue-<slug>` (never edit a protected branch).
3. Create `docs/briefs/<slug>.md` from `docs/briefs/_TEMPLATE.md`: replace `{{SLUG}}` and `{{DATE}}`, set `status: queued`, write the owner's description under Goal exactly as given, guess `risk` (low, medium or high; see docs/orchestration/COST-POLICY.md) and a first `touches` list with a quick search of the code (do not do a full plan: /build-feature does that). Leave the other sections as the template has them.
4. Run `python3 -I scripts/orchestration/queue_status.py` and tell the owner if this feature's `touches` overlap an active feature.
5. Commit with explicit paths, push with `python3 -I scripts/orchestration/feature_git.py push` and open a pull request titled "queue: <slug>" with `gh pr create`. Do not merge.
6. Finish with the PR link and: "Merge it to put <slug> in the queue. When you want to build the next one, run /clear (or start a new session) and then /build-next. To build this one specifically, run /build-feature <slug>. To set its place in the build order, edit `order:` in its brief."

End your final reply with the "Learn more" part described in CLAUDE.md (3 follow-up questions or considerations, 2 new topics to explore).
