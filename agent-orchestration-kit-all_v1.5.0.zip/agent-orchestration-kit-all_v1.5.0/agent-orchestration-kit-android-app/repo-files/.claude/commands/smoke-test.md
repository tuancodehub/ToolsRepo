---
description: Prove the kit works in THIS repository and THIS environment before you rely on it (hooks, claims, agents, models, checks).
argument-hint: (no arguments)
model: sonnet
---

Run a safe end-to-end test of the orchestration kit. Report plainly; do not hide failures. Never attempt a dangerous command to "see if it is blocked": the self-test already proves that safely in a throw-away repository.

0. **Kit version.** Run `python3 -I scripts/orchestration/kit_version.py check`. Report the version it prints ("Kit version: ...") and the "Kit files" line. Missing files are a FAIL; changed safety files are a warning to show the owner (they may be the owner's own changes). If the version is UNKNOWN, say the install is incomplete.
1. Run `python3 -I scripts/orchestration/selftest.py` and show the summary line and any FAIL lines.
2. Hooks are live: ask the owner to confirm the SessionStart orientation text ("[orchestration kit] ...") appeared at the start of this session. If you did not see it, report that hooks may not be running in this environment and point to docs/orchestration/TROUBLESHOOTING.md.
3. Run `python3 -I scripts/orchestration/run_checks.py --list`, then `python3 -I scripts/orchestration/run_checks.py` and report the RESULT line and any SKIP lines (a skipped required check means CI must cover it).
4. Run `python3 -I scripts/orchestration/queue_status.py` and `python3 -I scripts/orchestration/changed_areas.py`.
5. Agents are reachable: call each of these with the prompt "Reply with one line: your role and which model you are." and report the replies in a small table: planner, brief-auditor, builder, checks-runner, quality-reviewer, ux-reviewer, security-reviewer, pr-writer. Expected tiers: planner, builder and security-reviewer on the top tier; the others on lower tiers (see docs/orchestration/MODELS.md). Say clearly if a reply does not match, since a model setting can be ignored.
6. Local modes only: run `python3 -I scripts/orchestration/set_workspace.py --check` and report every line. Then confirm the folder fence by asking the owner to check that the SessionStart text says the allowed folders; do NOT try a forbidden command to test it (the self-test already proves the rules safely).
7. Claim test (needs the owner's OK; in cloud and local-github modes it pushes one small branch, in local mode it creates one local branch): ask once with AskUserQuestion. If yes: run `python3 -I scripts/orchestration/feature_git.py claim kit-smoke-test`, create `docs/orchestration/SMOKE-TEST-RESULT.md` with today's date and the results above, commit it with an explicit path, push with `feature_git.py push`, then tell the owner they can delete the branch `feature/kit-smoke-test` (on GitHub, and locally with `git branch -D`; in local mode only locally) and, in local modes, free the slot with `feature_git.py release kit-smoke-test`. Do not open a pull request.
8. Finish with the kit version in use, a PASS / NEEDS ATTENTION verdict and the list of items to fix.

End your final reply with the "Learn more" part described in CLAUDE.md (3 follow-up questions or considerations, 2 new topics to explore).
