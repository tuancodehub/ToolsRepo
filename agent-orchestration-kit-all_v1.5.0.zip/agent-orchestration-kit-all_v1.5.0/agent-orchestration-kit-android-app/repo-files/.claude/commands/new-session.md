---
description: Local modes only. Create a separate folder (worktree) so a second Claude session can build another feature at the same time.
argument-hint: <feature-slug>
model: haiku
---

Set up a parallel session for the feature "$ARGUMENTS" on this computer.

1. Run `python3 -I scripts/orchestration/set_workspace.py --show`. If the mode is cloud, say: "This only applies when you work on your own computer. In cloud mode, just start a new cloud session for each feature." and stop.
2. Run `python3 -I scripts/orchestration/feature_git.py sessions` and show how many sessions are running against the limit. If the limit is reached, explain and stop (the owner finishes one first).
3. Run `python3 -I scripts/orchestration/worktree.py add $ARGUMENTS`. If it is refused, explain the reason in plain words and stop.
4. Tell the owner, in a short numbered list they can follow on a phone-sized screen:
   - Open a NEW terminal window (a second one, leave this one running).
   - Go into the new folder (show the exact `cd` line from the script output).
   - Install what the project needs in that folder (name the exact command from docs/orchestration/STACK-PROFILE.md; install scripts off).
   - Start Claude there and run `/build-feature $ARGUMENTS`.
   - Use the port numbers the script printed for dev servers in that folder, so it does not clash with the other session.
5. Remind them: each session has its own cost, pushes take turns (a pause between them is normal), and the other session should not edit the same files. Do not start building the feature in this session.

End your final reply with the "Learn more" part described in CLAUDE.md (3 follow-up questions or considerations, 2 new topics to explore).
