---
description: Build the next feature in the queue: picks the first queued feature whose dependencies are all merged, tells you which one and why, then builds it exactly like /build-feature.
argument-hint: (no arguments; optional extra instructions for the feature)
model: opus
---

Build the next ready feature. Optional extra text from the owner: $ARGUMENTS

1. Run `python3 -I scripts/orchestration/queue_status.py --next`.
   - If it prints a slug, that is the feature. Run `python3 -I scripts/orchestration/queue_status.py` and look up that feature's number and goal line.
   - If it prints nothing (exit 1), stop. Run `queue_status.py`, paste the whole table in your reply as plain text, and explain in one line why nothing is ready (for example: the pull request of the last feature is not merged yet, or every queued feature is waiting on a dependency). Do not pick a feature yourself.
2. Tell the owner, in 3 lines: which feature (its number in the build order and its goal), why it is next (first in order with every dependency merged), and what comes after it. Do not ask for approval here: the planning questions in the next step are the owner's chance to change course.
3. Read `.claude/commands/build-feature.md` and follow it exactly for that slug, treating any extra text from the owner as the request. Everything in it applies: claim, planning, questions, unattended build, checks, preview gate, pull request.
4. This session may have built a feature before. That is fine: the claim starts the new branch from the latest default branch. Never reuse the old feature's branch. Do not carry decisions over from the previous feature unless they are in the code or in `docs/briefs/`.
