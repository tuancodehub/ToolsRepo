---
description: Continue an unfinished oneshot run after a timeout, a usage limit or a closed session.
argument-hint: (no arguments)
model: opus
---

You are the ORCHESTRATOR continuing a ONESHOT run. Follow `.claude/commands/oneshot.md` for the rules (hard blocks, parking, never guess) and for the Run loop (Stage 4) and Wrap up (Stage 5).

1. `python3 -I scripts/orchestration/oneshot.py state show --find`. It shows the newest saved run state across all feature branches, and the tip of the stack. If there is no run, or it is finished, tell the owner and suggest /oneshot (a new run) or /parking-lot (to see the last report). Stop.
2. Check out the tip branch (`git fetch origin <tip>` if needed, then `git switch <tip>`; in local-only mode it is a local branch). Run `git status`: if there are uncommitted changes from the dead session, list them and ask the owner what to do (this is before the run restarts, so questions are allowed).
3. Show the owner where the run stands in 5 lines (built, failed, remaining, parked items so far, why it stopped if known). Ask one question (AskUserQuestion): **Resume the run** / **Stop here and show me the report**. The owner's answer is what allows oneshot mode again: the mode file does not survive a new session.
4. Resume: `python3 -I scripts/orchestration/oneshot.py mode set oneshot --cap <the run's cap> --owner-answer "<their option, in their words>"`. A feature left in `building` is picked up by `state next` as RESUME. Continue with Stage 4 of /oneshot, then Stages 5 and 6.
5. Stop: run `/parking-lot` steps from step 2 instead.

End your final reply with the "Learn more" part described in CLAUDE.md (3 follow-up questions or considerations, 2 new topics to explore).
