---
description: The oneshot report. Summarises every feature that was built, then walks the owner through every parked question, concern and guess, one at a time, and applies the owner's choices in one follow-up pull request.
argument-hint: (no arguments)
model: opus
---

You are the ORCHESTRATOR presenting a oneshot run's report. The owner may be on a phone: short, plain, no jargon. Everything the owner chooses here is recorded; you never merge, approve or mark a pull request ready.

## Steps
1. Load the run. `python3 -I scripts/orchestration/oneshot.py state show --find` prints the newest run and `TIP <branch>`. Switch to the tip branch (it contains every earlier feature's parking-lot files). If there is no run, say so and stop. Run `python3 -I scripts/orchestration/oneshot.py mode end` (the run is over; normal approvals apply again).
2. **Summary of the run**, at most 15 lines: for each feature, in order: number, name, one-line goal, risk, result (built, failed, skipped), pull request link. Then the totals, why the run stopped if it did not finish, and the cost line (ask the owner to run `/cost` and note it).
3. **Counts.** `python3 -I scripts/orchestration/park.py list --open` and the counts by type. Say how many need the owner's decision (`open`, `question`, `risk`, `concern`) and how many are just a checklist (`assumption`, `human-test`).
4. **Decisions, one batch at a time.** Order: `open` (money, tax, legal, names, links, credentials), then `risk`, `question`, `concern`, then `assumption`. High severity first within a type. For each item, read it with `park.py show <id>`, then explain in plain words: what was found, why it matters, what was done instead. Ask with AskUserQuestion (up to 4 items per call; each question stands alone; 2 or 3 options with your recommended one first and marked "(Recommended)"; always include **Leave as it is**). For an `open` item that needs a fact only the owner has (a price, a legal sentence), ask them to type it (the "Other" answer) or leave the placeholder. Record each answer: `park.py resolve <id> --decision "<the owner's choice>"`.
5. **Checklist.** Show the `human-test` items as a plain list the owner can work through (what to check, on which device, in which feature). Mark them resolved only when the owner says they checked.
6. **Apply the choices.** If any decision means a change, make it in ONE follow-up pull request on top of the stack, so nothing already built is rewritten: `feature_git.py claim oneshot-followups --base <tip>`, a brief listing each decision as in scope (quote the owner's answer), the **builder** agent, **checks-runner** (at most 2 fix rounds), reviewers as `changed_areas.py` says, commit (with the resolved parking-lot files), `feature_git.py push`, and a DRAFT pull request with `--base "$(python3 -I scripts/orchestration/feature_git.py pr-base)"`. In local-only mode, mark it `ready-to-merge`. Do not use `--force` or rewrite earlier branches.
7. **Command report (so the next run asks less).** Run `python3 -I scripts/orchestration/hook_log.py summary`. In plain words tell the owner: how many commands were blocked for good (hard blocks, working as intended), how many would have asked them and were blocked in oneshot (these cost the run a detour), and which kinds of command were allowed without asking. Then tell the owner they can run the built-in `/fewer-permission-prompts` command: it reads this session's history and suggests safe commands to stop asking about. Remind them to approve only read-only or test commands, never anything that installs, deletes, publishes or reaches the network. The settings file is a safety file: agents cannot edit it, so the owner adds approved lines to `.claude/settings.local.json` (not committed) themselves.
8. **Finish** with:
   - the merge order: the plan pull request first, then each feature in order, then the follow-up one. Each is a draft: the owner marks it ready for review (so the checks run) and then merges it.
   - "Turn on 'Automatically delete head branches' in the repository settings: GitHub then retargets the next pull request to the default branch when the one below it is merged. If it does not, change the base branch on the next pull request by hand."
   - what is still OPEN, and the human-test checklist.
   - "Before the next feature or run: merge, then run /clear (or start a new session)."

End your final reply with the "Learn more" part described in CLAUDE.md (3 follow-up questions or considerations, 2 new topics to explore).
