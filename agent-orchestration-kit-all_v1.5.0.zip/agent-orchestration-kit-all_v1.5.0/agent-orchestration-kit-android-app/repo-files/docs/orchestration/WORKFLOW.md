# Workflow

The exact steps are in `.claude/commands/build-feature.md`. This page explains them in plain language.

## Statuses (in each brief's front matter)
`queued` (idea in the queue) → `claimed` (a session owns the branch) → `planning` → `building` → `reviewing` → `preview` (waiting for you) → `pr-open` → `merged`. Side exits: `on-hold`, `cancelled`.

The status lives in the feature's own brief file (`docs/briefs/<slug>.md`), never in a shared table, so two features never edit the same line and never conflict. `/queue-status` builds the table for you: a numbered build order (set `order: 1, 2, 3...` in each brief), each feature's one-line goal, and a `<-- NEXT` marker on the first feature whose dependencies are all merged. `/build-next` builds that one.

## Phase by phase
| Phase | Who | Output | Your part |
|---|---|---|---|
| 0 Claim | orchestrator + script | branch `feature/<slug>` on GitHub, brief file | none |
| 1 Plan | planner (Opus) | plan, risks, decisions list | none |
| 2 Intake | orchestrator | answers saved in the brief | **Answer the questions** (gate 1) |
| 3 Audit | brief-auditor | READY / NOT READY | maybe 1 more question |
| 4 Build | builder (Opus) | code and tests, committed | none (unattended) |
| 5 Check + review | checks-runner, reviewers | results; at most 2 fix rounds | none |
| 6 Preview | orchestrator | preview link or steps, summary | **Look and choose** (gate 2) |
| 7 Ship | pr-writer, orchestrator | pull request | **Merge it yourself** (gate 3) |

## What "unattended" means
After gate 1 the build does not ask you anything. If something is truly missing, the builder stops with `BLOCKED` and the orchestrator asks you; it never guesses. Anything you could not answer at gate 1 is marked OPEN in the brief with a safe fallback, and the summary tells you what is waiting.

## Make changes after the preview
Choose "Make changes", describe them, and the builder updates the branch; checks and the needed reviewers run again. Each round costs money, and the orchestrator says so.

## Hold, cancel, or a feature that went wrong
- **Hold:** the branch and brief stay as they are. Set `status: on-hold` and start again later with `/build-feature <slug>` in a new session (you will be told the branch exists; confirm it is yours and use the resume option).
- **Cancel:** close the pull request if there is one, delete the branch on GitHub, and set the brief to `cancelled` in a small PR (or delete the brief).
- **Bad merge:** use GitHub's "Revert" button on the merged pull request.

## Two features that touch the same files
`touches:` in each brief lets `/queue-status` warn about overlap. Merge one first, then start (or update) the other. Never run overlapping features in parallel.

## Why there are three gates and not more
The planning questions are where your judgment is cheapest and matters most. The preview is where you see the real result. The merge is the irreversible step. Anything between runs on its own so you are not tied to the screen.

## Oneshot alternative
Instead of one feature at a time, `/oneshot` asks all questions first and builds the whole queue as stacked draft pull requests; `/parking-lot` is the report. Details: `ONESHOT.md`. After each finished feature `/build-feature` asks which way to continue.
