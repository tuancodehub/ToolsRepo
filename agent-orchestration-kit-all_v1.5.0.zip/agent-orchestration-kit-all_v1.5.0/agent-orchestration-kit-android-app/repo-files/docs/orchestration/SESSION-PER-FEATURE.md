# One feature at a time per session (from any device)

## The rule
One feature = one branch `feature/<slug>` = one pull request. A session may build several features, one after another, never two at once. Between features: merge the pull request, run `/clear` (or start a new session), then run `/build-next`. A new session is the cleanest start (empty context, clean workspace); `/clear` in the same session also works and saves the dependency re-install. Do not carry a long conversation from one feature to the next.

## Starting a feature from any device
1. Open Claude (web, desktop or phone) signed in to your account and start a new coding session attached to this repository.
2. Type: `/build-feature <slug> <what you want in your own words>`.
3. Answer the planning questions when they appear (this can take a few minutes). Then you can put the phone away: the build runs on its own.
4. Come back later, from any device, to the same session for the preview question.

Nothing is stored on the device. The plan lives in `docs/briefs/<slug>.md` on the feature branch, the code is committed to the branch, and the claim is the branch on GitHub. If a session is lost, the work up to the last push is safe.

## How collisions are prevented (the claim)
`/build-feature` begins by claiming the branch with `feature_git.py claim <slug>`. The script refuses if `feature/<slug>` already exists on GitHub, and otherwise creates it and pushes immediately. Two devices starting the same slug at the same moment: one wins, the other is told it is already claimed. Different slugs never collide.

## If a session dies
Start a NEW session. Run `/build-feature <slug>`. It will say the feature is already claimed. If you are SURE the old session is gone, tell the orchestrator to resume: it runs `feature_git.py resume <slug>`, which checks out the existing branch. Do not resume while another session might still be writing to it.

## How many at once?
- **Two or three sessions at a time is fine; one or two is easiest to follow.** Each runs on its own and has its own cost.
- **Start them at least a minute apart.** The git connection allows only a couple of simultaneous transfers per repository; three sessions pushing in the same second can get a "too many requests" error. The scripts wait about 6 seconds and retry exactly once. If it still fails, wait a minute and push again. Nothing is lost.
- **Never run overlapping features at the same time** (see `touches:` in the briefs). Merge one first.
- **Pushes are rare by design:** claim, end of planning, end of build/review, and any fix rounds. Agents push only through `feature_git.py push`.

## What a new session has to redo
A new session starts from a fresh copy of the repository: it re-installs dependencies (a few minutes) and re-reads `CLAUDE.md`. That is the price of a clean slate and it is much cheaper than carrying a long conversation forward.

## Shallow copies
Cloud sessions often clone with limited history for speed. The scripts fetch only what they need (the default branch tip and your feature branch). If an agent needs older history, it fetches a bounded amount; it never downloads everything.

## On your own computer (local modes)
The same rule holds: one feature, one session, one branch. A "session" is then a terminal window running Claude in a project folder.
- **One feature at a time:** work in the main project folder.
- **Several at once:** each feature gets its own folder (a worktree) made by `/new-session <slug>`, and its own Claude session in its own terminal window. See `LOCAL-MODE.md`.
- **Limits that protect you:** at most `max_sessions` (default 2) at once; a push lock and a pause between pushes (local-github); an overlap check before building; one set of dev-server ports per folder.
- **If a terminal is closed mid-feature:** the work up to the last commit is in that folder. Open a terminal there, start Claude, and run `/build-feature <slug>`; if the session slot is still held, the owner frees it with `feature_git.py release <slug>` and resumes with `feature_git.py resume <slug>`.
- **Local-only mode:** nothing is pushed. Commits stay on your computer until you merge with `local_merge.py`. Back the folder up.
