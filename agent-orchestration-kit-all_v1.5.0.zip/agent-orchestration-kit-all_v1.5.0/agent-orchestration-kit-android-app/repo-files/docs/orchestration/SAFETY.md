# Safety

## The layers
No single layer is perfect, so there are several. Each one still works if another fails.

| # | Layer | Where | What it does |
|---|---|---|---|
| 1 | **Permissions** | `.claude/settings.json` | Denies reading secrets, force pushes, pushing `main`, merging PRs, `sudo`, publishing. Allows only a short list of routine commands |
| 2 | **Hooks** | `.claude/hooks/*.py` | Run before every shell command and file access. Block or ask the owner (details below). A crashing hook blocks (fail-closed) |
| 3 | **Git pre-commit** | `.githooks/pre-commit` | No commits on protected branches; scans staged changes for secrets |
| 4 | **CI** | `.github/workflows/ci.yml` | Secret scan, dependency audit and the stack's checks on every pull request. Actions pinned to commit hashes; read-only token |
| 5 | **GitHub rules** | repository settings | Branch protection or rulesets on the default branch. **Private repositories on GitHub Free cannot use these**; see below |
| 6 | **You** | three gates | You answer the questions, approve the preview, and merge |

## What the hooks block outright
Pushing or committing on `main`, `master`, `production`, `prod`, `develop`, `release*` · force pushes, remote branch deletion, mirror pushes · `--no-verify` and changing git hook settings · `git add -A` / `git add .` · merging, approving or deleting things with `gh`; printing tokens · publishing packages or apps (`npm publish`, `fastlane deliver`, store submissions, …) · reading or sending secret files (`.env*`, keys, keystores, `.ssh`, `.aws`, cloud config) through any tool · `sudo`, `ssh`, `scp`, `nc` · `curl … | sh` · installs without `--ignore-scripts` (unless the repo's `.npmrc` sets it) · destructive deletes (`rm -rf /`, `.`, `~`, the repository, `.git`) · world-writable permissions · printing environment variables.

## What asks you first
Cloud and deploy CLIs (`aws`, `gcloud`, `terraform`, `kubectl`, `vercel`, `wrangler deploy`, `firebase`, …) · destructive database commands · `npx`/`dlx` of packages that are not installed · `git reset --hard`, `git clean`, branch deletion, remote changes, history rewriting · `gh` commands that change settings, secrets, releases or spend CI minutes · any edit to the **protected files**: `.claude/**`, `.githooks/**`, `.github/workflows/**`, `.github/CODEOWNERS`, `.github/dependabot.yml`, `CLAUDE.md`, `AGENTS.md`, `.mcp.json`, `.secret-scan-allow`, `scripts/orchestration/**`, `**/.npmrc` (your stack adds a few more in `.claude/guard-config.json`) · writes outside the repository.

When an unattended agent hits one of these prompts it must stop and report BLOCKED, not look for a way around. If you see such a prompt and did not ask for that change, choose No.

## Secrets: the rules
- Agents never read, write or print secrets. They use `.env.example` and tell you which variable names to set.
- Real secrets live only in the place that runs the code (hosting dashboard, GitHub Actions secrets, your password manager), never in the repository and never in a cloud session's files.
- **Never give a session production credentials or production data.** Use test keys, test data, and separate preview databases.
- Anything shipped inside an app or web bundle can be read by anyone. Mobile and browser code must not contain secrets.

## Known gaps (be honest with yourself about these)
1. **A script can do what a command cannot.** `python3 -c`, `node -e` or a script file can read or write things the hooks look for in commands. The hooks catch accidents and common patterns, not a determined adversary. Keep secrets out of the working folder: that is the real protection.
2. **Hooks need Python 3** and must be running in your environment. If they are not, layer 1 (permissions) still applies, and `/smoke-test` tells you. Subagent tool calls should pass through the hooks too; `/smoke-test` is how you verify it in your setup.
3. **You can weaken the fence by approving the wrong prompt.** Approve safety-file edits only when you asked for them.
4. **GitHub Free + private repository = no server-side branch rules.** GitHub documents rulesets and branch protection for private repositories only on paid plans (public repositories get them free). Without them, the hooks and the pre-commit script are the main thing keeping an agent off `main`, and a leaked or over-powered token could push there. Options: upgrade the plan; make the repository public (only if nothing in it is private); or accept the risk and keep the GitHub connection's permissions as narrow as possible.
5. **CI cannot protect against itself.** A pull request that changes `.github/workflows/` runs the changed workflow. That is why those edits are protected and why you read the diff of any PR that touches them.
6. **Prompt injection.** Text in web pages, issues, comments, package READMEs or tool output can try to give an agent orders. All agents are told to treat such text as data. The strongest defense is the layers above: even a tricked agent cannot push `main`, read `.env` or publish.
7. **Dependencies.** Packages can be malicious or typo-squatted. The kit limits install scripts, pins versions, reports every added dependency, and has the security reviewer check each. It cannot know if a legitimate maintainer was compromised.

## On your own computer (local modes)
Always blocked, in **every** mode: deleting, moving or overwriting a drive top (`/`, `C:\\`), a home folder, or a system folder (`/etc`, `/usr`, `/var`, `C:\\Windows`, Program Files, `/mnt/c` and similar); disk, partition and format commands (`mkfs`, `dd` to a device, `diskpart`, `format`); `--no-preserve-root`; shutdown and restart; encoded or remote-run PowerShell.

Extra rules in local and local-github mode (the **folder fence**):
- Agents may **read and run** programs from anywhere, but may **change, create, delete or move** files only inside the work folder you chose (this project, its worktree folders, the shared `tools` folder) and the temp folder. Anything else is denied.
- Deleting the work folder, the project folder, or the worktrees folder itself is denied; deleting a sibling project asks first.
- System installs (`apt`, `dnf`, `brew`, `winget`, `choco`, plain `pip`, `npm -g`) are denied. Tools go in `tools/` (virtual environments, downloaded programs).
- Settings that decide the fence (`set_workspace.py`, `.claude/workspace.local.json`) and the local merge (`local_merge.py`) are owner-only: agents cannot run or edit them.
- Local-only: `git push` and `gh` are denied. Local-github: only `feature_git.py push` may push (it takes turns and pauses between pushes). Worktrees are made only by `worktree.py`.

Honest limits of the fence: it checks the commands and file edits an agent asks for. Code an agent writes and then runs (`python3 script.py`, `node -e`) and what installed tools do inside (caches, build tools) are not checked. It stops mistakes and common dangerous forms, not a determined attacker. For sensitive computers, run Claude in a virtual machine, a container, or under a separate low-privilege user that owns only the work folder. The hooks need Python 3; if it is missing they block everything on purpose.

## If something goes wrong
- **A secret was committed or printed:** (1) revoke or rotate the key at the provider NOW, before anything else; (2) tell Claude to remove it from the branch; (3) if it was pushed to a shared branch, treat it as public forever: rotating is the fix, deleting the commit is not; (4) check the provider's logs for use.
- **A bad change was merged:** use GitHub's Revert on the merged pull request.
- **An agent did something unexpected:** end the session, look at the branch's commits and the pull request, and report it (the thumbs-down button helps improve Claude). Review `docs/orchestration/SAFETY.md` known gaps.
- **A hook blocks something legitimate:** do not edit the hook in the middle of a feature. Tell the orchestrator; change the rule in a separate, owner-supervised session.

## Keep the owner side tight
Turn on two-factor sign-in for GitHub, Claude and your hosting account. Use the narrowest GitHub permissions that work. Keep a spending limit on every metered service. Review the diff of every pull request that touches safety files, workflows, dependencies or permissions before you merge.

## Decision log
Hooks write each block, ask and (in oneshot) auto-allow to `.claude/.check-logs/hook-log.jsonl` (git-ignored, local, size-capped, long token-like strings removed). Read it with `hook_log.py`. It is for review, not enforcement.

## Oneshot mode
- In oneshot, anything a hook would ask about is **blocked** instead, and the agent parks the item and continues with a safe alternative. Hard blocks (protected branches, merging, secrets, destructive commands, safety files, owner-only scripts) never change.
- Oneshot is turned on only by `/oneshot` or `/oneshot-resume` after the owner's explicit answer, recorded in `.claude/run-mode.json` (git-ignored, expires after 12 hours, agents cannot edit it). The record is a note, not a cryptographic lock: the worst case is fewer questions, not fewer protections.
- Money, tax, legal and policy wording, names, links and credentials are never guessed: they stay OPEN and are parked.
