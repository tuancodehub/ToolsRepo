# Models: who uses what, and how to change it

## Current assignment (standard mode)
| File | `model:` | Tier |
|---|---|---|
| `.claude/commands/build-feature.md`, `init-project.md` | `opus` | Top |
| `.claude/commands/add-feature.md`, `smoke-test.md` | `sonnet` | Mid |
| `.claude/commands/queue-status.md` | `haiku` | Low |
| `.claude/agents/planner.md`, `builder.md`, `security-reviewer.md` | `opus` | Top |
| `.claude/agents/brief-auditor.md`, `quality-reviewer.md`, `ux-reviewer.md` | `sonnet` | Mid |
| `.claude/agents/checks-runner.md`, `pr-writer.md` | `haiku` | Low |

A command's `model:` line chooses the orchestrator's model while that command runs.

## Aliases versus pinned versions
The kit uses the aliases `opus`, `sonnet` and `haiku`. An alias follows the newest model of that tier, so you get improvements automatically and nothing in these files goes stale. The trade-off is that behavior and price can change when a new model arrives. If you want stability, replace an alias with a full model ID (for example `claude-opus-5-5`, `claude-sonnet-5-5`, `claude-haiku-5-5`, the names current when this kit was written) and update it on your schedule. Model names change over time: check Anthropic's documentation for the current list.

## How to change a model
Ask Claude: "run `python3 -I scripts/orchestration/set_models.py --show`" to see the table, or "`--set builder=sonnet`" to change one. These files are protected, so you will be asked to approve the edit. Or edit the `model:` line in the file by hand on GitHub.

## Settings are not always honored
Per-agent model settings can be ignored in some versions or surfaces. `/smoke-test` asks each agent which model it is and shows you the result. Re-check after Claude Code updates, and watch `/cost`.

## Why not cheaper models for building?
The builder writes the code that runs your product; a subtle mistake there costs more than the token difference, and the security reviewer cannot catch everything. Savings come from not running unneeded reviewers, using scripts for mechanical work, short contexts, and small features. For a low-risk feature you may still choose a Sonnet builder at intake.

## Changing tiers for a whole project
- **Lean:** set `planner` and `builder` to `sonnet` only for projects with no sensitive data and no logins. Keep `security-reviewer` on `opus`.
- **Maximum quality:** set `quality-reviewer` to `opus`. Expect higher cost per feature.
- Never put `security-reviewer` below the top tier on a project with logins, payments or personal data.
