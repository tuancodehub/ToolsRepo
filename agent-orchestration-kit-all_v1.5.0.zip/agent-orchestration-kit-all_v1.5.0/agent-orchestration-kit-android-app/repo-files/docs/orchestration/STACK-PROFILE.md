# Stack profile: Android app

## What this covers
Native Android apps written in Kotlin (Jetpack Compose or classic Views) and built with Gradle. For cross-platform apps built with React Native or Expo, use the *mobile (Expo)* kit instead.

## How work happens without a phone in the loop
The cloud session can edit code, run Gradle (lint, unit tests, a debug build) and push. It cannot run the app on a phone or emulator. So:
- Agents rely on lint, unit tests and the debug build to catch mistakes.
- **Your preview** is a debug APK: CI builds it for every pull request and attaches it as a downloadable file ("debug-apk") on the checks page, kept 3 days. Download it on an Android test phone and try the feature, then approve or ask for changes (gate 2).
- Sideloading needs "install unknown apps" turned on for your browser or file manager on a test phone. Use a spare phone or a test profile if you can.

## Before the first feature
- Project builds with `./gradlew assembleDebug` on a clean machine; the Gradle wrapper files are committed.
- Java 17 matches CI (change `ci.yml` if your project needs another version).
- Keep release signing out of the repository: keystores, passwords and Play Console keys live with you (or a secrets manager), never in a session. Debug builds use the standard debug key only.
- Consider a version catalog (`gradle/libs.versions.toml`) so dependency changes are easy to review.

## Checks
Required: `lint` (`lintDebug`), `unit-tests` (`testDebugUnitTest`), `build-debug` (`assembleDebug`), `secrets`. Instrumented (on-device) tests are not run in CI by default because emulators are slow and costly; add them later if you need them.

## Risk guide
- **low:** strings, colors, layouts, icons, small UI polish.
- **medium:** new screens, navigation, local storage, new library.
- **high:** new permissions, sign-in, networking or certificate settings, payments or in-app billing, background services, exported components (activities, receivers, providers), WebView, file sharing, encryption, release or signing configuration, anything with personal data.

## Cost notes
- CI: one Linux job of about 8 to 25 minutes per pull request (Gradle is slow the first time; caching helps). A free private repository gets 2,000 Linux minutes a month, so a handful of features a week fits.
- APK artifacts count toward storage; 3-day retention keeps it small.

## Limits and honesty
- No visual or touch testing from the cloud: you are the tester. Ask for screenshots in the brief if you want them (via a test that renders previews) but expect rough edges.
- Play Store listing, privacy declarations, data-safety forms and age ratings are yours.
- Google Play requires up-to-date target API levels; dependency upgrades may need their own features.

## Local testing (local modes; see `LOCAL-MODE.md`)
- You install Android Studio, the SDK and an emulator (or enable developer mode on a test phone). Agents only read and run them; they cannot install into your system.
- Build a debug APK with `./gradlew assembleDebug`, then install it with `adb install` on **one** emulator or phone. Run one emulator at a time, or give each session its own virtual device and tell `adb` which one with `-s <serial>`.
- Gradle keeps its own cache in your home folder; that is normal. Use a **test account and fake data**, never real accounts or production keys.
- Never commit keystores or signing files.

## Oneshot notes
See `docs/orchestration/ONESHOT.md`. EXPERIMENTAL. Touch, device sizes, signing, store settings and real hardware need a human. Android CI also runs on every push to `feature/**` (more minutes).
