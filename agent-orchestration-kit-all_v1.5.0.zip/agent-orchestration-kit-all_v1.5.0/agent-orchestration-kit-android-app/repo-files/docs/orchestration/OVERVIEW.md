# Orchestration overview

*The one-page summary. Everything else in this folder explains a part of it.*

## What this is
A ready-made way to have a team of AI agents plan, build, check and review features in your repository, while you stay in control. You choose where the work happens: **in Claude's cloud sessions plus your GitHub repository** (start, watch and finish from any computer or phone; the repository is the memory), **on your own computer** (so you can run and test apps on your own emulator or phone), or **on your own computer connected to GitHub**. In the local modes agents may change files only inside one work folder you choose (`LOCAL-MODE.md`).

## The cast
| Role | Model tier | What it does |
|---|---|---|
| **Orchestrator** (the main session) | Top (Opus) | Claims the feature, runs the pipeline, asks you every question up front, never writes feature code |
| **planner** | Top (Opus) | Reads the code and writes the plan, risks, and the list of decisions you must make |
| **brief-auditor** | Mid (Sonnet) | Checks the plan is complete enough to build with nobody watching |
| **builder** | Top (Opus) | Writes the code and tests from the finished brief. Never asks you anything, never pushes |
| **checks-runner** | Low (Haiku) | Runs the automated checks and reports only failures |
| **quality-reviewer** | Mid (Sonnet) | Checks correctness against the brief, tests, scope |
| **ux-reviewer** | Mid (Sonnet) | Checks accessibility, plain wording, truthfulness (only when the UI or text changed) |
| **security-reviewer** | Top (Opus) | Checks for secrets, injection, auth holes, risky dependencies (every change except docs-only) |
| **pr-writer** | Low (Haiku) | Writes the pull request description |

## The life of a feature (three gates are yours)
1. **Claim.** `/build-feature <slug>` claims `feature/<slug>` on GitHub. If another session already has it, you are told and nothing starts.
2. **Plan.** The planner studies the code and drafts the plan and decisions.
3. **Gate 1: your questions.** The orchestrator explains each decision in plain words, with options and a recommendation, and asks everything the build could need, so it never has to stop later.
4. **Audit.** The brief-auditor confirms nothing is missing.
5. **Build, unattended.** The builder works. Checks run. Only the reviewers the change needs run. At most 2 fix rounds.
6. **Gate 2: your preview.** You look at it (link, test build or steps for your stack) and choose Approve, Make changes or Hold.
7. **Pull request.** Only after you approve. The pr-writer drafts the description.
8. **Gate 3: you merge.** Agents can never merge or approve.

## One feature at a time, with a clean slate between
Each feature has its own branch and pull request. A session may build several features in a row, but never two at once. After each feature you merge, run `/clear` (or start a new session) so the next one starts with an empty, cheap context, then run `/build-next`. A fresh session is the cleanest start; `/clear` in the same session is faster and works because the claim always starts from the latest default branch. You can run two or three sessions side by side from different devices; start them a minute apart and see `SESSION-PER-FEATURE.md`. On your own computer, parallel sessions each get their own folder (a worktree) and their own ports; a session limit and a push lock stop them overwriting each other or flooding GitHub.

## Safety in layers (details in `SAFETY.md`)
Permissions in `.claude/settings.json` → hooks that block or ask before risky commands and file access → a git pre-commit hook (no commits on `main`, secret scan) → CI on every pull request → GitHub branch rules (needs a paid plan for private repositories) → your three gates. The safety files themselves cannot be edited by an agent without your approval.

## Cost in one paragraph (details in `COST-POLICY.md`)
Opus plans, builds and reviews security. Cheaper models do chores and routine review. Scripts do the mechanical work for free (run checks, claim branches, route reviewers). Caps: 2 fix rounds, reviewers only when needed, at most 2 parallel features (enforced on your own computer), CI on pull requests only. Your real hard limits are your spending limits on your Anthropic and GitHub accounts: set them (`SETUP-CHECKLIST.md`).

## What this does NOT do
It does not replace your judgment on legal text, money, privacy and real-world facts. It cannot stop a determined attacker who already controls your accounts. It cannot build or test iPhone apps in the Linux cloud. It does not make CI free: private repositories have a monthly minutes allowance.

## Where to look
`README.md` (index) · `WORKFLOW.md` · `SESSION-PER-FEATURE.md` · `LOCAL-MODE.md` · `COST-POLICY.md` · `MODELS.md` · `SAFETY.md` · `SECURE-CODING.md` · `STACK-PROFILE.md` · `SETUP-CHECKLIST.md` · `TROUBLESHOOTING.md` · `GLOSSARY.md`

## Two ways to build
Step by step (`/build-feature`, `/build-next`) or oneshot (`/oneshot`, `/oneshot-resume`, `/parking-lot`). Both are always available. See `ONESHOT.md`.
