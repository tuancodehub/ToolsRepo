# Cost policy

## Principle
Spend the most where a mistake is most expensive (planning, building, security). Spend almost nothing on mechanical work (scripts do it) or on re-reading things nobody needs. Keep every conversation small.

## Who uses which model
| Work | Model tier | Why |
|---|---|---|
| Orchestrator (the session), planner, builder, security-reviewer | **Top (Opus)** | Bad plans, bad code and missed vulnerabilities cost far more than the tokens |
| brief-auditor, quality-reviewer, ux-reviewer | **Mid (Sonnet)** | Checking against a list is a well-bounded job |
| checks-runner, pr-writer, queue-status | **Low (Haiku)** | Running commands and summarizing |
| Running checks, claiming, routing reviewers, dependency and secret scans | **No model (scripts)** | `run_checks.py`, `feature_git.py`, `changed_areas.py`, `dep_report.py`, `secret_scan.py` cost zero tokens |

Owner override: for a `risk: low` feature you may choose `builder_model: sonnet` at intake to save money. Never for medium or high risk. To change tiers project-wide, see `MODELS.md`.

## Risk ratings
- **low:** text, content, styling, docs, small isolated UI.
- **medium:** new screens or logic, new integrations without personal data.
- **high:** login or permissions, payments, personal data, database changes, security headers or app permissions, signing or deployment settings, anything an attacker would like to reach.
Risk never turns reviews off; it only decides whether you may use a cheaper builder.

## Caps (the kit enforces or recommends all of these)
| Cap | Value |
|---|---|
| Fix rounds per feature | 2, then stop and report |
| Builder re-runs after BLOCKED | 2 |
| Brief-auditor rounds | 2 |
| Reviewers | only those `changed_areas.py` names; re-run only those that failed |
| Features in parallel | 2 to 3 sessions in cloud mode; 2 on your own computer (enforced: `max_sessions`). Each session spends separately |
| CI | pull requests only (mobile kits also run on feature branches, see their profile) |
| Dependabot | grouped updates, at most 3 open pull requests |

## Habits that save the most
1. **Clean context per feature.** Long conversations re-read everything on every turn. Run `/clear` (or start a new session) between features; automatic compaction at 60% is only a safety net.
2. **Answer the planning questions well.** A BLOCKED build or a rework round costs more than the questions.
3. **Do not paste logs or files into the chat.** Scripts print short summaries; full logs are on disk.
4. **Keep `CLAUDE.md` short and stable.** It is read every session; editing it often also defeats prompt caching.
5. **Small features.** Plans and reviews scale with size. Split big ideas.
6. **Look at the planner's "Decisions" before you accept defaults** on anything about money, privacy or security.

## Where money and limits come from
1. **Claude usage.** Depends on your plan (included usage limits, or pay-as-you-go). Run `/cost` at the end of a feature and paste the figure into the brief's "Cost notes". After 3 to 5 features you will know your typical cost per feature and per risk level.
2. **GitHub Actions minutes.** Private repositories on the Free plan get a monthly allowance (2,000 minutes of standard Linux runner time and 500 MB of artifact storage, as of this kit's writing). macOS runners count at roughly 10 times the Linux rate, which matters for iPhone projects. Public repositories run standard runners free. Check current numbers on GitHub's billing page.
3. **Hosting.** Branch previews and builds may count against your host's free tier (for example build minutes).
4. **Third-party services** a feature adds (email, SMS, AI APIs, push notifications) have their own bills. Use test keys and low limits in previews.

## Set hard limits (the only true caps)
Everything above is a habit or a script. The things that actually stop spending are limits on your accounts: a spending limit or usage alert on Claude, and a budget (set to a low number, or zero) for GitHub Actions. See `SETUP-CHECKLIST.md`.

## Signs of overspend, and what to do
| Sign | Do |
|---|---|
| Features keep hitting the fix-round cap | The briefs are too vague or features too big. Split them and spend more time on the questions |
| Opus used for tiny text changes | Use `builder_model: sonnet` for `risk: low`, or batch small changes into one feature |
| CI minutes disappearing | Check for runs on every push, repeated reruns, or macOS jobs; see the profile's CI notes |
| Many features in parallel with overlapping files | Serialize them; conflicts cost double |

## Oneshot cost
- A oneshot run costs about the sum of its features. The cap (default at most 12) and the stop rules limit it. Reviews: right after each high-risk feature, once at the end for the rest.
- Pull requests open as drafts: CI runs when you mark them ready. Android CI also runs on each push to `feature/**`. GitHub Free private repositories: 2,000 Linux minutes per month; macOS counts about 10 times.
