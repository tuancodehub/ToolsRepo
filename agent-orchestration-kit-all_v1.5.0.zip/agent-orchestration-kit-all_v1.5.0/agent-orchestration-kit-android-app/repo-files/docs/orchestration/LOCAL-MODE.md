# Working on your own computer (local modes)

*Read this if you choose "local only" or "local and connected to GitHub" in `/init-project`. In cloud-only mode you can skip it.*

## The three ways to work
| Mode | Where the work happens | GitHub | Good for |
|---|---|---|---|
| **cloud** | A new Claude cloud session per feature | Yes (the repository is the memory) | Websites; working from a phone; nothing to install |
| **local** | Your computer, in a folder you choose | None. Work is merged on your computer | Private experiments; testing apps on your own emulator or phone |
| **local-github** | Your computer, in a folder you choose | Branches pushed to GitHub; pull the latest any time | Testing apps on your own devices **and** keeping the latest code available everywhere |

You can switch later: run `set_workspace.py` again (see below). The kit's agents, commands and checks are the same in every mode; only where files live, how work is published, and how strict the folder fence is differ.

## The folder fence (what agents may and may not touch)
You pick one main work folder, for example `~/Workspace` (Mac or Linux) or `C:\Work` (Windows). In the local modes:

| Agents **may** | Agents **may not** |
|---|---|
| **Change** files inside the work folder (this project, its worktree folders, the `tools` folder) and the temp folder | **Change, delete or move** anything outside those folders |
| **Read** files and **run programs** from anywhere (system tools, SDKs, logs) | Delete, move or overwrite a drive top, a home folder or a system folder, ever |
| Create Python virtual environments and download tools **into the tools folder** | Run disk, partition or format commands; shut down or restart the computer |
| Use the normal dev tools (git, npm, Gradle, Expo...) | Install into the system (`apt`, `dnf`, `brew`, `winget`, `choco`, `pip` without a virtual environment, `npm -g`) |

Deleting the work folder itself, or this project's folder, is also blocked: agents delete specific items inside them. A deletion of a whole sibling project inside the work folder asks you first.

The folder rules are checked before every command and every file edit (see `SAFETY.md`). The drive-top and system-folder protection is on in **every** mode, including cloud.

## Folder layout
```
~/Workspace/                  <- the only place agents may change files (plus temp)
    tools/                    <- shared by every project and worktree
        venvs/<name>/         <- Python virtual environments
        bin/                  <- downloaded programs
    MyProject/                <- the main project folder
    MyProject-worktrees/      <- extra folders for parallel sessions (made by worktree.py)
        feature-one/
        feature-two/
```
Every worktree finds the same `tools` folder because it is a sibling of the project, inside the work folder. The project must live inside the work folder.

## What to install first (you do this; agents never install into your system)
All systems need: **git**, **Python 3**, and whatever your stack needs (Node.js, Java, Android Studio, Xcode). The **GitHub command line (`gh`)** is needed only to open pull requests from your computer in local-github mode (otherwise open them on GitHub's website).

| System | Do this once |
|---|---|
| **macOS** | Open Terminal, run `xcode-select --install` (gives git and Python 3). Install Node from nodejs.org or a version manager. For iPhone apps, install Xcode from the App Store |
| **Windows** | Install **Git for Windows** (includes Git Bash) and **Python 3** from python.org (tick "Add python.exe to PATH"). Run Claude Code from **Git Bash**, or use **WSL** (Ubuntu) and follow the Linux steps inside it. Keep the work folder path short (`C:\Work`) and turn on long paths: `git config --global core.longpaths true`. PowerShell commands are checked too, but Git Bash or WSL is the better-tested route. iPhone apps cannot be built on Windows |
| **Debian or Ubuntu** | `sudo apt update && sudo apt install -y git python3 python3-venv curl` |
| **Rocky Linux, Amazon Linux, RHEL family** | `sudo dnf install -y git python3 curl` (use `yum` on older releases). `python3 -m venv` is included. Install Node through your distribution's module or a version manager |
| **GitHub CLI (optional)** | Follow the install page at cli.github.com for your system, then `gh auth login` yourself. Agents are not allowed to run `gh auth` |

`python3 --version` and `git --version` must both work. On Windows the command may be `python` instead of `python3`; the kit's safety hooks try `python3`, `python` and `py` in turn.

## Setting it up (about 5 minutes)
1. Make the work folder and put the project inside it (clone it there, or move it).
2. Install the kit into the project (see `USER-START-GUIDE.md` in the kit zip) and start Claude in the project folder.
3. Run `/init-project`. It asks: cloud only, local only, or local with GitHub; your operating system; your work folder; how many sessions at once. It cannot apply the folder setting itself: it shows you the exact line to run, for example:
   ```
   python3 scripts/orchestration/set_workspace.py --mode local-github --root ~/Workspace
   ```
   Run that yourself in a terminal in the project folder (or type it in Claude with `!` in front). Agents are blocked from running it, because it decides which folders they may change.
4. Check it: `python3 scripts/orchestration/set_workspace.py --check` (agents may run this one).
5. Run `/smoke-test`.

The setting lives in `.claude/workspace.local.json`, which is git-ignored, so each computer has its own. Settings you can change: `--scope project` (agents may change only this project, its worktrees and the tools folder, not the rest of the work folder), `--max-sessions`, `--push-gap`, `--extra-write <folder>` (allow one more folder).

## Tools without touching your system
- **Python tools:** `python3 -m venv ~/Workspace/tools/venvs/<name>` then `~/Workspace/tools/venvs/<name>/bin/pip install <package>` (Windows: `...\Scripts\pip.exe`). Plain `pip install` is blocked because it would change your computer's own Python.
- **Programs you download:** save them in `tools/bin` and run them from there.
- **Node packages:** install into the project (`npm ci --ignore-scripts`). For a tool shared by several projects, `npm install --prefix ~/Workspace/tools <package>`.
- **Big SDKs (JDK, Android SDK, Xcode):** you install these; agents only read and run them.
- `python3 -I scripts/orchestration/worktree.py tools` prints these reminders with your real paths.

## One feature, or several at once
- **One at a time:** work in the main project folder. `/build-feature <slug>`.
- **Several at once (recommended way):** each feature gets its own folder and its own Claude session.
  1. In your first session: `/new-session <slug>` (or `python3 scripts/orchestration/worktree.py add <slug>`). It makes `MyProject-worktrees/<slug>` and tells you its port numbers.
  2. Open a **new terminal window**, `cd` into that folder, install the project's dependencies there (each folder has its own copy), start Claude, run `/build-feature <slug>`.
  3. When the feature is merged: `python3 scripts/orchestration/worktree.py remove <slug>`.
- Each folder uses its **own block of ports** for dev servers (`worktree.py ports`), so two running apps never fight over port 3000 or 8081. Mobile emulators: run one emulator or simulator at a time, or give each session its own virtual device.
- Disk space: each folder has its own dependencies. Remove folders you are finished with.

## How sessions are kept from overwriting each other and from flooding GitHub
- **Own branch, own folder:** git allows a branch to be checked out in only one folder at a time, so two sessions cannot edit one branch.
- **Session limit:** at most `max_sessions` (default 2) sessions on this computer. A new claim is refused when the limit is reached. A slot is freed when a worktree is removed, or by the owner with `feature_git.py release <slug>`. Sessions with no activity for 12 hours stop counting.
- **Overlap check:** before building, `feature_git.py overlap` compares the files each running session plans to change. If they overlap, you are asked whether to wait. Merge one before the other.
- **Pushes take turns (local-github):** a push waits for a lock, then for a pause (default 15 seconds) since the last push by any session. If GitHub says "slow down", the script waits 30 seconds and tries once more, never in a loop. Pushes happen only at a few points: claim, end of planning, end of review.
- **No unsafe pushing:** agents cannot run `git push` directly in the local modes, only `feature_git.py push`. They cannot create worktrees except with `worktree.py`.
- `python3 -I scripts/orchestration/feature_git.py sessions` shows what is running.

## Testing and previews on your computer
`STACK-PROFILE.md` has a "Local testing" section for your project type: how to run the app on your computer, emulator or phone. In general: dev servers listen on **localhost only**, use the ports from `worktree.py ports`, and are stopped when you are done.

## Merging
- **local-github:** merge the pull request on GitHub (the usual gate). Then in the main folder run `git pull` to bring your computer up to date.
- **local only:** after you approve the preview, run this yourself in a terminal, from the main project folder, on the main branch:
  ```
  python3 scripts/orchestration/local_merge.py <slug>
  ```
  It asks you to type the feature name, merges it, and runs the checks. If the checks fail it shows how to undo the merge. It refuses to run for an agent (it needs a person at a terminal).

## What the fence does not do (be honest with yourself)
- It checks what the **agent** asks for. Programs the agent starts (npm, Gradle, pip, a test suite) write to their own caches (for example `~/.npm`, `~/.gradle`) as part of normal work; that is not blocked.
- A script written by the agent and then run (`python3 script.py`, `node -e`) can do things the command checks cannot see. The checks catch mistakes and the common dangerous forms, not a determined or tricked agent.
- For stronger protection, run Claude inside a virtual machine, a container, or under a separate low-privilege user account that owns only the work folder. That is the right choice for sensitive machines.
- Back up your work folder (Time Machine, File History, or git pushes). The kit protects against agent mistakes, not against a failed disk.
- Hooks need Python 3. If Python is missing the hooks block everything (on purpose) and tell you why.

## Going back to cloud-only
Run `python3 scripts/orchestration/set_workspace.py --mode cloud`. It removes the local settings file. Your branches and briefs are unchanged.
