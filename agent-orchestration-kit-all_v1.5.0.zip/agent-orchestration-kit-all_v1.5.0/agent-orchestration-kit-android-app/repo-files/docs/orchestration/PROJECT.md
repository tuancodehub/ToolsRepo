# Project facts

Filled in by `/init-project`. Agents read this before planning. Keep it short and true.

- **Name:** {{PROJECT_NAME}}
- **Purpose:** {{ONE_LINE_PURPOSE}}
- **Users:** {{USERS}}
- **Voice for user-visible text:** {{VOICE}}
- **Stack and hosting:** {{STACK_AND_HOSTING}}
- **Build style we expect to use most (step by step or oneshot; both are always available):** {{RUN_MODE}}
- **How we work (cloud, local, or local with GitHub) and operating system:** {{WORK_MODE}}
- **Browsers the app must work in (web projects; leave blank for apps):** {{BROWSERS}}
- **How a branch preview is produced:** {{PREVIEW_METHOD}}
- **Data sensitivity:** {{DATA_SENSITIVITY}}  <!-- personal data? payments? logins? health, children, financial? -->
- **Default risk for new features:** {{DEFAULT_RISK}}
- **Things agents must never invent:** phone numbers, prices, reviews, credentials, legal wording, real names or photos.
- **Open to-dos for the owner:** {{OWNER_TODOS}}
