# Orchestration kit: index

| Read this | When |
|---|---|
| `OVERVIEW.md` | First. One page: the cast, the gates, safety, cost |
| `SETUP-CHECKLIST.md` | Once, after installing: the steps only you can do (accounts, spending limits, GitHub settings) |
| `WORKFLOW.md` | How a feature moves from idea to merged PR, and what each status means |
| `SESSION-PER-FEATURE.md` | Running several features from several devices or terminals without collisions |
| `LOCAL-MODE.md` | Working on your own computer: the folder fence, tools, worktrees, parallel sessions, testing, merging |
| `COST-POLICY.md` and `MODELS.md` | Keeping spending predictable; changing which model does what |
| `SAFETY.md` | What is blocked, what asks you, what is NOT covered, and what to do after an incident |
| `SECURE-CODING.md` | The coding rules agents and reviewers follow |
| `STACK-PROFILE.md` | This project type: checks, preview method, risks, limits |
| `TROUBLESHOOTING.md` | When something does not work |
| `GLOSSARY.md` | Plain-language meanings of the terms |
| `PROJECT.md` | Facts about your project (filled in by `/init-project`) |

## First 15 minutes
1. Merge the install pull request (it contains this kit).
2. In a new session: `/init-project` (it asks whether you work in the cloud, locally, or locally with GitHub, and which operating system; approve the safety-file prompts it shows).
3. Do the owner-only steps in `SETUP-CHECKLIST.md`, above all the two spending limits.
4. In a new session: `/smoke-test`.
5. Build features: `/build-feature <slug> <what you want>` for a specific one, or `/build-next` for the next in the queue. Between features: merge, then `/clear` (or a new session).

## Oneshot
See `ONESHOT.md`: ask everything first, build the whole queue unattended, review parked items at the end.

## Commands
| Command | Does |
|---|---|
| `/init-project` | One-time setup |
| `/smoke-test` | Proves the kit works here |
| `/new-session <slug>` | Local modes: makes a separate folder so another Claude session can build a second feature at the same time |
| `/add-feature <slug> <text>` | Puts a feature in the queue (small PR) |
| `/queue-status` | Shows the numbered build order, each feature's goal, what is NEXT, and overlap warnings |
| `/build-next` | Builds the first queued feature whose dependencies are merged (same steps as `/build-feature`) |
| `/build-feature <slug> [text]` | Plans, asks, builds, reviews, previews, opens the PR |
| `/oneshot [text]` | Asks everything first, then builds the whole queue unattended (stacked draft PRs); see `ONESHOT.md` |
| `/oneshot-resume` | Continues an unfinished oneshot run |
| `/parking-lot` | The oneshot report: summary, then every saved question and concern, then one follow-up PR |
