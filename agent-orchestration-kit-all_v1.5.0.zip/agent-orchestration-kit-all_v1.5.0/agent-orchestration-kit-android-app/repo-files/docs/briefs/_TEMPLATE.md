---
slug: {{SLUG}}
title: TODO short title
status: claimed          # queued | claimed | planning | building | reviewing | preview | pr-open | merged | on-hold | cancelled
risk: medium             # low | medium | high  (see docs/orchestration/COST-POLICY.md)
builder_model: opus      # opus (default). The owner may choose sonnet for a low-risk feature at intake.
touches: []              # path globs this feature will change, e.g. [src/pages/**, src/config/**]
depends_on: []           # slugs that must be merged first
base:                    # oneshot: the feature branch this one is stacked on (set by claim --base). Empty = the default branch
order: 0                 # build order: 1 = first, 2 = second ... (0 = not set yet). /queue-status and /build-next follow it
updated: {{DATE}}
---

# Brief: {{SLUG}}

## Goal
One or two sentences: what changes for the user, and why.

## In scope
-

## Out of scope
-

## Decisions (answer, date)
<!-- Filled during intake. One line each: the question, the owner's answer, the date. -->

## Assumed defaults
<!-- Things the orchestrator assumed because a sensible default existed. The owner confirmed them at intake. -->

## OPEN items
<!-- Anything unanswered. The builder builds around these and never guesses. Money, legal wording, real names,
     phone numbers, links, credentials and reviews are NEVER guessed. -->

## Plan
<!-- Written by the planner: approach, files to change, data and security considerations, tests, rollout. -->

## Security notes
<!-- Written by the planner: what could go wrong here (inputs, auth, secrets, new dependencies, new network calls)
     and how the builder must handle it. -->

## Files likely touched
-

## Done when
- [ ] (observable result 1)
- [ ] (observable result 2)
- [ ] All checks pass: `python3 -I scripts/orchestration/run_checks.py`
- [ ] Reviewers report no BLOCKER

## Reviewer focus
-

## Cost notes
<!-- After the feature: paste the session's /cost line here (or a rough note). Helps tune the cost policy. -->
