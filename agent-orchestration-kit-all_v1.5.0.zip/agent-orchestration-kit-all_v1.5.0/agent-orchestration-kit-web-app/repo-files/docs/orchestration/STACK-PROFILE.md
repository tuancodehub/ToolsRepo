# Stack profile: web app (frontend only)

## What this covers
Browser apps built with a bundler (Vite, Next.js client-side, Create React App successors, SvelteKit in SPA mode) that call existing APIs or a hosted backend-as-a-service (Supabase, Firebase, Appwrite, a third-party API). You do not write or run your own server. If you do, use the *web app with backend* kit.

## The big idea: the browser is public
Anything in the app (code, build variables, bundled files) can be read by every visitor. So:
- No secrets, private API keys or admin credentials in client code. Variables with prefixes such as `VITE_`, `NEXT_PUBLIC_`, `REACT_APP_`, `EXPO_PUBLIC_` are published to everyone.
- Whatever protects data must run elsewhere. With a hosted backend, that protection is its **security rules** (for example row-level security or storage rules). Treat a change to those rules as a high-risk change.

## Before the first feature
- `package.json` scripts: `lint`, `typecheck`, `test`, `build` (all required by default); optionally `test:e2e` and `test:a11y`. Edit `.claude/checks.json` via `/init-project` if your names differ.
- `.nvmrc` with your Node version; `ignore-scripts=true` in `.npmrc` (owner edit), rebuilding individual packages only when needed.
- A SEPARATE test backend project (test database, test auth settings, test storage) used by previews and CI. Production keys never go into a session.
- Host connected for per-branch previews.

## Checks
Required: `lint`, `typecheck`, `test`, `build`, `secrets`. Optional: `e2e` (browser tests, slow), `a11y`. CI repeats them with `--strict` plus a dependency audit.

## Preview (gate 2)
Cloudflare, Netlify or Vercel can build each pushed branch and give a preview address. Point previews at the test backend with the host's preview-environment variables. Sign-in on the preview should use test accounts only. If your preview needs a backend that does not exist yet, say so at intake.

## Risk guide
- **low:** copy, styling, layout, a new static view.
- **medium:** new screens with state, new API calls to services without personal data, new routes.
- **high:** sign-in or session handling, anything reading or writing user data, access rules in the hosted backend, payments or checkout, file uploads, third-party scripts, security headers, hosting config.

## Cost notes
- CI: one Linux job of about 4 to 10 minutes per pull request; browser end-to-end tests add several minutes. Free-plan private repositories have a monthly allowance (see `COST-POLICY.md`).
- Hosted backends and hosts have free-tier limits; previews that create real accounts or sends can cost money. Use sandbox settings.

## Browser support
Ask at `/init-project`; the answer lives in `.claude/browsers.txt` (one of `chromium`, `firefox`, `webkit` per line; Chrome and Edge are `chromium`, Safari is `webkit`) and in `docs/orchestration/PROJECT.md`.
- **Tests:** if you use Playwright, define one test project per listed browser (`projects: [{ name: 'chromium', ... }, { name: 'firefox', ... }, { name: 'webkit', ... }]`). CI installs exactly the browsers in `.claude/browsers.txt` and runs them all.
- **Cloud sessions may not be able to install every browser** (their network is limited). If one cannot be installed, the tests still run in GitHub's checks on the pull request; the agent must say so instead of skipping it silently.
- **Each extra browser adds a few CI minutes.** Public sites usually deserve all three; a private tool needs the browsers its users actually use, plus Chromium.
- **Features that only some browsers support** (for example choosing a folder to save into works in Chrome and Edge but not in Firefox or Safari; some payment, notification and file APIs differ too): the planner must list them as a decision. Build one storage or feature layer with a fallback for the other browsers, or show a clear, friendly "please use Chrome or Edge" page, and add a test for that message.
- **WebKit in tests is not real iPhone Safari.** Check the preview on a real device for anything that matters on phones.

## Limits and honesty
- Agents cannot see the rendered app unless browser tests or screenshots exist; you must look at the preview.
- Hosted-backend rules cannot be fully tested from the repository alone; ask the security reviewer to read them and test with two different test users.
- Browser storage, cookies and third-party scripts affect privacy law obligations; the wording and legal decisions are yours.

## Local testing (local modes; see `LOCAL-MODE.md`)
- Run the app with `npm run dev` on **localhost only**, using this folder's port block (`worktree.py ports`; main folder: 5173 or 3000). Point it at a **separate test backend**, never production.
- Each worktree has its own `node_modules`: run `npm ci --ignore-scripts` in the new folder first.
- Preview on `http://localhost:<port>`; stop the server when done.

## Oneshot notes
See `docs/orchestration/ONESHOT.md`. Look at each page and form in every chosen browser and on a phone; use real test accounts; check accessibility by eye.
