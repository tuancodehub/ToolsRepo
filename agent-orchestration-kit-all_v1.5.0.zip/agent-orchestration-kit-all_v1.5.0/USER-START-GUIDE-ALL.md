# Agent orchestration kits: all project types

Pick the folder that matches the project you are starting, then open its `USER-START-GUIDE.md`.

| Folder | Use it for |
|---|---|
| `agent-orchestration-kit-static-website` | Marketing and content sites, portfolios |
| `agent-orchestration-kit-web-app` | Browser apps with no server of your own |
| `agent-orchestration-kit-web-app-backend` | Browser app plus your own API and database |
| `agent-orchestration-kit-android-app` | Native Android apps (Kotlin) |
| `agent-orchestration-kit-ios-app` | Native iPhone/iPad apps (Swift); has the biggest limits |
| `agent-orchestration-kit-mobile-expo` | iPhone and Android from one codebase (Expo / React Native) |

Several products? Install each kit in its own repository. Do not mix two kits in one repository. If a repository holds a website and an app, choose the kit for the riskier part.
Every kit is complete on its own; the shared parts are identical.

## Quick start
Each kit folder has `USER-START-GUIDE.md` (copy-and-paste prompts for every step, plus this list of commands) and `INSTALL.md` (the install instructions Claude Code follows). The commands are the same in every kit:

## Commands (type these in Claude Code)
| Command | What it does | When |
|---|---|---|
| `/init-project` | Asks plain questions about your project and fills in the kit's settings. | Once, right after install |
| `/smoke-test` | Proves the safety guards and agents work in your repository. | Once after `/init-project`, and after kit updates |
| `/add-feature <name> <what it should do>` | Adds a feature to the queue (a small pull request). Builds nothing. | Any time, from any device |
| `/queue-status` | Shows the numbered build order, each feature's goal, what is NEXT, and what each waits for. Almost free. | Any time |
| `/build-feature <name>` | Plans, asks every question first, builds, reviews, lets you preview, then opens a pull request. One feature, step by step. | To build a specific feature |
| `/build-next` | Same as `/build-feature`, but picks the next ready feature in the queue for you. | To keep going down the queue |
| `/oneshot` | Asks ALL questions up front, then builds the whole queue unattended: one stacked draft pull request per feature. Questions and concerns are saved for a report. Can cost much more. | When you trust the plan and want to walk away |
| `/oneshot-resume` | Continues an unfinished oneshot run after a limit, timeout or closed session. | After an interrupted oneshot |
| `/parking-lot` | The oneshot report: summary of every feature, then every saved question and concern explained so you can decide. Applies your choices in one follow-up pull request. | After a oneshot finishes |
| `/new-session <name>` | Local modes only: makes a separate folder so a second Claude session can build another feature at the same time. | Only when working on your own computer in parallel |

Also useful: `/clear` (starts a fresh conversation; do it between features) and `/cost` (shows what the session has used).
