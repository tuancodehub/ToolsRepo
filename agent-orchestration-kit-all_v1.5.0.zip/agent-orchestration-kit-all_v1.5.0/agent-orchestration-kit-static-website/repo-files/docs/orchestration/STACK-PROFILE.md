# Stack profile: static website

## What this covers
Sites that are built into plain files at build time and served by a host (marketing sites, portfolios, documentation, small business sites). Typical tools: Astro, Eleventy, Hugo, Next.js static export, or hand-written HTML/CSS. Dynamic parts (a contact form, booking links, analytics) use small serverless handlers or links to third-party services, not a custom backend. If you have logins, a database or user accounts, use the *web app with backend* kit instead.

## Before the first feature
- A `package.json` with scripts named `lint`, `build` (required) and, ideally, `check` (types), `test`, `test:a11y` (accessibility tests with axe + Playwright). Missing optional scripts are simply skipped; `/init-project` adapts `.claude/checks.json`.
- A `.nvmrc` file with your Node version (CI reads it).
- `ignore-scripts=true` in `.npmrc` (owner edit), then `npm rebuild <package>` only for packages that need a build step (image libraries, for example). Add such a step to `.github/workflows/ci.yml` too.
- Host connected so each branch gets a preview address (below).

## Checks (`.claude/checks.json`)
`lint`, `build`, `secrets` are required; `typecheck`, `test`, `a11y`, `todos` are optional until you add them. CI runs the same list with `--strict`, so a required check that cannot run fails CI.

## Preview (gate 2)
After the build and review, `feature_git.py push` publishes the branch and the host builds a preview.
| Host | How the preview appears |
|---|---|
| Cloudflare (Workers with static assets, or Pages) | Connect the repository; non-default branches get preview URLs. Find the address on the commit or in the dashboard |
| Netlify / Vercel | Deploy previews per branch or pull request; link in the PR checks or the dashboard |
| GitHub Pages | No per-branch preview. Use a different host for previews, or review via CI artifact |
| No host yet | Tell the orchestrator; it can describe the local steps, but you will not be able to click a link from a phone |
Previews must use test settings only. Never point a preview at production services or put real secrets in it.

## Risk guide
- **low:** text, images, styling, new static page with no forms or scripts.
- **medium:** new interactive component, new third-party link-out, new content types.
- **high:** forms or anything that sends data, security headers or CSP, analytics or tracking scripts, payment links, redirects, anything with a serverless handler, hosting configuration.

## Cost notes
- CI: one Linux job of about 3 to 8 minutes per pull request (more if browser tests run). Free-plan private repositories get 2,000 Linux minutes a month.
- Browser install for accessibility tests is the slowest step; cache it or run those tests only when UI files changed.
- Host build minutes may also be metered.

## Browser support
Ask at `/init-project`; the answer lives in `.claude/browsers.txt` (one of `chromium`, `firefox`, `webkit` per line; Chrome and Edge are `chromium`, Safari is `webkit`) and in `docs/orchestration/PROJECT.md`.
- **Tests:** if you use Playwright, define one test project per listed browser (`projects: [{ name: 'chromium', ... }, { name: 'firefox', ... }, { name: 'webkit', ... }]`). CI installs exactly the browsers in `.claude/browsers.txt` and runs them all.
- **Cloud sessions may not be able to install every browser** (their network is limited). If one cannot be installed, the tests still run in GitHub's checks on the pull request; the agent must say so instead of skipping it silently.
- **Each extra browser adds a few CI minutes.** Public sites usually deserve all three; a private tool needs the browsers its users actually use, plus Chromium.
- **Features that only some browsers support** (for example choosing a folder to save into works in Chrome and Edge but not in Firefox or Safari; some payment, notification and file APIs differ too): the planner must list them as a decision. Build one storage or feature layer with a fallback for the other browsers, or show a clear, friendly "please use Chrome or Edge" page, and add a test for that message.
- **WebKit in tests is not real iPhone Safari.** Check the preview on a real device for anything that matters on phones.

## Limits and honesty
- Agents cannot judge visual design from code alone; you must look at the preview.
- Legal text, prices, reviews, photos and credentials come from you; agents mark them OPEN and use `TODO-` placeholders, never inventions.
- Images: keep large originals out of the repository when possible; strip location data (EXIF) before publishing photos.

## Local testing (local modes; see `LOCAL-MODE.md`)
- Run the site with the dev command in `.claude/checks.json` (for example `npm run dev`); it must listen on **localhost only**, on the port block of this folder (`worktree.py ports`; main folder: 3000 or 4321 as the tool defaults).
- Preview before the pull request on `http://localhost:<port>` in your own browser. Check it on your phone by opening the same address through your computer's network name only if you trust your Wi-Fi; otherwise use the host's branch preview.
- Stop the dev server when done. Never run it with a public address or tunnel.

## Oneshot notes
See `docs/orchestration/ONESHOT.md`. Preview each page's look on a phone and a laptop; real photos, names, links and prices stay OPEN until the owner supplies them.
