# User guide: Web app with backend kit

Version 1.5.2 (2026-11-16). Full-stack web apps: a browser frontend plus your own API server and database (Node, Python, Go, Ruby, .NET, Java and others).

This guide is for YOU. Claude Code does not need to read it. It has the exact words to paste, in order.
Paste each grey line into Claude Code as written. Replace anything in <angle brackets>. Plain words are fine; no coding needed.

## What this kit is
A ready-made team of AI agents that plan, build, check and review features in your GitHub repository, in Claude cloud sessions or on your own computer, with safety guards and cost limits. You can build one feature at a time (step by step) or the whole list in one go (oneshot). Install it once per project (about 20 minutes).

## What is in the zip
| File | What it is |
|---|---|
| `USER-START-GUIDE.md` | This guide (for you) |
| `CHANGELOG.md` | What changed in each version |
| `INSTALL.md` | The install instructions for Claude Code (you paste its prompt, below) |
| `repo-files/` | Everything copied into your repository: agents, commands, hooks, settings, scripts, checks, docs |
| `gitignore-additions.txt` | Lines added to your `.gitignore` |
| `MANIFEST.txt` | Checksums of every file |

## Step 1. Install the kit (once per project)
1. Start Claude Code on your repository: a cloud session on the repo, or a terminal in your project folder on your computer (install git and Python 3 first; on Windows use Git Bash or WSL). A brand-new repository can be empty; the install adds what the first check needs.
2. Unzip this kit. Cloud: upload the zip or the unzipped folder into the session. Your computer: note the unzipped folder's path.
3. Say:
> Install this orchestration kit. Read INSTALL.md in the kit folder and follow it exactly. Kit folder: <path, or "the folder I uploaded">

4. If it asks to edit `.claude` or `.github/workflows`, say yes. This is the one time that is expected.
5. When it opens the pull request, look it over: the kit is plain text. Open `.claude/settings.json`, `.github/workflows/ci.yml` and `.claude/hooks/`. Anything you do not recognize should not be there. Then merge it yourself on GitHub.
6. If the first check on the pull request fails, say:
> The pull request check failed. Read the error, fix only that, push to the same branch, and tell me in plain words what was wrong.

## Step 2. Set up (new session on the repository)
Start a NEW session. Then:
> /init-project

Answer in plain words: what you are building and for whom, where you work (cloud, your computer, or your computer plus GitHub), which browsers must work (websites and web apps), and which build style you expect to use most (you can always use either). Then:
> /smoke-test

## Step 3. Account settings only you can do
> Walk me through docs/orchestration/SETUP-CHECKLIST.md one item at a time, in plain words.

(Spending limits, repository settings, preview hosting. Also turn on "Automatically delete head branches": on GitHub open the repository, then Settings → General, scroll to Pull Requests and tick it. Claude reminds you after your first pull request, and oneshot needs it.)

## Step 4. Describe the app and line up features
> I want to build <what it is> for <who uses it>. Research what a good version of this needs. Suggest a list of features, in a sensible order, and add them to the queue with /add-feature. Explain each feature in one or two plain sentences.

Then check the list:
> /queue-status

To change it, say: "Move <feature> before <feature>", or "Rewrite the goal of <feature> to say ...".

## Step 5A. Build step by step (safest)
> /build-next

Claude asks every question first (answer in plain words), builds on its own, lets you preview, then asks "Approve and open pull request?" Merge the pull request yourself. Before the next feature:
> /clear

then `/build-next` again. After each feature Claude also asks whether to continue step by step or switch to oneshot.

## Step 5B. Build everything in one go (oneshot)
Merge any open pull request first, run `/clear`, then:
> /oneshot

Answer ALL the questions (your last chance to steer), pick the feature cap, confirm "Start". It then works alone and saves its questions and concerns. When it finishes:
> /parking-lot

Decide each saved item. Merge the pull requests in the order it gives you, marking each "Ready for review" on GitHub first so the checks run. If the session stops early (limit, timeout, closed app), open a new session and say:
> /oneshot-resume

## Commands (type these in Claude Code)
| Command | What it does | When |
|---|---|---|
| `/init-project` | Asks plain questions about your project and fills in the kit's settings. | Once, right after install |
| `/smoke-test` | Proves the safety guards and agents work in your repository. | Once after `/init-project`, and after kit updates |
| `/add-feature <name> <what it should do>` | Adds a feature to the queue (a small pull request). Builds nothing. | Any time, from any device |
| `/queue-status` | Shows the numbered build order, each feature's goal, what is NEXT, and what each waits for. Almost free. | Any time |
| `/build-feature <name>` | Plans, asks every question first, builds, reviews, lets you preview, then opens a pull request. One feature, step by step. | To build a specific feature |
| `/build-next` | Same as `/build-feature`, but picks the next ready feature in the queue for you. | To keep going down the queue |
| `/oneshot` | Asks ALL questions up front, then builds the whole queue unattended: one stacked draft pull request per feature. Questions and concerns are saved for a report. Can cost much more. | When you trust the plan and want to walk away |
| `/oneshot-resume` | Continues an unfinished oneshot run after a limit, timeout or closed session. | After an interrupted oneshot |
| `/parking-lot` | The oneshot report: summary of every feature, then every saved question and concern explained so you can decide. Applies your choices in one follow-up pull request. | After a oneshot finishes |
| `/new-session <name>` | Local modes only: makes a separate folder so a second Claude session can build another feature at the same time. | Only when working on your own computer in parallel |

Also useful: `/clear` (starts a fresh conversation; do it between features) and `/cost` (shows what the session has used).

## Handy prompts
- "Explain what you just did in plain words."
- "What is left in the queue, and what would you build next?"
- "What is still OPEN on this feature?"
- "I changed my mind about <decision>. What would that affect?"
- "Add this decision to docs/orchestration/PROJECT.md: <decision>."

## After your first oneshot (do this once)
When `/parking-lot` ends, it shows which commands were blocked or allowed. Then type:
> /fewer-permission-prompts

It suggests commands to stop asking about, from this session's history. Approve only read-only or test commands (never install, delete, publish or network commands). Claude cannot edit its own settings, so add the approved lines to `.claude/settings.local.json` yourself, or ask Claude to show you exactly what to paste.

## What Claude's replies look like
Each final reply ends with "Learn more": 3 follow-up questions or considerations related to the work, and 2 new topics worth exploring. They are suggestions only; answer or ignore them.

## Be honest about the limits
- Tested here in scratch repositories only; run `/smoke-test` after install to prove it works in yours.
- Step mode now approves common local test commands (vitest, jest, tsc, eslint, playwright, prettier check) without asking. Install, delete, publish and network commands still ask.
- Hooks and scripts need Python 3 (cloud sessions have it). On Windows start Claude from Git Bash or WSL.
- On your own computer the safety checks prevent accidents; they are not a sandbox. For sensitive machines use a virtual machine, container or separate user account.
- A private GitHub repository on the Free plan cannot enforce branch rules. See `docs/orchestration/SAFETY.md` after install.
- You still decide money, legal wording, privacy and real-world facts.

## Updating the kit later
Unzip the newer kit (the version is in its file name; the installed version is in `docs/orchestration/KIT-VERSION.txt`). Then say:
> Install this orchestration kit update. Read INSTALL.md in the kit folder and follow it exactly. Keep my own .claude/checks.json, .claude/browsers.txt and docs/orchestration/PROJECT.md. Kit folder: <path>

Check the pull request before merging.

## Something not working?
> Read docs/orchestration/TROUBLESHOOTING.md and tell me what is wrong, in plain words.

Never ask Claude to turn off a safety check; it is not allowed to, and you should not need to.
