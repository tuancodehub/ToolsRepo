# Changelog

Versions follow MAJOR.MINOR.PATCH. To see which version a project has installed, open `docs/orchestration/KIT-VERSION.txt` in the repository.

## 1.5.2
- Packages: `setup_deps.py` installs a project's packages safely (exact versions, install scripts off) when a fresh session has none; smoke test, `/build-next`, `/build-feature` and `/oneshot` run it first, and a failing check says so.
- `/smoke-test` is cheaper and cannot get stuck: the claim test is a dry run (`feature_git.py claim <slug> --check`, nothing created or pushed); models are compared exactly with `set_models.py --verify`, then one live agent call per tier (3 agents, not 8); the SessionStart check is automatic; the result ends with PASS, PASS with notes, or NEEDS ATTENTION.
- `/queue-status`: a PR column with a link to each feature's pull request, at most 20 rows at a time, merged features hidden (just counted) once the list is long, `--all` (ask "show more") shows everything; overlap warnings are grouped (first 5, then a count).
- After the first pull request (install, first feature, oneshot start) Claude reminds you, once, to turn on GitHub's "Automatically delete head branches" (Settings → General → Pull Requests), and only if it is off.
- `feature_git.py set-pr <url>` records the pull request link in the brief.

## 1.5.1
- `/queue-status` prints a table (number, status with emoji, feature, risk, what it does, what it waits for) instead of a list. Status emoji: ➡️ next, 🟢 ready, ⏳ waiting, 🚧📝🔨🔍👁️ in progress, 📬 pull request open, ✅ merged, 🚫 cancelled; ⚠️ marks warnings.
- The queue now knows what is really merged: `/queue-status` and `/build-next` fetch first, then detect merged features from git history and from GitHub (squash merges included), instead of trusting only the hand-edited `status:` line in each brief. Briefs that are out of date are announced, and a small pull request can update them (`queue_status.py --sync`).
- Session start fetches the latest from GitHub, so a long-paused or resumed session no longer shows old merge information.
- A feature marked pr-open whose branch has vanished from GitHub is flagged for a check, never silently counted as merged. A just-claimed branch with no commits is never mistaken for merged.

## 1.5.0
- Every final reply from Claude Code now ends with a "Learn more" part: 3 related follow-up questions or considerations and 2 new topics to explore (rule in `CLAUDE.md`, repeated in each command).

## 1.4.1
- `/smoke-test` now checks the installed version and that every kit file is present and unchanged, and prints the version in use (`kit_version.py`). The install record `docs/orchestration/KIT-VERSION.txt` lists a checksum for each kit file. The session start shows the version.
- Install titles, commits and the pull request description name the version.

## 1.4.0
- Zip files and the folder inside each zip carry the version in their name, so unzipped copies never overwrite each other.
- Added this CHANGELOG and `docs/orchestration/KIT-VERSION.txt` (written into the repository at install).
- The install instructions report the version you are updating from and to.

## 1.3.2
- Step mode approves common local test commands (vitest, jest, tsc, eslint, playwright test, prettier check; gradle on Android) without asking.
- Decision log of hook blocks, asks and oneshot auto-allows (`hook_log.py`); `/parking-lot` shows a command report; `/fewer-permission-prompts` recommended after the first oneshot.
- (By strict semantic versioning this was a minor release; the number stays as published.)

## 1.3.1
- Oneshot no longer stalls on permission prompts: commands that pass the safety checks are explicitly allowed; `npx` of tools already installed in the project is allowed.
- Builder agent uses Edit/Write for files, runs tests as separate commands, and uses full paths.

## 1.3.0
- Oneshot: `/oneshot`, `/oneshot-resume`, `/parking-lot`; stacked draft pull requests; run state; circuit breaker; parking lot of questions and concerns.
- Both build styles in one kit; choice at `/init-project` and after each feature.
- `USER-START-GUIDE.md` replaces START-HERE and QUICK-START; `INSTALL.md` is now instructions for Claude Code only.
- Install creates `README.md` and `.nvmrc` when missing so the first pull request's checks pass.

## 1.2.0
- Numbered queue with goals, `/queue-status --next`, `/build-next`, several features per session with a `/clear` reminder.
- Browser choice (Chromium, Firefox, WebKit) for web kits.

## 1.1.0
- Local and local-github work modes, folder fence, worktrees, session cap, push lock.

## 1.0.0
- First release: cloud mode, agents, safety hooks, cost policy, CI.
