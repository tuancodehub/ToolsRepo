#!/usr/bin/env python3
"""Show or change the model of each agent and command.

  set_models.py --show
  set_models.py --set builder=sonnet planner=opus
  set_models.py --verify      compare each agent's model with the kit's standard tiers (free; no agent is called)
Allowed values: opus, sonnet, haiku, inherit, or a full model ID such as claude-opus-5-5.
These files are protected: Claude will ask the owner to approve the edit.
"""
import os
import re
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
DIRS = [os.path.join(ROOT, ".claude", "agents"), os.path.join(ROOT, ".claude", "commands")]
VALUE_RE = re.compile(r"^(opus|sonnet|haiku|inherit|claude-[a-z0-9.\-]+)$")


STANDARD = {"planner": "top", "builder": "top", "security-reviewer": "top",
            "brief-auditor": "mid", "quality-reviewer": "mid", "ux-reviewer": "mid",
            "checks-runner": "low", "pr-writer": "low"}


def tier(value):
    v = value.lower()
    if "opus" in v:
        return "top"
    if "sonnet" in v:
        return "mid"
    if "haiku" in v:
        return "low"
    return "inherit" if v == "inherit" else "unknown"


def verify():
    """Read the model line of every agent file and compare it with the standard tiers. Prints a table; exit 1 on a mismatch."""
    agents = os.path.join(ROOT, ".claude", "agents")
    bad = 0
    print("| Agent | model: line | Tier | Standard | Result |")
    print("|---|---|---|---|---|")
    for name, want in STANDARD.items():
        path = os.path.join(agents, name + ".md")
        if not os.path.isfile(path):
            print("| %s | (file missing) | | %s | FAIL |" % (name, want))
            bad += 1
            continue
        val = current(path)
        got = tier(val)
        ok = got == want
        note = "OK" if ok else ("CHANGED by the owner?" if name != "security-reviewer" else "WARNING: security review below the top tier")
        if not ok:
            bad += 1
        print("| %s | %s | %s | %s | %s |" % (name, val, got, want, note))
    print("RESULT: " + ("all agents match the standard tiers" if not bad else "%d agent(s) differ from the standard tiers (fine if you chose that)" % bad))
    return 1 if bad else 0


def files():
    out = {}
    for d in DIRS:
        for name in sorted(os.listdir(d)) if os.path.isdir(d) else []:
            if name.endswith(".md"):
                out[name[:-3]] = os.path.join(d, name)
    return out


def current(path):
    m = re.search(r"(?m)^model:\s*(\S+)", open(path, "r", encoding="utf-8").read().split("\n---", 2)[0])
    return m.group(1) if m else "(none)"


def main():
    fs = files()
    if "--verify" in sys.argv:
        return verify()
    if "--show" in sys.argv or len(sys.argv) == 1:
        for name, path in fs.items():
            kind = "agent  " if "/agents/" in path else "command"
            print("%s %-18s %s" % (kind, name, current(path)))
        return 0
    if "--set" in sys.argv:
        pairs = sys.argv[sys.argv.index("--set") + 1:]
        for pair in pairs:
            if "=" not in pair:
                print("bad pair:", pair)
                return 1
            name, value = pair.split("=", 1)
            if name not in fs or not VALUE_RE.match(value):
                print("unknown name or value:", pair)
                return 1
            text = open(fs[name], "r", encoding="utf-8").read()
            head, sep, body = text.partition("\n---\n")
            new_head, n = re.subn(r"(?m)^model:.*$", "model: " + value, head, count=1)
            if n == 0:
                print("no model line in", name)
                return 1
            open(fs[name], "w", encoding="utf-8").write(new_head + sep + body)
            print("%s -> %s" % (name, value))
        return 0
    print(__doc__)
    return 1


if __name__ == "__main__":
    sys.exit(main())
