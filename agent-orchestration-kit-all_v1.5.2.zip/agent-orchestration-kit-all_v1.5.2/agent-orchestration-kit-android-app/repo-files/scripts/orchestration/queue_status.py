#!/usr/bin/env python3
"""Show the feature queue. There is no hand-edited table to conflict on: every feature's status lives in
the front matter of its own brief (docs/briefs/<slug>.md), and this script builds the table.

  queue_status.py           numbered build order, one-line goals, warnings
  queue_status.py --short   2-3 lines (used at session start)
  queue_status.py --next    the slug of the next feature that is ready to build (nothing else on stdout)
  queue_status.py --all     show every feature (by default at most 20 rows; merged ones are only counted once the list is long)
  queue_status.py --sync    also rewrite `status:` to merged in the briefs of features found merged in git or on GitHub
                            (changes files in the working tree only; the command then opens a small pull request)

Merged features are detected from the real history, not only from the hand-edited `status:` line: the feature branch is
inside the default branch, or GitHub says a pull request from it was merged (works for squash merges). Run `git fetch`
first (the commands do) so this computer knows about merges made on GitHub since the session started.

Order: set `order: N` (1 = first) in a brief's front matter. Features without an order come after the ordered
ones, alphabetically. A feature is READY when it is queued and every feature in `depends_on` is merged.
"""
import glob
import os
import re
import subprocess
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
ACTIVE = {"claimed", "planning", "building", "reviewing", "preview", "pr-open"}


def front_matter(path):
    try:
        text = open(path, "r", encoding="utf-8").read()
    except OSError:
        return {}
    m = re.match(r"^---\n(.*?)\n---", text, re.S)
    data = {}
    if not m:
        return data
    for line in m.group(1).splitlines():
        if ":" in line and not line.startswith(" "):
            k, v = line.split(":", 1)
            v = v.split("#", 1)[0].strip()
            if v.startswith("[") and v.endswith("]"):
                data[k.strip()] = [x.strip().strip("'\"") for x in v[1:-1].split(",") if x.strip()]
            else:
                data[k.strip()] = v.strip("'\"")
    return data


def static_prefix(pattern):
    m = re.search(r"[*?\[]", pattern)
    return pattern[:m.start()] if m else pattern


def overlaps(a, b):
    pa, pb = static_prefix(a), static_prefix(b)
    return pa.startswith(pb) or pb.startswith(pa)


def goal_text(path):
    """First sentence under '## Goal' (placeholder text and comments are ignored)."""
    try:
        text = open(path, "r", encoding="utf-8").read()
    except OSError:
        return ""
    m = re.search(r"(?ms)^## Goal\s*\n(.*?)(?=^## |\Z)", text)
    if not m:
        return ""
    body = re.sub(r"(?s)<!--.*?-->", "", m.group(1)).strip()
    body = " ".join(body.split())
    if not body or body.startswith("One or two sentences"):
        return ""
    cut = re.search(r"[.!?](\s|$)", body)
    first = body[:cut.end()].strip() if cut else body
    return first if len(first) <= 150 else first[:147].rstrip() + "..."


def order_of(b):
    try:
        n = int(str(b.get("order", "0")).strip() or 0)
    except ValueError:
        n = 0
    return n if n > 0 else 10 ** 6


def is_ready(b, status_by_slug, claims):
    if b.get("status") != "queued":
        return False
    if claims and b["slug"] in claims:
        return False
    return all(status_by_slug.get(d) == "merged" for d in b.get("depends_on", []))


def remote_claims():
    try:
        p = subprocess.run(["git", "-C", ROOT, "ls-remote", "--heads", "origin", "refs/heads/feature/*"],
                           capture_output=True, text=True, timeout=10)
        if p.returncode != 0:
            return None
        return {l.split("refs/heads/feature/", 1)[1] for l in p.stdout.splitlines() if "refs/heads/feature/" in l}
    except (OSError, subprocess.SubprocessError):
        return None


def other_session_briefs(known):
    """Local modes: briefs that live only in another running session's worktree."""
    out = []
    try:
        sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
        import orch_common as oc
        ws = oc.load_ws(ROOT)
        if not oc.is_local(ws):
            return out
        for s in oc.active_sessions(oc.state_dir(ROOT), ws["stale_hours"]):
            if s["slug"] in known or os.path.realpath(s["path"]) == os.path.realpath(ROOT):
                continue
            fm = front_matter(os.path.join(s["path"], "docs", "briefs", s["slug"] + ".md"))
            if fm:
                fm.setdefault("slug", s["slug"])
                out.append(fm)
    except Exception:
        pass
    return out


LIST_LIMIT = 20
DETECT = {"claimed", "planning", "building", "reviewing", "preview", "pr-open", "ready-to-merge"}
_GH = {}


def git_out(*args, timeout=15):
    try:
        p = subprocess.run(["git", "-C", ROOT] + list(args), capture_output=True, text=True, timeout=timeout)
        return p.returncode, p.stdout.strip()
    except (OSError, subprocess.SubprocessError):
        return 1, ""


def default_ref():
    rc, out = git_out("symbolic-ref", "--short", "refs/remotes/origin/HEAD")
    if rc == 0 and out:
        return out
    for cand in ("origin/main", "origin/master", "main", "master"):
        if git_out("rev-parse", "--verify", "--quiet", cand)[0] == 0:
            return cand
    return ""


def gh_merged(slug):
    """True/False from GitHub, None when gh is missing, not signed in, or offline."""
    if slug in _GH:
        return _GH[slug]
    res = None
    try:
        p = subprocess.run(["gh", "pr", "list", "--state", "merged", "--head", "feature/" + slug, "--json", "number", "--limit", "1"],
                           cwd=ROOT, capture_output=True, text=True, timeout=12)
        if p.returncode == 0:
            res = p.stdout.strip() not in ("", "[]")
    except (OSError, subprocess.SubprocessError):
        res = None
    _GH[slug] = res
    return res


def pr_links():
    """{slug: (number, url)} for pull requests from feature branches, from ONE `gh pr list` call. {} when gh is unavailable."""
    out = {}
    if "--short" in sys.argv or "--next" in sys.argv:
        return out
    try:
        p = subprocess.run(["gh", "pr", "list", "--state", "all", "--limit", "200", "--json", "headRefName,url,number,updatedAt"],
                           cwd=ROOT, capture_output=True, text=True, timeout=15)
        if p.returncode == 0:
            import json
            for r in sorted(json.loads(p.stdout or "[]"), key=lambda r: r.get("updatedAt", "")):
                h = r.get("headRefName", "")
                if h.startswith("feature/") and r.get("url", "").startswith("https://"):
                    out[h[len("feature/"):]] = (str(r.get("number", "")), r["url"])
    except (OSError, subprocess.SubprocessError, ValueError):
        pass
    return out


def detect_merged(slug, dref, claims, status="pr-open", use_gh=True):
    """('merged', how) | ('probably', why) | None. Only 'merged' counts for dependencies."""
    if dref and status in ("pr-open", "ready-to-merge"):   # a branch with no commits of its own is also 'inside' the default branch
        for br in ("refs/remotes/origin/feature/" + slug, "refs/heads/feature/" + slug):
            if git_out("rev-parse", "--verify", "--quiet", br)[0] == 0:
                if git_out("merge-base", "--is-ancestor", br, dref)[0] == 0:
                    return ("merged", "its branch is inside " + dref)
                break
    g = gh_merged(slug) if use_gh else None
    if g:
        return ("merged", "GitHub shows its pull request as merged")
    if claims is not None and slug not in claims and g is None:
        return ("probably", "its branch is gone from GitHub (usually deleted after a merge)")
    return None


def write_status(slug, new):
    path = os.path.join(ROOT, "docs", "briefs", slug + ".md")
    try:
        text = open(path, "r", encoding="utf-8").read()
        text2 = re.sub(r"(?m)^status:.*$", "status: " + new, text, count=1)
        if text2 != text:
            open(path, "w", encoding="utf-8", newline="\n").write(text2)
            return True
    except OSError:
        pass
    return False


def main():
    short = "--short" in sys.argv
    want_next = "--next" in sys.argv
    briefs = []
    for path in sorted(glob.glob(os.path.join(ROOT, "docs", "briefs", "*.md"))):
        name = os.path.basename(path)
        if name.startswith("_"):
            continue
        fm = front_matter(path)
        fm.setdefault("slug", name[:-3])
        fm["_goal"] = goal_text(path)
        briefs.append(fm)

    briefs += other_session_briefs({b["slug"] for b in briefs})
    claims = remote_claims()
    dref = default_ref()
    stale, probably = [], []
    for b in briefs:
        if b.get("status") in DETECT:
            d = detect_merged(b["slug"], dref, claims, b.get("status"), use_gh=not short)
            if d and d[0] == "merged":
                b["_brief_status"] = b["status"]
                b["status"] = "merged"
                b["_how"] = d[1]
                stale.append(b)
            elif d and d[0] == "probably" and b.get("status") == "pr-open":
                probably.append((b, d[1]))
    counts = {}
    for b in briefs:
        counts[b.get("status", "?")] = counts.get(b.get("status", "?"), 0) + 1
    active = [b for b in briefs if b.get("status") in ACTIVE]

    if want_next:
        by = {b["slug"]: b.get("status") for b in briefs}
        ready = sorted([b for b in briefs if is_ready(b, by, claims)], key=lambda b: (order_of(b), b["slug"]))
        if ready:
            print(ready[0]["slug"])
            return 0
        sys.stderr.write("No queued feature is ready (everything is merged, claimed, or waiting on a dependency).\n")
        return 1

    if short:
        if not briefs:
            print("Queue: empty (add one with /add-feature).")
        else:
            print("Queue: " + ", ".join("%d %s" % (n, s) for s, n in sorted(counts.items())) +
                  ("; active: " + ", ".join(b["slug"] for b in active) if active else "") +
                  ("; %d merged on GitHub but briefs not updated (run /queue-status)" % len(stale) if stale else ""))
        return 0

    if not briefs:
        print("Queue is empty. Add a feature with /add-feature <slug>.")
        return 0
    by_status = {b["slug"]: b.get("status") for b in briefs}
    upcoming = sorted([b for b in briefs if b.get("status") not in ("merged", "cancelled")], key=lambda b: (order_of(b), b["slug"]))
    done = sorted([b for b in briefs if b.get("status") in ("merged", "cancelled")], key=lambda b: b["slug"])
    nxt = next((b for b in upcoming if is_ready(b, by_status, claims)), None)
    show_all = "--all" in sys.argv
    prs = pr_links()

    def cell(text, n=90):
        text = " ".join(str(text).split()).replace("|", "/")
        return text if len(text) <= n else text[:n - 3].rstrip() + "..."

    def badge(b):
        st = b.get("status", "?")
        if b is nxt:
            return "\u27a1\ufe0f NEXT"
        if st == "queued":
            return "\U0001F7E2 Ready" if is_ready(b, by_status, claims) else "\u23f3 Waiting"
        return {"claimed": "\U0001F6A7 Claimed", "planning": "\U0001F4DD Planning", "building": "\U0001F528 Building",
                "reviewing": "\U0001F50D Reviewing", "preview": "\U0001F441\ufe0f Preview", "pr-open": "\U0001F4EC PR open",
                "ready-to-merge": "\U0001F4EC Ready to merge", "merged": "\u2705 Merged", "cancelled": "\U0001F6AB Cancelled"}.get(st, "\u2753 " + st)

    def pr_cell(b):
        info = prs.get(b["slug"])
        url = info[1] if info else (b.get("pr") or "")
        if not url or not re.match(r"^https://[^\s)]+$", url):
            return "-"
        num = info[0] if info else (re.search(r"/pull/(\d+)", url) or [None, ""])[1]
        return "[#%s](%s)" % (num, url) if num else "[link](%s)" % url

    risk_icon = {"high": "\U0001F534 High", "medium": "\U0001F7E0 Medium", "low": "\U0001F535 Low"}
    total = len(upcoming) + len(done)
    long_list = total > LIST_LIMIT and not show_all
    shown_up = upcoming if show_all else upcoming[:LIST_LIMIT]
    show_done = not long_list           # merged features are hidden (just counted) once the list is long
    print("**Build order** (1 = first). \u27a1\ufe0f next \u00b7 \U0001F7E2 ready \u00b7 \u23f3 waiting on others \u00b7 \U0001F6A7\U0001F4DD\U0001F528\U0001F50D\U0001F441\ufe0f in progress \u00b7 \U0001F4EC pull request open \u00b7 \u2705 merged")
    print("")
    print("| # | Status | Feature | PR | Risk | What it does | Waits for |")
    print("|---|---|---|---|---|---|---|")
    for n, b in enumerate(shown_up, 1):
        waiting = [d for d in b.get("depends_on", []) if by_status.get(d) != "merged"] if b.get("status") == "queued" else []
        note = " (on GitHub)" if claims and b["slug"] in claims and b.get("status") == "queued" else ""
        print("| %d | %s | %s%s | %s | %s | %s | %s |" % (n, badge(b), cell(b["slug"], 40), note, pr_cell(b),
                                                       risk_icon.get(b.get("risk", ""), cell(b.get("risk", "?"), 12)),
                                                       cell(b.get("_goal") or "(no goal written yet)"), cell(", ".join(waiting), 60) or "-"))
    if show_done:
        for b in done:
            extra = " (its brief still says %s)" % b["_brief_status"] if b.get("_brief_status") else ""
            print("| \u2013 | %s | %s%s | %s | | | |" % (badge(b), cell(b["slug"], 40), extra, pr_cell(b)))
    print("")
    if len(upcoming) > len(shown_up):
        print("Showing the first %d of %d features still to do. Ask for 'show more' to see the rest (queue_status.py --all)." % (len(shown_up), len(upcoming)))
    if done and not show_done:
        print("\u2705 %d merged feature(s) hidden because the list is long. Ask for 'show merged' to see them (queue_status.py --all)." % len(done))
    if stale:
        if "--sync" in sys.argv:
            for b in stale:
                if write_status(b["slug"], "merged"):
                    print("SYNCED: %s -> status: merged (%s)" % (b["slug"], b["_how"]))
            print("Brief files were changed in the working tree. Commit them in a small pull request.")
        else:
            print("\u26a0\ufe0f OUT OF DATE: %d brief(s) say a feature is still open, but it is merged (%s). "
                  "Run with --sync, or use /queue-status, to update them." % (len(stale), ", ".join(b["slug"] for b in stale)))
    for b, why in probably:
        print("\u26a0\ufe0f CHECK: %s is marked pr-open but %s. If it was merged, tell Claude; this is not counted as merged yet." % (b["slug"], why))
    rc, cur = git_out("rev-parse", "--abbrev-ref", "HEAD")
    if dref and rc == 0:
        rc2, behind = git_out("rev-list", "--count", "HEAD.." + dref)
        if rc2 == 0 and behind.isdigit() and int(behind) > 0 and cur not in ("HEAD",):
            print("\u26a0\ufe0f NOTE: this branch (%s) is %s commit(s) behind %s. Briefs here may be out of date; run git fetch and compare with the default branch." % (cur, behind, dref))
    pairs = []
    for i, a in enumerate(active):
        for b in active[i + 1:]:
            hit = next(((pa, pb) for pa in a.get("touches", []) for pb in b.get("touches", []) if overlaps(pa, pb)), None)
            if hit:
                pairs.append((a["slug"], b["slug"], hit[0], hit[1]))
    for a_, b_, pa, pb in pairs[:5]:
        print("\u26a0\ufe0f WARNING: '%s' and '%s' are both active and both touch %s / %s. Expect a merge conflict; merge one before the other." % (a_, b_, pa, pb))
    if len(pairs) > 5:
        print("\u26a0\ufe0f ...and %d more overlapping pairs. Merge the earliest pull requests first; the warnings clear as features merge." % (len(pairs) - 5))
    if claims:
        known = {b["slug"] for b in briefs}
        for s_ in sorted(claims - known):
            if not s_.startswith("kit-smoke-test"):
                print("NOTE: remote branch feature/%s has no brief on this branch yet." % s_)
    if not pairs:
        print("\u2705 No overlapping 'touches' among active features.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
