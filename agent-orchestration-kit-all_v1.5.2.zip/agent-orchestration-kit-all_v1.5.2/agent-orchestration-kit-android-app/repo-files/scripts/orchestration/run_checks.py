#!/usr/bin/env python3
"""Run the project's checks (from .claude/checks.json) and print a SHORT summary.

Why: passing checks cost zero AI tokens, and failing checks show only the last lines of output.
Full logs go to .claude/.check-logs/ (git-ignored).

Usage:
  python3 -I scripts/orchestration/run_checks.py            # run everything
  python3 -I scripts/orchestration/run_checks.py --only lint,test
  python3 -I scripts/orchestration/run_checks.py --list
  python3 -I scripts/orchestration/run_checks.py --strict   # CI mode: a skipped REQUIRED check counts as a failure
Exit code: 0 = no required check failed, 1 = a required check failed, 2 = bad config.
"""
import argparse
import json
import os
import shutil
import subprocess
import sys
import time

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
CONFIG = os.path.join(ROOT, ".claude", "checks.json")
LOGDIR = os.path.join(ROOT, ".claude", ".check-logs")
TAIL = 25


def npm_scripts():
    try:
        with open(os.path.join(ROOT, "package.json"), "r", encoding="utf-8") as fh:
            return set((json.load(fh).get("scripts") or {}).keys())
    except (OSError, ValueError):
        return set()


def skip_reason(check, scripts):
    if check.get("npm_script") and check["npm_script"] not in scripts:
        return "script '%s' not defined in package.json" % check["npm_script"]
    for f in check.get("requires_file", []):
        if not os.path.exists(os.path.join(ROOT, f)):
            return "file '%s' not found" % f
    for t in check.get("requires_tool", []):
        if not shutil.which(t):
            return "tool '%s' not installed here (CI must cover this)" % t
    env_any = check.get("requires_env_any", [])
    if env_any and not any(os.environ.get(e) for e in env_any):
        return "none of %s is set here (CI must cover this)" % "/".join(env_any)
    return None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--only", default="")
    ap.add_argument("--list", action="store_true")
    ap.add_argument("--strict", action="store_true")
    args = ap.parse_args()

    try:
        with open(CONFIG, "r", encoding="utf-8") as fh:
            cfg = json.load(fh)
        checks = cfg["checks"]
    except (OSError, ValueError, KeyError) as exc:
        print("RESULT: CONFIG-ERROR (%s)" % exc)
        return 2

    only = {x.strip() for x in args.only.split(",") if x.strip()}
    if args.list:
        for c in checks:
            print("%-14s %-8s %s" % (c["name"], "required" if c.get("required", True) else "optional", c["cmd"]))
        return 0

    os.makedirs(LOGDIR, exist_ok=True)
    scripts = npm_scripts()
    failed_required, skipped_required, lines = [], [], []

    for c in checks:
        name = c["name"]
        if only and name not in only:
            continue
        required = c.get("required", True)
        why = skip_reason(c, scripts)
        if why:
            lines.append("SKIP  %-12s %s%s" % (name, why, " [required]" if required else ""))
            if required:
                skipped_required.append(name)
            continue
        start = time.time()
        try:
            p = subprocess.run(c["cmd"], shell=True, cwd=ROOT, capture_output=True, text=True,
                               timeout=int(c.get("timeout", 600)))
            out, rc = (p.stdout or "") + (p.stderr or ""), p.returncode
        except subprocess.TimeoutExpired as exc:
            out, rc = ((exc.stdout or b"").decode("utf-8", "replace") if isinstance(exc.stdout, bytes) else (exc.stdout or "")) + "\nTIMED OUT", 124
        secs = int(time.time() - start)
        with open(os.path.join(LOGDIR, name + ".log"), "w", encoding="utf-8") as fh:
            fh.write(out)
        if rc == 0:
            lines.append("PASS  %-12s (%ds)" % (name, secs))
        else:
            tag = "FAIL" if required else "WARN"
            lines.append("%s  %-12s (%ds) exit %d. Last lines:" % (tag, name, secs, rc))
            lines += ["      | " + l for l in out.strip().splitlines()[-TAIL:]]
            if required:
                failed_required.append(name)

    print("\n".join(lines))
    if failed_required and os.path.exists(os.path.join(ROOT, "package.json")) and not os.path.isdir(os.path.join(ROOT, "node_modules")):
        print("HINT: this project's packages are not installed in this session (a fresh cloud session has none). "
              "Run: python3 -I scripts/orchestration/setup_deps.py   then run the checks again.")
    if failed_required:
        print("RESULT: FAIL (%s)" % ", ".join(failed_required))
        return 1
    if skipped_required and args.strict:
        print("RESULT: FAIL (required checks could not run in CI: %s)" % ", ".join(skipped_required))
        return 1
    if skipped_required:
        print("RESULT: PASS-WITH-SKIPS (required but skipped here: %s). CI must cover these." % ", ".join(skipped_required))
        return 0
    print("RESULT: PASS")
    return 0


if __name__ == "__main__":
    sys.exit(main())
