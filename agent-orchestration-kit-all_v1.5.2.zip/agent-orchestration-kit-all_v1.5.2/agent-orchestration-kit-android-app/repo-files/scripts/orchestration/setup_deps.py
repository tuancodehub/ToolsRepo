#!/usr/bin/env python3
"""Make sure the project's packages are installed (a fresh cloud session starts with none), safely.

  setup_deps.py            install what is missing, if it can be done safely and automatically
  setup_deps.py --check    only report (exit 0 = installed or nothing to install, 1 = missing)

Node projects with a package-lock.json: `npm ci --ignore-scripts` (exact versions from the lock file, install scripts
OFF). If a package really needs its install script, tell the owner; never turn scripts on yourself. Other package
managers and languages are reported, never guessed. Standard library only. Exit codes: 0 ok, 1 missing or failed.
"""
import os
import subprocess
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


def has(*names):
    return any(os.path.exists(os.path.join(ROOT, n)) for n in names)


def node_installed():
    nm = os.path.join(ROOT, "node_modules")
    return os.path.isdir(nm) and bool([e for e in os.listdir(nm) if not e.startswith(".")] or os.path.isdir(os.path.join(nm, ".bin")))


def main():
    check = "--check" in sys.argv
    if not has("package.json"):
        print("DEPS: nothing to install here (no package.json). Other stacks: follow docs/orchestration/STACK-PROFILE.md.")
        return 0
    if node_installed():
        print("DEPS: ok (node_modules is present).")
        return 0
    if check:
        print("DEPS: MISSING. Run: python3 -I scripts/orchestration/setup_deps.py")
        return 1
    if has("package-lock.json"):
        print("DEPS: installing with 'npm ci --ignore-scripts' (exact versions, install scripts off). This can take a few minutes...")
        try:
            p = subprocess.run(["npm", "ci", "--ignore-scripts"], cwd=ROOT, capture_output=True, text=True, timeout=900)
        except (OSError, subprocess.SubprocessError) as exc:
            print("DEPS: FAILED to start npm (%s). Is Node installed? See docs/orchestration/TROUBLESHOOTING.md." % exc)
            return 1
        if p.returncode != 0:
            print("DEPS: FAILED. Last lines of npm's output:\n" + "\n".join((p.stderr or p.stdout).strip().splitlines()[-8:]))
            return 1
        print("DEPS: installed. If a tool still complains about a missing binary, tell the owner: it may need its install script (never enable scripts yourself).")
        return 0
    if has("yarn.lock", "pnpm-lock.yaml", "bun.lockb", "bun.lock"):
        print("DEPS: MISSING, and this project uses another package manager. Ask the owner to approve the install command from STACK-PROFILE.md (with install scripts off).")
        return 1
    print("DEPS: MISSING, and there is no lock file, so there is no exact version list to install from. Ask the owner before installing anything.")
    return 1


if __name__ == "__main__":
    sys.exit(main())
