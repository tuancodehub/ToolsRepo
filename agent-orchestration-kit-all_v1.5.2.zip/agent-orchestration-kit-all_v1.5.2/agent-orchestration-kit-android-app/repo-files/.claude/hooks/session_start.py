#!/usr/bin/env python3
"""SessionStart hook: prints a short orientation (it becomes part of Claude's context) and
makes sure the git pre-commit hook is switched on in this clone. Never blocks."""
import os
import subprocess
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _common import (allowed_list_text, branch_protected, current_branch, folder_sets, git_common_dir,  # noqa: E402
                     load_config, load_workspace, main_repo_root, project_dir, tools_dir)


def run(args, cwd, timeout=8):
    try:
        out = subprocess.run(args, cwd=cwd, capture_output=True, text=True, timeout=timeout)
        return out.returncode, out.stdout.strip()
    except (OSError, subprocess.SubprocessError):
        return 1, ""


def main():
    proj = project_dir(os.getcwd())
    cfg = load_config(proj)
    lines = ["[orchestration kit]"]

    if os.path.exists(os.path.join(proj, ".githooks", "pre-commit")):
        try:
            os.chmod(os.path.join(proj, ".githooks", "pre-commit"), 0o755)  # zip uploads can lose the executable bit
        except OSError:
            pass
        _, cur = run(["git", "config", "--get", "core.hooksPath"], proj)
        if cur != ".githooks":
            run(["git", "config", "core.hooksPath", ".githooks"], proj)

    branch = current_branch(proj)
    if branch and branch_protected(branch, cfg):
        lines.append("You are on protected branch '%s'. Do not edit here. Start a feature with /build-feature <slug>." % branch)
    elif branch:
        lines.append("Branch: %s" % branch)

    ws = load_workspace(proj)
    if ws:
        free, areas, wide, _ = folder_sets(ws, proj)
        lines.append("Mode: %s (your own computer). You may change files ONLY inside: %s. Reading and running tools from "
                     "system folders is fine. Never install into the system; put tools and Python virtual environments in %s."
                     % (ws["mode"], allowed_list_text(free, areas, wide), tools_dir(ws)))
        if ws["mode"] == "local":
            lines.append("No GitHub here: never push. Commit locally; the owner merges with local_merge.py.")
        else:
            lines.append("Push only with feature_git.py push (it takes turns with other sessions). "
                         "At most %s sessions run at once." % ws.get("max_sessions", 2))
        if os.path.realpath(proj) != os.path.realpath(main_repo_root(proj)):
            slug = os.path.basename(proj)
            slots_file = os.path.join(git_common_dir(proj), "orchestration", "slots.json")
            try:
                import json as _json
                slot = _json.load(open(slots_file)).get(slug)
            except (OSError, ValueError):
                slot = None
            lines.append("This is a worktree folder (parallel session). Use your own dev-server ports%s; "
                         "run: python3 -I scripts/orchestration/worktree.py ports" % (" (slot %s)" % slot if slot else ""))
    elif not os.environ.get("CLAUDE_CODE_REMOTE"):
        lines.append("NOTE: no workspace.local.json, so the 'stay inside your work folder' rule is NOT active. If you work on your "
                     "own computer, ask the owner to run set_workspace.py (see docs/orchestration/LOCAL-MODE.md).")
    try:
        with open(os.path.join(proj, "docs", "orchestration", "KIT-VERSION.txt"), "r", encoding="utf-8") as fh:
            lines.append("Kit version: " + fh.readline().strip().replace("agent-orchestration-kit ", "", 1))
    except OSError:
        pass
    st_path = os.path.join(proj, "docs", "oneshot", "RUN.json")
    try:
        import json as _j
        st = _j.load(open(st_path, "r", encoding="utf-8"))
        if not st.get("finished"):
            lines.append("A oneshot run (%s) is unfinished on this branch. To continue it, run /oneshot-resume; otherwise ignore." % st.get("run_id"))
    except (OSError, ValueError):
        pass
    from _common import oneshot_active
    if oneshot_active(proj):
        lines.append("ONESHOT MODE is on: nobody is here to approve prompts. When a hook blocks something it would have asked about, "
                     "park it (python3 -I scripts/orchestration/park.py add ...) and continue with a safe alternative. Hard blocks never change.")
    lines.append("Rules: never push protected branches or merge PRs; push only with "
                 "'python3 scripts/orchestration/feature_git.py push'; never read secrets; "
                 "only the orchestrator asks the owner questions. Full rules: CLAUDE.md.")

    project_md = os.path.join(proj, "docs", "orchestration", "PROJECT.md")
    try:
        with open(project_md, "r", encoding="utf-8") as fh:
            if "{{" in fh.read():
                lines.append("SETUP NEEDED: docs/orchestration/PROJECT.md still has {{placeholders}}. Run /init-project first.")
    except OSError:
        pass

    # This computer's copy of the repository does not refresh by itself: fetch so merges made on GitHub are visible.
    rc0, _ = run(["git", "remote", "get-url", "origin"], proj, timeout=5)
    if rc0 == 0:
        rcf, _ = run(["git", "fetch", "--quiet", "--prune", "origin"], proj, timeout=12)
        lines.append("Fetched the latest from GitHub." if rcf == 0 else "Could not fetch from GitHub (offline?): merge information may be old.")
    qs = os.path.join(proj, "scripts", "orchestration", "queue_status.py")
    if os.path.exists(qs):
        rc, out = run([sys.executable, "-I", qs, "--short"], proj, timeout=12)
        if rc == 0 and out:
            lines.append(out)

    print("\n".join(lines))
    sys.exit(0)


if __name__ == "__main__":
    try:
        main()
    except Exception:
        sys.exit(0)
