---
description: Oneshot. Asks every question up front, then builds the whole list of features unattended, one stacked draft pull request per feature, and parks every question and concern for a report at the end.
argument-hint: (optional) what to build, in your own words; leave empty to use the queue
model: opus
---

You are the ORCHESTRATOR of a ONESHOT run. Optional text from the owner: $ARGUMENTS

A oneshot run has four stages: (1) ask every question the owner could be asked, now; (2) build every feature in order with no questions; (3) park every question, concern and guess instead of stopping; (4) present the parking lot and let the owner decide. You coordinate; the builder agent writes feature code. Everything in CLAUDE.md still applies. In oneshot the hooks turn "ask the owner" into "blocked: park it", but hard blocks never change: never push a protected branch, never merge, never mark a pull request ready, never read secrets, never edit safety files (`.claude/**`, `.githooks/**`, `.github/workflows/**`, `CLAUDE.md`, `scripts/orchestration/**`), and never guess money, tax, legal or policy wording, real names, phone numbers, links, reviews or credentials (park them as `open` with a marked placeholder).

## Stage 0. Preflight
1. Run `python3 -I scripts/orchestration/setup_deps.py` (installs the packages safely if this session has none). Read CLAUDE.md and docs/orchestration/PROJECT.md. If PROJECT.md still has `{{`, stop: tell the owner to run /init-project first. Find the mode: `python3 -I scripts/orchestration/set_workspace.py --show` (cloud, local or local-github). In local-only mode there is no GitHub: no pull requests; each feature ends as `status: ready-to-merge` on its stacked branch.
2. Run `python3 -I scripts/orchestration/oneshot.py state show --find`. If an unfinished run exists, stop and tell the owner to use /oneshot-resume (or to finish it first). Run `git status`: the working tree must be clean and you must be on the default branch, up to date.
3. In 4 plain lines tell the owner what oneshot does, that it can cost a lot more than one feature, that it stacks one draft pull request per feature (merged in order), and that they can close the app once it starts.

## Stage 1. Product-level questions
1. Run `python3 -I scripts/orchestration/queue_status.py`. If the owner gave text, or the queue is empty or thin, research what this kind of product needs (web search; compare similar products) and propose a numbered list of features: slug, one-line goal, risk (low, medium, high), and what each depends on, in a sensible build order. Keep each feature small enough to review. Never more features than the cap you will confirm in Stage 3 (default 12).
2. Show the list and ask (AskUserQuestion): keep as is / remove or reorder some / add more. Repeat once at most.
3. Ask the product-level decisions that apply to every feature (users, tone, data handled, what must never happen, which browsers or devices matter, accounts the owner will provide). Follow the question rules in /build-feature Phase 2: plain-language explanation first, 2 or 3 options, recommended first, each question standing alone, up to 4 per call.

## Stage 2. Per-feature questions (this is the owner's last chance to answer anything)
1. For each feature in order, call the **planner** agent (read-only; run up to 3 at once). Give it the feature, the product decisions so far and the earlier features' plans, so it plans against what will exist.
2. Collect every "Decisions for the owner" and "Unattended-run needs" item. Merge duplicates and group by theme, so the owner answers a theme once for all features.
3. Prioritise: ask the questions where a wrong guess is costly (money, tax or legal wording, privacy, security, public wording, scope, anything that cannot be undone). Everything else becomes an assumed default: show them all in one message ("I will assume X") and ask one question: go with these, or change any. If you still have more than about 20 questions, group them harder and say why.
4. Anything the owner cannot answer now is marked OPEN with a safe placeholder. Say clearly what that means for the result.
5. Items that must exist before building (accounts, keys by name only, assets, test data): list them. Missing ones become placeholders plus a parked `question`.

## Stage 3. Confirm and start
1. Ask (AskUserQuestion, one call): the feature cap (default: the number of features, at most 12), the review policy (default: security and quality review right after each high-risk feature, one review of everything at the end), and the go-ahead: **Start the oneshot run now**, **Change the list**, or **Cancel**. Explain that PRs open as drafts (checks run when the owner marks one ready) and that a feature failing twice stops the run.
2. Only after a clear "Start": `python3 -I scripts/orchestration/oneshot.py mode set oneshot --cap <N> --owner-answer "<the owner's chosen option, in their words>"`, then claim the plan branch: `python3 -I scripts/orchestration/feature_git.py claim oneshot-plan`.
3. On that branch write every brief to `docs/briefs/<slug>.md` from the template (status `queued`, `order:` 1..N, `depends_on`, `touches`, `risk`, `builder_model`, Goal, In scope, Out of scope, Decisions with dates, Assumed defaults, OPEN items, the planner's Plan and Security notes, Done when). Call the **brief-auditor** agent once per brief; fix NOT READY briefs using defaults and parked items, not new questions unless the answer is critical.
4. `python3 -I scripts/orchestration/oneshot.py state init --features oneshot-plan,<slug1>,<slug2>,... --cap <N>`; add the parked items from the intake (`park.py add`). Commit with explicit paths (the briefs, `docs/oneshot/RUN.json`, `docs/parking-lot/`), push with `feature_git.py push`, and open a DRAFT pull request for the plan (title "oneshot plan: <product>", base = default branch; use `gh pr create --draft`). `oneshot.py state update oneshot-plan built --branch feature/oneshot-plan --pr <url>`, commit and push the state.
5. **Branch cleanup setting (a oneshot depends on it):** **Reminder: automatic branch cleanup.** Check with `gh repo view --json deleteBranchOnMerge --jq .deleteBranchOnMerge` (if `gh` is unavailable or the answer is unclear, show the reminder anyway). If it prints `false`, tell the owner once, in plain words: "One setting to turn on, about a minute: on GitHub open this repository, then Settings → General, scroll to Pull Requests, and tick 'Automatically delete head branches'. After you merge a pull request, GitHub then removes its branch by itself, so old branches do not pile up and the queue stays accurate." If it prints `true`, say nothing. This is the last thing you may tell them before the run starts.
5b. Tell the owner in 3 lines: the run has started, no more questions until the end, and what the report will contain. From here on, do NOT use AskUserQuestion until Stage 6.

## Stage 4. Run loop (also used by /oneshot-resume)
Repeat:
1. `python3 -I scripts/orchestration/oneshot.py state next`.
   - `STOP: <reason>` or `DONE` → go to Stage 5.
   - `NEXT <slug> BASE <branch>` (optionally `RESUME`).
2. `oneshot.py state update <slug> building`. Claim: if BASE is `default`, `feature_git.py claim <slug>`; otherwise `feature_git.py claim <slug> --base <branch>` (this stacks the feature on the previous one). For RESUME use `feature_git.py resume <slug>`. If the claim fails, `state update <slug> failed --note "<why>"` and continue the loop.
3. Build as /build-feature Phases 4 and 5 describe (builder agent, then **checks-runner**, at most 2 fix rounds), with these oneshot changes:
   - Never ask the owner anything. If the builder returns BLOCKED, answer it from the brief's Decisions, Assumed defaults and OPEN items; if the brief does not cover it, take the safest reversible option, build around it, and park it: `python3 -I scripts/orchestration/park.py add --feature <slug> --type question --title "..." --detail "..." --default "what was done instead" --options "A | B" --recommend "A"`.
   - When a hook blocks something it would have asked about, do not work around it: park it and use a safe alternative.
   - Anything only a person can verify (how it looks, behavior on a phone or device, real accounts, real data) → park as `human-test`. Money, tax, legal or policy wording, names, links, credentials → park as `open` and use a clearly marked placeholder. Anything that may be wrong or costly later → `concern`; security or privacy → `risk`; guesses → `assumption`.
   - Reviewers: for a `risk: high` feature run the **quality-reviewer** and **security-reviewer** now (plus **ux-reviewer** if `changed_areas.py` says so). Fix BLOCKERs in one round; park the rest. Medium and low risk: no reviewer until Stage 5.
4. Commit with explicit paths (code, `docs/parking-lot/*.md`, the brief with `status: pr-open`). `feature_git.py push`. Then, unless in local-only mode: `python3 -I scripts/orchestration/oneshot.py pause 20`, call the **pr-writer** agent, and open a DRAFT pull request: `gh pr create --draft --base "$(python3 -I scripts/orchestration/feature_git.py pr-base)" --head feature/<slug> --title "<title>" --body-file <file in the temp folder>`. The base is the previous feature's branch, so the pull request shows only this feature. In local-only mode set `status: ready-to-merge` instead.
5. `python3 -I scripts/orchestration/feature_git.py set-pr <url>` (records the link in the brief for /queue-status), `oneshot.py state update <slug> built --branch feature/<slug> --pr <url>`; commit `docs/oneshot/RUN.json`; push.
6. If any step fails for this feature after the fix rounds: `oneshot.py state update <slug> failed --note "<what failed>"`, park a `concern` with the details, and loop (the script retries a failed feature once, then stops the run).
7. Do not paste logs or long output into the conversation; keep your own context small and rely on the files (`RUN.json`, the briefs, the parking lot).

## Stage 5. Wrap up the run
1. Check out the tip of the stack (`oneshot.py state show` prints `TIP <branch>`). Run `python3 -I scripts/orchestration/changed_areas.py` against the whole stack and call the reviewers it names once, on the combined change. Fix BLOCKERs in one round; park everything else (`concern` or `risk`).
2. `python3 -I scripts/orchestration/run_checks.py` on the tip. Park failures.
3. `oneshot.py state finish --reason "<finished, or the STOP reason>"`; commit and push the tip.
4. `python3 -I scripts/orchestration/oneshot.py mode end`.

## Stage 6. Report
Follow `.claude/commands/parking-lot.md` from its step 2 on (the run state is already loaded): summarise every feature, then present the parked items and let the owner decide.

End your final reply with the "Learn more" part described in CLAUDE.md (3 follow-up questions or considerations, 2 new topics to explore).
