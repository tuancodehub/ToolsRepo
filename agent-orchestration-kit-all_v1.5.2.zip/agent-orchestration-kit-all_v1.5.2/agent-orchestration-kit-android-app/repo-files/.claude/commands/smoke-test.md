---
description: Prove the kit works in THIS repository and THIS environment before you rely on it (hooks, claims, agents, models, checks).
argument-hint: (no arguments)
model: sonnet
---

Run a safe end-to-end test of the orchestration kit. Report plainly; do not hide failures. Never attempt a dangerous command to "see if it is blocked": the self-test already proves that safely in a throw-away repository. Keep it cheap: no step below needs more than the three small agent calls in step 5.

0. **Kit version.** Run `python3 -I scripts/orchestration/kit_version.py check`. Report the version it prints ("Kit version: ...") and the "Kit files" line. Missing files are a FAIL; changed safety files are a warning to show the owner (they may be the owner's own changes). If the version is UNKNOWN, say the install is incomplete.
1. Run `python3 -I scripts/orchestration/selftest.py` and show the summary line and any FAIL lines.
2. **Hooks are live.** Check yourself, without asking the owner: this session's start-up text should contain a line starting "[orchestration kit]" (it also shows the kit version and fetch result). If it is missing, report that hooks may not be running here and point to docs/orchestration/TROUBLESHOOTING.md.
3. **Packages and checks.** Run `python3 -I scripts/orchestration/setup_deps.py` (a fresh cloud session has no packages; this installs them safely with install scripts off, or says what to do). Then `python3 -I scripts/orchestration/run_checks.py --list`, then `python3 -I scripts/orchestration/run_checks.py`, and report the RESULT line and any SKIP lines (a skipped required check means CI must cover it).
4. Run `python3 -I scripts/orchestration/queue_status.py` and `python3 -I scripts/orchestration/changed_areas.py`.
5. **Agents and models.** Run `python3 -I scripts/orchestration/set_models.py --verify` and show its table: it reads each agent's model setting and compares it with the standard tiers, exactly and for free. Then check that models really apply by calling ONE agent per tier with the prompt "Reply with one line: your role and which model you are.": **planner** (top), **quality-reviewer** (mid), **checks-runner** (low). Show the three replies in a small table. An agent reports its own model, so this is a strong sign, not proof; say so once. Do not call the other agents: the table above already covers their settings.
6. Local modes only: run `python3 -I scripts/orchestration/set_workspace.py --check` and report every line. Confirm the folder fence from the SessionStart text that lists the allowed folders; do NOT try a forbidden command to test it (the self-test already proves the rules safely).
7. **Claim test (dry run, no question needed, nothing is created).** Run `python3 -I scripts/orchestration/feature_git.py claim kit-smoke-test --check`. "CLAIM CHECK OK" is a pass. "ALREADY CLAIMED" is also a pass (it shows the guard works), but add a note: a branch `feature/kit-smoke-test` is left over from an older test; the owner can delete it on GitHub (agents cannot).
8. **Branch cleanup setting.** **Reminder: automatic branch cleanup.** Check with `gh repo view --json deleteBranchOnMerge --jq .deleteBranchOnMerge` (if `gh` is unavailable or the answer is unclear, show the reminder anyway). If it prints `false`, tell the owner once, in plain words: "One setting to turn on, about a minute: on GitHub open this repository, then Settings → General, scroll to Pull Requests, and tick 'Automatically delete head branches'. After you merge a pull request, GitHub then removes its branch by itself, so old branches do not pile up and the queue stays accurate." If it prints `true`, say nothing.
9. Finish with: the kit version in use, a one-line cost note (ask the owner to run `/cost`), and a verdict: **PASS**, **PASS with notes** (list them), or **NEEDS ATTENTION** (list what to fix).

End your final reply with the "Learn more" part described in CLAUDE.md (3 follow-up questions or considerations, 2 new topics to explore).
