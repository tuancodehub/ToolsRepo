---
description: Show the feature queue, what is really merged (checked against git and GitHub), who has claimed what, and any overlap warnings.
argument-hint: (no arguments)
model: sonnet
---

1. Get fresh information first (skip in local-only mode, which has no GitHub): run `git fetch --prune origin`. This computer's copy of the repository does not update by itself, so without this, merges made on GitHub since the session started are invisible.
2. Run `python3 -I scripts/orchestration/queue_status.py`. It prints a markdown table (columns: #, Status with an emoji, Feature, PR (a link to each feature's pull request), Risk, What it does, Waits for). It shows at most 20 rows; once the list is long, merged features are hidden and only counted. If the owner asks to see more, merged features, or everything, run `python3 -I scripts/orchestration/queue_status.py --all` and paste that followed by warning lines. Paste the ENTIRE output in your reply exactly as printed, as normal markdown (NOT inside a code block, so the table renders as a table): every row, the legend line and every warning. Do not shorten it, summarize it, reorder it or replace it with a count: the owner reads it on a phone and the tool output is folded away there.
3. The tool detects merges from the real history (the branch is inside the default branch, or GitHub says the pull request was merged), not only from the `status:` line in each brief. If the output has an `OUT OF DATE` line, the brief files still say a merged feature is open. Ask with AskUserQuestion: **Update them now with a small pull request** (Recommended), or **Leave them**. If yes: `git switch -c chore/mark-merged origin/<default branch>` (the default branch is what `git symbolic-ref --short refs/remotes/origin/HEAD` shows, without `origin/`), run `python3 -I scripts/orchestration/queue_status.py --sync`, commit only the changed brief files by explicit path with the message "Mark merged features in the queue", `python3 -I scripts/orchestration/feature_git.py push`, then `gh pr create --base <default branch> --head chore/mark-merged` with a one-line description, and tell the owner to merge it. Never merge it yourself.
4. A `CHECK:` line means a brief says pr-open but its branch is gone from GitHub (usually deleted after a merge). Ask the owner whether it was merged; if yes, set that brief's `status: merged` in the same small pull request. Do not guess.
5. A `NOTE:` that this branch is behind the default branch means the briefs you see may be old: say so plainly.
6. Then add at most two lines: which feature is NEXT (marked `<-- NEXT`), and any warning that needs the owner's attention.

End your final reply with the "Learn more" part described in CLAUDE.md (3 follow-up questions or considerations, 2 new topics to explore).
