# Troubleshooting

| Problem | Likely cause | Do this |
|---|---|---|
| No "[orchestration kit]" text at session start | Hooks are not running (repository not attached, `python3` missing, settings not loaded) | Check the repository is attached and `.claude/settings.json` is on the branch. Run `python3 --version`. Run `/smoke-test`. Layer 1 permissions still apply meanwhile |
| Everything gets blocked with "guard ... failed" | A hook crashed (deliberately fail-closed) | Run `python3 -I scripts/orchestration/selftest.py` and read the failure. Do not edit hooks mid-feature |
| An approval prompt appears for `.claude/...` or `CLAUDE.md` | Protected file. Intentional | Approve only if YOU asked for that change. Otherwise choose No; the agent should report BLOCKED |
| A legitimate command is blocked | The guard is conservative | Use the alternative the message suggests (for example a package script instead of `npx`; explicit `git add paths`). To change a rule, do it in a separate owner-supervised session |
| `ALREADY CLAIMED` | The branch `feature/<slug>` exists on GitHub (another session, or an old one) | Pick another slug, or if the old session is dead use `feature_git.py resume <slug>` |
| Push failed with "too many requests" or 429 | Too many simultaneous git transfers | The script already retried once. Wait a minute, run `feature_git.py push` again. Start parallel sessions a minute apart |
| `npm ci` is refused | Install scripts are not disabled | Run `npm ci --ignore-scripts`, or add `ignore-scripts=true` to `.npmrc` (owner step) |
| Required check shows SKIP | The tool or script is not available in the cloud session (for example Gradle or Xcode) | CI covers it. Wait for CI on the pull request, or read the profile's notes |
| CI never starts | Actions disabled, minutes exhausted, or the trigger does not match | Check the repository's Actions tab and your budget (SETUP-CHECKLIST A). Mobile profiles also run on `feature/**` pushes |
| Reviewers run for tiny docs changes | `.claude/areas.json` globs do not cover your docs folders | Add your docs paths to `docs_only` (owner edit) |
| Agents ran on the wrong model | A model setting was ignored | Run `/smoke-test` step 5, then `scripts/orchestration/set_models.py --show`. Check `/cost` |
| `/build-feature` does not appear | Commands not loaded in this surface | Move the file to `.claude/skills/build-feature/SKILL.md` (a skill with the same text) and start a new session |
| Two features conflict at merge | Overlapping files | Merge one, then ask Claude to update the other branch from the default branch; run `/queue-status` earlier next time |
| Session ended mid-feature | Closed, timed out, or lost | Work up to the last push is on the branch. New session, then resume (see above) |
| No preview available | Host not connected, or the preview needs CI | See the Preview section of `STACK-PROFILE.md` and SETUP-CHECKLIST D |
| Cost higher than expected | Large features, repeated fix rounds, many parallel sessions | See `COST-POLICY.md` "Signs of overspend" |
| `SESSION LIMIT` when claiming | `max_sessions` sessions are already running on this computer | Finish one. If one is really finished or was closed, the owner runs `feature_git.py release <slug>` |
| `OVERLAP` warning | Two running sessions plan to change the same files | Finish and merge one first, or split the work |
| "outside your allowed work folders" | The folder fence: the file or folder is not inside the work folder | Work inside the work folder. To allow one more folder, the owner runs `set_workspace.py ... --extra-write <folder>` |
| "pip would install into your computer's own Python" | Plain `pip install` is blocked in local modes | Make a virtual environment in the tools folder (`worktree.py tools` shows the commands) |
| A system install (`apt`, `dnf`, `brew`, `winget`) is blocked | Agents may not change your system | Install it yourself, or put a portable copy in the tools folder |
| "Python 3 was not found" from a hook | The hooks need Python 3 on the PATH | Install Python 3 (see `LOCAL-MODE.md`); on Windows start Claude from Git Bash or WSL |
| Hooks seem inactive on Windows | Claude was started from a shell without `sh` | Start Claude from Git Bash or WSL |
| Two apps fight over a port | Two sessions use the same dev-server port | Use the numbers from `worktree.py ports` in each folder |
| `worktree.py add` says it is not set up | No `.claude/workspace.local.json` on this computer | Owner runs `set_workspace.py` (cloud mode has no worktrees) |
| Push is slow with several sessions | The push lock and pause (on purpose) | Wait; the script prints who it is waiting for |
| Selftest fails after copying the kit | A file was changed or a tool is missing | Read the FAIL lines; restore the original file from the kit zip |

If you are stuck: describe the symptom to Claude in a new session and ask it to read this file and `SAFETY.md` first.

## Oneshot
- **What did the hooks block or allow?** `python3 -I scripts/orchestration/hook_log.py summary` (or `recent 20`). The log is `.claude/.check-logs/hook-log.jsonl`, local only.
- **Run stopped or session ended:** open a new session and run `/oneshot-resume`. Progress is in `docs/oneshot/RUN.json` on the newest feature branch.
- **Checks do not run on a pull request:** it is a draft. Mark it "Ready for review".
- **Next pull request shows too many changes after merging the one below:** change its base branch to the default branch (or turn on "Automatically delete head branches" in the repository settings beforehand).
- **Agent is still asking for permission in oneshot:** those are permission-list prompts, not hooks. Add the command to `.claude/settings.local.json` (not committed) and tell the team.
- **"BLOCKED in oneshot mode":** expected. The agent should park the item. If it keeps stopping, run `/parking-lot`.
- **Oneshot refuses to start / expired:** the mode file expires after 12 hours without progress; `/oneshot-resume` turns it on again after your yes.

## The queue shows old merge information
This computer's copy of the repository only updates when it fetches, and a brief's `status:` line is not updated by GitHub. Since 1.5.1 the session start and `/queue-status` fetch first and detect merges from git and GitHub. If a brief still says pr-open for a merged feature, run `/queue-status` and accept the small pull request that updates it. If `gh` is not installed or not signed in, squash merges are found only when the branch was deleted on GitHub (shown as a CHECK line): tell Claude it was merged.
