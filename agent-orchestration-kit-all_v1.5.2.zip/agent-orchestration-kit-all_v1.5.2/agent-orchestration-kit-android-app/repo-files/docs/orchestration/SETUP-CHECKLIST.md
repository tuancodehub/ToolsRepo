# Setup checklist (owner-only steps)

Agents cannot, and must not, do these. Tick them off once per project. Menu names can change; if you cannot find one, search the setting's name in that product's help.

## A. Spending limits (do these first)
- [ ] **Claude:** set a spending limit or usage alert in your Claude account settings (names vary by plan). Note your plan's included usage so `/cost` numbers mean something.
- [ ] **GitHub Actions:** in GitHub, open your account or organization settings, find *Billing and licensing*, then *Budgets and alerts* (or the Actions spending limit). Set a low budget, or zero if you never want to pay, so CI stops instead of billing. Check *Usage* monthly.
- [ ] **Hosting and third parties:** set budgets or alerts wherever you pay per use (hosting, email, SMS, AI APIs, maps).

## B. GitHub repository settings
- [ ] Two-factor sign-in on your GitHub account.
- [ ] *Settings → Code security* (names vary): turn on Dependabot alerts and Dependabot security updates. Turn on secret scanning and push protection where your plan offers them.
- [ ] *Settings → Actions → General*: workflow permissions = **read** by default; require approval for first-time contributors' workflow runs; do not allow Actions to create or approve pull requests; prefer allowing only GitHub-authored and verified actions.
- [ ] **Branch rules on the default branch** (rulesets or branch protection): require a pull request, require the CI check to pass, block force pushes and deletion, require code-owner review for safety files. *Availability: public repositories on any plan; private repositories only on paid plans.* If you are on Free with a private repository you cannot set these: see `SAFETY.md`, gap 4, and decide to upgrade, go public, or accept the risk.
- [ ] Copy `.github/CODEOWNERS.example` to `.github/CODEOWNERS` (done for you by `/init-project` if you gave a username).
- [ ] Delete the head branch automatically after merge (a repository setting) to keep branches tidy.

## C. The cloud session environment
- [ ] Give sessions **only non-production values**: test API keys, test databases, sandbox payment keys. Never production secrets.
- [ ] If your environment lets you restrict network access or the GitHub connection's permissions, keep them as narrow as the project allows.
- [ ] Confirm the repository is attached when you start a session (so `CLAUDE.md`, hooks and agents load).

## D. Hosting and preview (depends on your stack; see `STACK-PROFILE.md`)
- [ ] Connect the repository to your host so every branch gets a preview address (websites and web apps), or set up the test-build route your stack uses (mobile).
- [ ] Put real secrets in the host's secret store, not the repository. Use separate preview and production settings.
- [ ] Decide who may open preview links (public link or sign-in) especially if the preview shows real-looking data.

## E. Install and verify the kit
- [ ] Merge the install pull request.
- [ ] Run `/init-project`, answer the questions, approve only the safety-file edit prompts it explains.
- [ ] Add `ignore-scripts=true` to `.npmrc` for JavaScript projects (agents will then be allowed plain `npm ci`); rebuild individual packages only when needed.
- [ ] Run `/smoke-test` in a new session and fix anything it flags.
- [ ] Build one tiny low-risk feature first and note its cost from `/cost` in the brief.

## G. Your own computer (only for the local modes; see `LOCAL-MODE.md`)
- [ ] Installed git and Python 3 (and Git for Windows / WSL on Windows); `python3 --version` and `git --version` work.
- [ ] Made one work folder (for example `~/Workspace`), put the project inside it, and ran `set_workspace.py` yourself. `set_workspace.py --check` says OK.
- [ ] Decided how many sessions at once (default 2) and told `/init-project`.
- [ ] Local-github: `git remote -v` shows your GitHub repository; you signed in to GitHub yourself (git credential manager or `gh auth login`).
- [ ] Backups: the work folder is covered by your computer's backup, or pushed to GitHub.
- [ ] For mobile apps: emulators, simulators or a test phone are set up (see the "Local testing" section of `STACK-PROFILE.md`). Use test accounts only.
- [ ] Sensitive computer? Run Claude in a virtual machine, container or separate user account (see `SAFETY.md`).

## F. Habits
- [ ] Read the diff of any pull request that touches `.claude/`, `.githooks/`, `.github/`, `CLAUDE.md`, dependencies or permissions before merging.
- [ ] Look at *Usage* on Claude and GitHub once a month.
- [ ] After upgrading Claude Code or changing environments, run `/smoke-test` again.

- [ ] Turn on "Automatically delete head branches" (GitHub: Settings → General → scroll to Pull Requests). Claude also reminds you after the first pull request. Oneshot needs it (so stacked pull requests retarget after each merge).
