# Oneshot (build a whole queue unattended)

Two ways to build, both always available in the same kit:

- **Step by step** (`/build-feature`, `/build-next`): you answer questions and approve each feature. Safest, most control.
- **Oneshot** (`/oneshot`): you answer every question first. Then every feature in the list is built without stopping, as one pull request per feature. Questions, concerns and guesses that come up are saved in a **parking lot**. At the end you get a report and decide what to change.

You are asked which you expect to use most in `/init-project`, and again after each finished feature. You can always start either one yourself.

## The flow
1. **Product questions.** The list of features is confirmed (kept, removed, added), plus questions that apply to every feature.
2. **Feature questions.** A planner looks at each feature. Costly-to-guess questions (money, tax or legal wording, privacy, security, public wording, scope) are asked. The rest become "assumed defaults" you confirm in one message.
3. **Go.** You pick the cap (max 12 features per run is the default), the review policy and press start. After this, no more questions until the report.
4. **Run.** One feature at a time, each on its own branch, each with its own draft pull request. A plan pull request (docs only: briefs, run state, intake answers) comes first.
5. **Wrap up.** Review of everything together, checks, run state closed.
6. **Report (`/parking-lot`).** Summary of every feature, then every parked item explained one batch at a time. Your choices are applied in ONE extra follow-up pull request on top. Nothing already built is rewritten.

## Stacked pull requests: merge order
Each feature is built on top of the previous one (feature 2's branch starts from feature 1's branch). Each pull request shows only its own changes. Merge **in order**: plan PR, feature 1, feature 2, and so on, then the follow-up. Pull requests open as **drafts**: checks do not run until you press "Ready for review". Mark each ready before merging it so the checks run.
Turn on "Automatically delete head branches" (GitHub: Settings → General → Pull Requests). Then GitHub moves the next pull request to the default branch when the one below it is merged. If it does not, change the base branch on the next pull request by hand.

## What changes for safety
- Things that would normally ask you ("may I?") become **blocks**: the agent gets a message, parks the item and picks a safe alternative. The run never waits for an answer that nobody is there to give.
- **Hard blocks never change:** no pushing protected branches, no merging, no marking pull requests ready, no secrets, no destructive system commands, no editing safety files, no guessing money, tax, legal or policy wording, names, phone numbers, links, reviews or credentials (they stay marked OPEN).
- Oneshot is switched on only by `/oneshot` or `/oneshot-resume`, after your explicit answer, which is recorded in `.claude/run-mode.json`. Agents cannot edit that file (hooks block it). It expires after 12 hours without progress.
- **Honest limits:** the record is a note, not a lock: a determined agent or person with shell access could still write it. The worst case is fewer questions, not fewer protections. Hooks prevent accidents; they are not a sandbox. The wording of the commands cannot be fully tested without a real run: expect to adjust after the first one.
- Command prompts (the permission list) cannot be switched off by hooks. The kit's allow list covers common build and test commands; if you still get prompts, add them to `.claude/settings.local.json` (not committed) and tell the team.

## After a run: what was blocked or allowed
Every hook decision (blocked, asked, and in oneshot allowed without asking) is logged in `.claude/.check-logs/hook-log.jsonl` (git-ignored; token-like text is cut out). `python3 -I scripts/orchestration/hook_log.py summary` shows the counts; `/parking-lot` shows it for you. After your first oneshot, also run the built-in `/fewer-permission-prompts`: it suggests commands to stop asking about. Approve only read-only or test commands. Add them yourself to `.claude/settings.local.json`; agents cannot edit settings.

## Stops and resume
- A feature that fails twice, two failures in a row, or reaching the cap **stops** the run. Later features are stacked on the failed one, so the run does not skip ahead.
- State lives in `docs/oneshot/RUN.json` (committed with each feature) and parked items in `docs/parking-lot/` (one file per item, so branches never conflict).
- If the session ends (limit, timeout, closed app): open a new session, run `/oneshot-resume`. It finds the newest saved state, asks for your yes, and continues.

## The parking lot
Item types: `open` (a fact only you have), `question`, `concern`, `risk`, `assumption`, `human-test` (things only a person can check: how it looks, a phone, a real account, real data). Each item records what was done instead.

## Cost and risk
- Cost is roughly the sum of every feature, with less of your attention. Set the cap to what you are willing to spend; check `/cost` at the end.
- Draft pull requests skip CI until ready. (Android: CI also runs on each push to `feature/**`: more minutes.) GitHub Free private repositories have 2,000 Linux minutes per month; macOS minutes count about 10 times.
- Unattended runs are good for well-understood features. For risky or unclear ones, prefer step by step. Long runs are kept small: each feature uses its own sub-agents and state is saved in files, not in the conversation.
- High-risk features get a quality and security review right after they are built; the rest are reviewed once at the end.

## By project type (what only a human can check)
- **Web app / web app with backend / static website:** look at pages and forms in each chosen browser; check on a phone; use real (test) accounts; backend: database changes are never run against a real database, only a test one.
- **Android, iOS, Expo (experimental):** touch behavior, device sizes, signing, store settings and real hardware cannot be checked by the agent. Treat oneshot as experimental here and expect a long human-test list.
