# Install: iOS app kit (instructions for Claude Code)

You are installing this orchestration kit into the repository you are working in. Follow these steps exactly. Do not change the owner's existing code.

1. Make a branch called `chore/install-orchestration-kit`.
2. Copy everything inside `repo-files/` into the repository root. Keep the same folder names, including hidden folders (`.claude`, `.githooks`, `.github`). Overwrite nothing the owner wrote themselves without saying so; if a file already exists and differs, list it and keep the owner's version of `.claude/checks.json`, `.claude/browsers.txt` and `docs/orchestration/PROJECT.md` (kit updates only).
3. Append `gitignore-additions.txt` to `.gitignore`, skipping lines already present. Create `.gitignore` if missing.
4. Make the first pull request pass its automatic checks:
   - **README.** If the repository has no `README.md`, create one: the project name as the heading, one plain sentence about what it is (ask nothing; use what you know, or write "TODO: describe this project"), and a line saying it uses the orchestration kit (see `docs/orchestration/README.md`). If one exists, leave it alone.
5. Do NOT copy anything else from the kit folder. Do not run the project's code. Do not read secrets.
6. Commit with a message that starts "Install orchestration kit 1.5.2", push the branch and open a pull request titled "Install orchestration kit 1.5.2". The installed version is recorded in `docs/orchestration/KIT-VERSION.txt`; run `python3 -I scripts/orchestration/kit_version.py check` and put its output in the description. In the description say the version you installed from (read `docs/orchestration/KIT-VERSION.txt` before copying; "none" for a first install) and to (1.5.2), list what was copied, what you created (README, version file) and anything you skipped.
7. Tell the owner, in plain words: merge the pull request themselves, then start a NEW session and run `/init-project`. Do not merge it yourself. Also tell them, once: "One GitHub setting to turn on, about a minute: open this repository on GitHub, then Settings → General, scroll to Pull Requests, and tick 'Automatically delete head branches'. After you merge a pull request, GitHub then removes its branch by itself, so old branches do not pile up." Put the same sentence at the end of the pull request description.

If a protected folder (`.claude`, `.github/workflows`) needs approval to edit, ask the owner: this install is the one expected time.
